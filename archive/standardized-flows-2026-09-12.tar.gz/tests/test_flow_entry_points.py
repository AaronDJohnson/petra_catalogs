"""
The flow-based entry points' argument handling.

:func:`petra.standardized_flows.make_catalog_standardized_flows` and
:func:`petra.copula_flows.make_catalog_copula_flows` are the two entry points
that translate deprecated keyword spellings *and* forward a long list of flow
hyperparameters.  The tests here pin the two things that silently went wrong:
a deprecated alias that warned and was then dropped on the floor, and an ``eps``
default that drifted away from the rest of the package so the recorded costs of
two entry points were no longer comparable.

They monkeypatch the downstream relabeler rather than running it: what is under
test is which values arrive there, not the labeling that comes back.

The second half of the file covers the grouped settings objects
:class:`petra.options.Initialization` and :class:`petra.options.FlowFit` on
``make_catalog_standardized_flows``.  The relabeler below it deliberately kept
its flat signature, so the objects have to be unpacked on the way down; a field
that never left its object would be silently replaced by the relabeler's own
default, which is the failure the forwarding tests here are aimed at.  The last
test is the one that says the refactor was a refactor: the same run spelled flat
and spelled with objects has to produce bit-identical chains.
"""

import dataclasses
import inspect
import warnings

import numpy as np
import pytest

import petra.copula_flows as copula_flows
import petra.standardized_flows as standardized_flows
from petra.copula_flows import DEFAULT_MAX_PATIENCE, make_catalog_copula_flows
from petra.options import FlowFit, Initialization
from petra.posterior_chain import PosteriorChain
from petra.standardized_flows import make_catalog_standardized_flows
from petra.utils import option_field_keywords


@pytest.fixture
def tiny_chain():
    """A 12-sample, two-source, one-parameter chain -- just enough to run on."""
    rng = np.random.default_rng(0)
    chain = rng.normal(size=(12, 2, 1)) + np.array([[0.0], [8.0]])
    return PosteriorChain(chain, 2, 1, trans_dimensional=True)


@pytest.fixture
def record_relabel(monkeypatch):
    """
    Replace both flow relabelers with a recorder.

    Returns
    -------
    calls : dict
        Populated with the keyword arguments the entry point forwarded, under
        the key ``"kwargs"``.  The stub returns its input chain unchanged.
    """
    calls = {}

    def fake_relabel(posterior_chain, **kwargs):
        calls["kwargs"] = kwargs
        return posterior_chain

    monkeypatch.setattr(standardized_flows, "relabel_standardized_flows", fake_relabel)
    monkeypatch.setattr(copula_flows, "relabel_copula_flows", fake_relabel)
    return calls


@pytest.mark.parametrize("entry_point", [
    make_catalog_standardized_flows,
    make_catalog_copula_flows,
], ids=lambda f: f.__name__)
def test_n_phases_alias_is_honoured_not_just_warned(entry_point, tiny_chain, record_relabel):
    """
    ``n_phases`` renames to ``num_iterations``, and the value must survive.

    Both entry points used to call ``resolve_deprecated_kwargs`` and then read
    back only the two initialization keys, so the ``num_iterations`` the
    resolver returned was discarded: the caller was told their keyword had a new
    name, and then silently got the default (50) instead of the 7 they asked
    for.
    """
    with pytest.warns(DeprecationWarning, match="n_phases"):
        entry_point(tiny_chain, 2, init_with_mv_normal=False, progress=False, n_phases=7)

    assert record_relabel["kwargs"]["num_iterations"] == 7


@pytest.mark.parametrize("entry_point", [
    make_catalog_standardized_flows,
    make_catalog_copula_flows,
], ids=lambda f: f.__name__)
def test_explicit_num_iterations_is_kept_without_the_alias(entry_point, tiny_chain, record_relabel):
    """The alias handling must not disturb the ordinary spelling."""
    entry_point(tiny_chain, 2, num_iterations=3, init_with_mv_normal=False, progress=False)

    assert record_relabel["kwargs"]["num_iterations"] == 3


def test_copula_flows_accepts_the_legacy_patience_spelling(tiny_chain, record_relabel):
    """
    ``patience`` is coppuccino's name for the early-stopping patience.

    petra spells it ``max_patience`` everywhere else, so the copula entry point
    was the only one whose training keywords could not be copied across from a
    sibling.  The old name still works, with a warning.
    """
    with pytest.warns(DeprecationWarning, match="patience"):
        make_catalog_copula_flows(tiny_chain, 2, num_iterations=1,
                                  init_with_mv_normal=False, progress=False,
                                  patience=5)

    assert record_relabel["kwargs"]["max_patience"] == 5


def test_copula_flows_defaults_to_the_documented_patience(tiny_chain, record_relabel):
    """Without either spelling, the module-level default is what is forwarded."""
    make_catalog_copula_flows(tiny_chain, 2, num_iterations=1,
                              init_with_mv_normal=False, progress=False)

    assert record_relabel["kwargs"]["max_patience"] == DEFAULT_MAX_PATIENCE


def test_copula_flows_rejects_both_patience_spellings(tiny_chain, record_relabel):
    """Passing both spellings is a mistake, not a precedence question."""
    with pytest.raises(TypeError, match="not both"):
        with pytest.warns(DeprecationWarning):
            make_catalog_copula_flows(tiny_chain, 2, init_with_mv_normal=False,
                                      progress=False, patience=5, max_patience=9)


def test_relabel_copula_flows_also_accepts_the_legacy_spelling(monkeypatch, tiny_chain):
    """The rename reaches the mid-level relabeler, not only the entry point."""
    seen = {}

    def fake_make_fit(chain, **kwargs):
        seen.update(kwargs)
        return lambda chain, max_num_sources: [None] * max_num_sources

    monkeypatch.setattr(copula_flows, "make_copula_flows_fit", fake_make_fit)
    monkeypatch.setattr(copula_flows, "create_relabel_samples",
                        lambda *args, **kwargs: (lambda pc, **kw: pc))

    with pytest.warns(DeprecationWarning, match="patience"):
        copula_flows.relabel_copula_flows(tiny_chain, 2, patience=3, progress=False)

    assert seen["max_patience"] == 3


def test_standardized_fitter_rejects_more_sources_than_it_was_built_for():
    """
    The fitter holds one slot per label, allocated up front.

    Asking it for more slots than that would silently fit only the ones it has,
    so it refuses instead.
    """
    chain = np.random.default_rng(0).normal(size=(10, 1, 1))
    fit = standardized_flows.make_standardized_flows_fit(
        chain, 1, threshold_samples=10 ** 6, progress=False)

    with pytest.raises(ValueError, match="built for at most 1 sources"):
        fit(chain, 2)


def test_plot_flows_reaches_the_display_helper(monkeypatch):
    """``plot_flows=True`` draws the diagnostic after every refit."""
    drawn = []
    monkeypatch.setattr(standardized_flows, "display_standardized_flows",
                        lambda *args, **kwargs: drawn.append(args))

    chain = np.random.default_rng(0).normal(size=(10, 1, 1))
    fit = standardized_flows.make_standardized_flows_fit(
        chain, 1, threshold_samples=10 ** 6, plot_flows=True, progress=False)
    fit(chain, 1)

    assert len(drawn) == 1


@pytest.mark.parametrize("entry_point", [
    make_catalog_standardized_flows,
    make_catalog_copula_flows,
    standardized_flows.relabel_standardized_flows,
    copula_flows.relabel_copula_flows,
], ids=lambda f: f.__name__)
def test_eps_default_matches_the_rest_of_the_package(entry_point):
    """
    ``eps`` clips the inclusion probabilities, and its value sets the scale of
    every ``log(1 - p)`` in the cost matrix.  It is ``1e-6`` in
    ``relabel_mv_normal``, ``relabel_univariate_normal`` and the Bayesian
    relabeler; the flow relabelers used to default to ``1e-2``, four orders of
    magnitude away, which made their reported costs incomparable.
    """
    assert inspect.signature(entry_point).parameters["eps"].default == 1e-6


# ---------------------------------------------------------------------------
# make_catalog_standardized_flows: the grouped settings objects
# ---------------------------------------------------------------------------

#: Every field of both objects, at a value that is not the default, spelled
#: flat.  Used twice: once to check the flat spelling still works unwarned, and
#: once as the left-hand side of the equivalence test.
NON_DEFAULT_FLAT = dict(
    init_with_mv_normal=True, init_num_iterations=7,
    knots=4, interval=3.5, max_epochs=3, max_patience=2, learning_rate=2e-3,
    log_prob_floor=-33.0, plot_flows=False,
)

#: The same values, grouped.
NON_DEFAULT_GROUPED = dict(
    initialization=Initialization(with_mv_normal=True, num_iterations=7),
    flow_fit=FlowFit(knots=4, interval=3.5, max_epochs=3, max_patience=2,
                     learning_rate=2e-3, log_prob_floor=-33.0, plot_flows=False),
)


def test_the_settings_objects_are_unpacked_for_the_relabeler(tiny_chain, record_relabel):
    """
    Flow settings must reach the relabeler after initialization is handled.

    :func:`petra.standardized_flows.relabel_standardized_flows` keeps its flat
    signature for direct callers, so every field of `flow_fit` has to be spelled out on the
    way down.  A field that was dropped there would not fail: the relabeler would
    quietly supply its own default, and the caller's ``max_epochs=3`` would
    become 100.
    """
    make_catalog_standardized_flows(
        tiny_chain, 2, num_iterations=1, progress=False,
        initialization=Initialization(with_mv_normal=False),
        flow_fit=FlowFit(knots=4, interval=3.5, max_epochs=3, max_patience=2,
                         learning_rate=2e-3, log_prob_floor=-33.0),
    )

    forwarded = record_relabel["kwargs"]
    assert forwarded["knots"] == 4
    assert forwarded["interval"] == 3.5
    assert forwarded["max_epochs"] == 3
    assert forwarded["max_patience"] == 2
    assert forwarded["learning_rate"] == 2e-3
    assert forwarded["log_prob_floor"] == -33.0


def test_an_omitted_settings_object_still_arrives_as_its_defaults(tiny_chain, record_relabel):
    """
    ``None`` means ``FlowFit()``, and the class is where those numbers live now.

    They used to be restated on the entry point, on the relabeler and on the
    fitter factory -- three copies, which is how a default drifts.  Reading them
    back off the class is what says the entry point no longer has its own.
    """
    make_catalog_standardized_flows(tiny_chain, 2, num_iterations=1, progress=False,
                                    init_with_mv_normal=False)

    forwarded = record_relabel["kwargs"]
    for field in dataclasses.fields(FlowFit):
        assert forwarded[field.name] == getattr(FlowFit(), field.name), field.name


def test_the_legacy_flat_keywords_are_still_accepted_without_a_warning(
        tiny_chain, record_relabel):
    """
    Every flat spelling keeps working, silently.

    A `DeprecationWarning` here would be wrong: the flat form is not deprecated,
    it is the *other* way of writing the same call, and it is what every existing
    script and notebook -- ``examples/simple_flows_example.py`` included -- uses.
    """
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        make_catalog_standardized_flows(tiny_chain, 2, num_iterations=1, progress=False,
                                        **NON_DEFAULT_FLAT)

    assert record_relabel["kwargs"]["knots"] == 4
    assert record_relabel["kwargs"]["max_epochs"] == 3


@pytest.mark.parametrize("kwargs, message", [
    ({"flow_fit": FlowFit(), "knots": 8}, "either 'knots' or 'flow_fit', not both"),
    ({"flow_fit": FlowFit(), "plot_flows": True}, "either 'plot_flows' or 'flow_fit', not both"),
    ({"initialization": Initialization(), "init_num_iterations": 3},
     "either 'init_num_iterations' or 'initialization', not both"),
])
def test_an_options_object_and_a_colliding_flat_keyword_is_an_error(
        tiny_chain, record_relabel, kwargs, message):
    """
    Not a merge, and not a precedence rule.

    Merging would mean answering "does ``FlowFit(knots=8)`` plus ``max_epochs=20``
    keep knots=8?" -- an answer that has to be remembered rather than read.
    """
    with pytest.raises(TypeError, match=message):
        make_catalog_standardized_flows(tiny_chain, 2, num_iterations=1, progress=False,
                                        **kwargs)


def test_a_non_colliding_flat_keyword_alongside_an_object_is_fine(tiny_chain, record_relabel):
    """
    The rule is per object, not per call.

    Passing a `FlowFit` must not make `init_num_iterations` unreachable --
    otherwise adopting one object would force adopting both.
    """
    make_catalog_standardized_flows(
        tiny_chain, 2, num_iterations=1, progress=False,
        flow_fit=FlowFit(knots=4), init_with_mv_normal=False,
    )

    assert record_relabel["kwargs"]["knots"] == 4


def test_a_deprecated_alias_onto_an_options_field_still_warns_and_is_honoured(
        tiny_chain, record_relabel, monkeypatch):
    """
    ``mv_normal_init_iterations`` renames to ``init_num_iterations``, which now
    lives on `Initialization` rather than in the signature.

    The alias has to stay applicable -- ``resolve_deprecated_kwargs`` checks its
    replacement against the entry point's accepted keywords, and that set is only
    right if the options index is unioned into it -- and the value has to reach
    the initializer instead of being warned about and then dropped.
    """
    import petra.make_catalog as make_catalog

    seen = {}

    def fake_mv_normal(posterior_chain, **kwargs):
        seen.update(kwargs)
        return posterior_chain

    monkeypatch.setattr(make_catalog, "relabel_mv_normal", fake_mv_normal)

    with pytest.warns(DeprecationWarning, match="mv_normal_init_iterations"):
        make_catalog_standardized_flows(tiny_chain, 2, num_iterations=1, progress=False,
                                        initialization_param_index=None,
                                        mv_normal_init_iterations=3)

    assert seen["num_iterations"] == 3


def test_the_top_level_iteration_budget_is_not_claimed_by_the_initializer():
    """
    `Initialization`'s field is `num_iterations`, and this entry point has one too.

    They are different budgets: one bounds the flow relabeling, the other bounds
    each initialization pass.  If ``Initialization.FLAT_KEYWORDS`` ever fell back
    to an identity map, ``num_iterations`` would be claimed by both the signature
    and the options index, and the caller's 50 flow iterations would be spent on
    the pre-relabeling instead.
    """
    index = option_field_keywords(make_catalog_standardized_flows)
    assert "num_iterations" not in index
    assert index["init_num_iterations"] == ("initialization", "num_iterations", Initialization)

    parameters = inspect.signature(make_catalog_standardized_flows).parameters
    assert parameters["num_iterations"].default == 50


def test_the_chains_own_fields_are_not_accepted_as_keywords(tiny_chain):
    """
    ``PosteriorChain`` is a dataclass, and it is this entry point's first
    argument.

    Detecting settings objects with ``dataclasses.is_dataclass`` would therefore
    have made ``cost_dict`` and friends accepted keywords here, each of them
    quietly ``replace()``ing the caller's chain instead of relabeling it.  The
    ``FLAT_KEYWORDS`` marker is what stops that, so they must still be unknown.
    """
    index = option_field_keywords(make_catalog_standardized_flows)
    for field in dataclasses.fields(PosteriorChain):
        assert field.name not in index

    with pytest.raises(TypeError, match="cost_dict"):
        make_catalog_standardized_flows(tiny_chain, 2, progress=False, cost_dict={})


def test_flat_and_grouped_spellings_produce_bit_identical_chains():
    """
    The whole refactor in one assertion.

    Every settings value below is non-default and reaches a different part of the
    run: `knots` and `interval` shape the spline, `max_epochs`, `max_patience`
    and `learning_rate` decide how far it trains, `log_prob_floor` sets what an
    impossible label costs, and `init_num_iterations` bounds each pre-relabeling
    pass.  ``threshold_samples`` is small enough that flows really are trained,
    so this is not merely a test of the uniform-prior fallback.  If any one value
    were dropped, defaulted or routed into the wrong object by only one of the
    two spellings, the two chains would differ.
    """
    rng = np.random.default_rng(3)
    chain = rng.normal(size=(16, 2, 2)) * 0.4 + np.array([[0.0, 0.0], [6.0, 6.0]])
    chain = np.stack([chain[i, rng.permutation(2), :] for i in range(16)])
    posterior_chain = PosteriorChain(chain, 2, 2, trans_dimensional=True)

    # One iteration, because an iteration here is two real flow fits and this
    # test pays for three runs of it; the relabeling loop's own early stop means
    # a second iteration would buy no extra coverage on a chain this separable.
    shared = dict(num_iterations=1, threshold_samples=5, rng_seed=11,
                  initialization_param_index=0, progress=False)

    flat = make_catalog_standardized_flows(posterior_chain, 2, **NON_DEFAULT_FLAT, **shared)
    grouped = make_catalog_standardized_flows(posterior_chain, 2, **NON_DEFAULT_GROUPED, **shared)

    np.testing.assert_array_equal(flat.get_chain(), grouped.get_chain())
    np.testing.assert_array_equal(flat.prob_in_model, grouped.prob_in_model)
    assert flat.cost_dict == grouped.cost_dict

    # ...and the settings really did reach the flows, so "identical" above is not
    # just "both spellings were ignored".  `knots` is the field to vary for that:
    # it changes the shape of the spline rather than how long it trains, so --
    # unlike `max_epochs`, which this chain converges under long before the
    # third epoch -- it always moves the density, and with it the assignment cost
    # the loop records.
    reshaped = make_catalog_standardized_flows(
        posterior_chain, 2,
        initialization=NON_DEFAULT_GROUPED["initialization"],
        flow_fit=dataclasses.replace(NON_DEFAULT_GROUPED["flow_fit"], knots=8),
        **shared,
    )
    assert reshaped.cost_dict != grouped.cost_dict


def test_every_make_catalog_entry_point_exposes_eps():
    """
    ``eps`` is part of the shared ``make_catalog_*`` keyword contract.

    `make_catalog_mv_normal` used 1e-6 internally via `relabel_mv_normal` but
    gave the caller no way to set it. Every retained method must expose the
    same knob so callers can compare assignment costs across methods.
    """
    import petra
    names = ["make_catalog_mv_normal", "make_catalog_standardized_flows",
             "make_catalog_copula_flows",
             "make_catalog_bayesian_gaussian"]
    for name in names:
        params = inspect.signature(getattr(petra, name)).parameters
        assert "eps" in params, f"{name} does not expose eps"
        assert params["eps"].default == 1e-6, f"{name} has a divergent eps default"
        assert params["eps"].kind is inspect.Parameter.KEYWORD_ONLY, name
