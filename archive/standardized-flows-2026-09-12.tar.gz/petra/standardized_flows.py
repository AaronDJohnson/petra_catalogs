"""
Standardized normalizing flows for petra catalogs.

This module provides normalizing flows with simple standardization (mean/std
normalization) instead of copula transforms. This allows label swapping to occur
naturally while still benefiting from data standardization for improved
numerical stability.

Entry point
-----------
:func:`make_catalog_standardized_flows` follows the shared ``make_catalog_*``
keyword contract: ``posterior_chain, max_num_sources`` positionally, then
keyword-only ``num_iterations``, ``initialization_param_index``,
``shuffle_seed``, ``rng_seed``, ``checkpoint_dir``, ``resume_from``,
``progress`` and ``eps``, and finally the method-specific settings.

Settings objects
----------------
The entry point takes the optional pre-relabeling as a
:class:`petra.options.Initialization` and the flows' training hyperparameters as
a :class:`petra.options.FlowFit`, rather than as nine loose keywords.  Every
field of both is still accepted as a plain keyword -- ``knots=8`` and
``flow_fit=FlowFit(knots=8)`` are the same call -- but an object *and* one of its
fields in the same call is a :class:`TypeError`, never a merge.
:func:`relabel_standardized_flows` and :func:`make_standardized_flows_fit` keep
their flat signatures; the entry point unpacks the objects when it forwards.

Conventions
-----------
* Chains are ``(n_samples, n_sources, n_params_per_source)`` and a NaN row means
  "this source is absent from this sample"; every fit here drops those rows.
* ``eps`` is the clip bound on the inclusion probabilities and is ``1e-6``
  throughout petra, so the assignment costs of the different entry points are
  directly comparable.  So is ``log_prob_floor``
  (:data:`petra.flow_utils.DEFAULT_LOG_PROB_FLOOR`), which sets how hard the
  assignment refuses an impossible label.
* Diagnostics go through :func:`petra.utils.get_logger`, never ``print``, and
  every progress bar is silenced by ``progress=False``.
* The flow-training hyperparameters (``knots``, ``interval``, ``max_epochs``,
  ``max_patience``, ``learning_rate``, ``log_prob_floor``, ``plot_flows``) are a
  :class:`petra.options.FlowFit` on the entry point and flat keywords on the two
  functions below it.  ``threshold_samples`` stays a named keyword everywhere:
  it decides which slots get a flow at all rather than how one trains.
"""

from functools import partial
from pathlib import Path
from typing import Any, Callable, ClassVar, List, Sequence

import numpy as np
import jax
import jax.numpy as jnp
import jax.random as jr
from jax import Array
from jax.typing import ArrayLike

from flowjax.bijections import AbstractBijection, RationalQuadraticSpline, Stack
from flowjax.distributions import Normal, Transformed
from flowjax.flows import masked_autoregressive_flow
from flowjax.train import fit_to_data
from paramax import non_trainable

from petra.flow_utils import DEFAULT_LOG_PROB_FLOOR, stack_flow_log_probs
from petra.options import FlowFit, Initialization
from petra.posterior_chain import PosteriorChain
from petra.relabel import create_relabel_samples, prepare_chain
from petra.utils import (UniformPrior, get_logger, make_uniform_prior,
                         resolve_entry_point_kwargs)
# Re-exported, not used here: this module is where the deprecated flow keywords
# were handled, so both names are imported from it by tests and by user code.
from petra.utils import DEPRECATED_KEYWORDS, resolve_deprecated_kwargs  # noqa: F401

logger = get_logger(__name__)

#: Floor on the standard deviation used by :class:`StandardizationBijection`.
#: Also the value substituted for a non-finite standard deviation, which is what
#: an empty source slot produces.
MIN_STD = 1e-6


class StandardizationBijection(AbstractBijection):
    """
    Simple standardization transform: z = (x - mean) / std

    This is a basic linear transform that centers and scales the data
    without imposing copula constraints, allowing natural label swapping.

    Parameters
    ----------
    mean : float
        Mean to subtract.  A non-finite value (an empty source slot gives
        ``nan``) is replaced by ``0.0``.
    std : float
        Standard deviation to divide by.  A non-finite value is replaced by
        `MIN_STD`, and finite values are floored at `MIN_STD` to avoid a
        division by zero.

    Examples
    --------
    >>> import jax.numpy as jnp
    >>> bijection = StandardizationBijection(2.0, 4.0)
    >>> z, log_det = bijection.inverse_and_log_det(jnp.asarray(6.0))
    >>> float(z), round(float(log_det), 6)
    (1.0, -1.386294)
    >>> empty = StandardizationBijection(np.nan, np.nan)   # an empty source slot
    >>> empty.mean, empty.std
    (0.0, 1e-06)
    """

    mean: float
    std: float
    # Declared as ClassVar so equinox does not treat them as pytree leaves: this
    # transform is univariate and unconditional for every instance.  flowjax
    # declares them as instance attributes on AbstractBijection, hence the
    # ignores; overriding with a ClassVar is the documented flowjax idiom for a
    # fixed-shape bijection.
    cond_shape: ClassVar[None] = None  # type: ignore[misc]
    shape: ClassVar[tuple[int, ...]] = ()  # type: ignore[misc]

    def __init__(self, mean: float, std: float) -> None:
        """
        Build the transform, sanitizing a degenerate mean or standard deviation.

        Parameters
        ----------
        mean : float
            Mean to subtract.  Replaced by ``0.0`` when it is not finite.
        std : float
            Standard deviation to divide by.  Replaced by `MIN_STD` when it is
            not finite, and floored at `MIN_STD` otherwise.
        """
        mean = float(mean)
        std = float(std)
        # NOTE: `max(std, MIN_STD)` alone does NOT catch NaN -- max(nan, 1e-6)
        # is nan -- so an empty slot used to build a bijection whose every
        # output was nan.  Test finiteness explicitly.
        if not np.isfinite(mean):
            logger.warning("StandardizationBijection: non-finite mean (%s) replaced by 0.0.", mean)
            mean = 0.0
        if not np.isfinite(std):
            logger.warning("StandardizationBijection: non-finite std (%s) replaced by %s.", std, MIN_STD)
            std = MIN_STD

        self.mean = mean
        self.std = max(std, MIN_STD)  # Avoid division by zero

    def inverse_and_log_det(self, x: ArrayLike,
                            condition: ArrayLike | None = None) -> tuple[Array, Array]:
        """
        Transform from original space to standardized space.

        Parameters
        ----------
        x : array_like
            A scalar value in the original data space.  This bijection declares
            ``shape = ()``, so ``flowjax`` rejects anything else; several are
            stacked with :class:`flowjax.bijections.Stack` to standardize a
            whole parameter vector.
        condition : array_like, optional
            Unused; this bijection is unconditional.  Accepted because
            ``flowjax.bijections.AbstractBijection`` passes it.

        Returns
        -------
        z : jax.Array
            ``(x - mean) / std``.
        log_det : jax.Array
            Log absolute determinant of the Jacobian, ``-log(std) * x.size``.
            The ``x.size`` factor is 1 for the scalar input flowjax allows, and
            keeps the result correct for an element-wise array call.

        Examples
        --------
        >>> import jax.numpy as jnp
        >>> z, log_det = StandardizationBijection(1.0, 2.0).inverse_and_log_det(
        ...     jnp.asarray(3.0))
        >>> float(z), round(float(log_det), 6)
        (1.0, -0.693147)
        """
        x = jnp.asarray(x)
        z = (x - self.mean) / self.std
        log_det = -jnp.log(self.std) * x.size
        return z, log_det

    def transform_and_log_det(self, z: ArrayLike,
                              condition: ArrayLike | None = None) -> tuple[Array, Array]:
        """
        Transform from standardized space to original space.

        Parameters
        ----------
        z : array_like
            A scalar value in the standardized space; see
            :meth:`inverse_and_log_det` for why it must be scalar.
        condition : array_like, optional
            Unused; this bijection is unconditional.

        Returns
        -------
        x : jax.Array
            ``std * z + mean``.
        log_det : jax.Array
            Log absolute determinant of the Jacobian, ``log(std) * z.size``.

        Examples
        --------
        >>> import jax.numpy as jnp
        >>> x, log_det = StandardizationBijection(1.0, 2.0).transform_and_log_det(
        ...     jnp.asarray(1.0))
        >>> float(x), round(float(log_det), 6)
        (3.0, 0.693147)
        """
        z = jnp.asarray(z)
        x = self.std * z + self.mean
        log_det = jnp.log(self.std) * z.size
        return x, log_det


def make_standardized_flows_fit(chain: np.ndarray,
                                max_num_sources: int,
                                rng_seed: int = 999,
                                threshold_samples: int = 50,
                                plot_flows: bool = False,
                                knots: int = 16,
                                interval: float = 4.0,
                                max_epochs: int = 100,
                                max_patience: int = 5,
                                learning_rate: float = 1e-3,
                                progress: bool = True) -> Callable:
    """
    Create standardized normalizing flows that preserve label swapping.

    Uses simple mean/std standardization instead of copula transforms,
    allowing natural label permutations while maintaining numerical stability.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params_per_source)
        Posterior samples, possibly containing NaNs for missing sources.  Only
        used to build the uniform-prior fallback; the flows themselves are fit
        to whatever chain is passed to the returned function.
    max_num_sources : int
        Maximum number of sources to fit flows for
    rng_seed : int, default 999
        Random seed for reproducibility
    threshold_samples : int, default 50
        A source slot with at most this many usable (non-NaN) samples is not
        worth a flow; it falls back to the uniform prior over the range of the
        whole chain.  This is a statistical decision, not a detail: raising it
        makes more slots uninformative in the assignment.
    plot_flows : bool, default False
        Whether to plot flow comparisons after each fit
    knots : int, default 16
        Number of knots for rational quadratic splines
    interval : float, default 4.0
        Interval size for spline transforms
    max_epochs : int, default 100
        Maximum training epochs per flow.
    max_patience : int, default 5
        Early-stopping patience, in epochs without validation improvement.
    learning_rate : float, default 1e-3
        Adam learning rate used by ``flowjax.train.fit_to_data``.
    progress : bool, default True
        Show the per-flow training progress bar.

    Returns
    -------
    standardized_flows_fit : callable
        Function ``(chain, max_num_sources) -> list of flows`` that refits every
        source on the current labeling.  It carries a ``set_iteration(int)``
        attribute used to label the diagnostic plots.

    Notes
    -----
    Every call retrains every populated slot from scratch.  Relabeling changes
    which samples belong to which slot, so a cached fit is stale even when the
    slot holds the same number of points; an earlier version kept a
    ``training_history`` cache and a ``need_retrain`` flag for this, but both
    were hardcoded to "always retrain" and only duplicated code.
    """
    uniform_prior = make_uniform_prior(chain)

    # One slot per source label.  Both lists are (re)filled on every call to
    # standardized_flows_fit, so there is nothing to precompute here.
    flows: List = [None] * max_num_sources
    transforms: List = [None] * max_num_sources
    current_iteration = [0]

    def set_iteration(iteration_num: int) -> None:
        """Set current iteration, used to label the diagnostic plots."""
        current_iteration[0] = iteration_num

    def make_standardization_transform(chain_entry: np.ndarray) -> Stack:
        """Per-parameter mean/std standardization for one source's samples."""
        standardization_transforms = [
            non_trainable(StandardizationBijection(np.mean(chain_entry[:, j]),
                                                   np.std(chain_entry[:, j])))
            for j in range(chain_entry.shape[1])
        ]
        return Stack(standardization_transforms)

    def fit_chain_entry_standardized(chain_entry: np.ndarray,
                                     flow_key: Array,
                                     fit_seed: int) -> tuple[Transformed, Stack]:
        """
        Fit one source: standardize, train a flow, map back to data space.

        Parameters
        ----------
        chain_entry : ndarray, shape (n_valid, n_params_per_source)
            This source's samples, with the NaN rows already dropped.
        flow_key : jax.Array
            PRNG key used to initialize the flow's parameters.
        fit_seed : int
            Seed for the training key, kept separate from `flow_key` so that
            initialization and optimization do not share randomness.

        Returns
        -------
        flow : flowjax.distributions.Transformed
            Trained flow, expressed in the original data space.
        transform : flowjax.bijections.Stack
            The standardization transform it was wrapped with.
        """
        transform = make_standardization_transform(chain_entry)
        inverse_log_det = jax.jit(jax.vmap(transform.inverse_and_log_det))

        # Transform to standardized space
        x_train, _ = inverse_log_det(chain_entry)

        flow = masked_autoregressive_flow(
            flow_key,
            base_dist=Normal(jnp.zeros(chain_entry.shape[1])),
            transformer=RationalQuadraticSpline(knots=knots, interval=interval),
            invert=True,
            nn_depth=2,
        )

        key = jr.key(fit_seed)
        key, subkey = jr.split(key)

        # Train the flow
        updated_flow, _ = fit_to_data(
            subkey, flow, x_train,
            max_epochs=max_epochs, max_patience=max_patience,
            learning_rate=learning_rate, show_progress=progress,
        )

        # Wrap with transform to map back to original space
        return Transformed(updated_flow, transform), transform

    def standardized_flows_fit(chain: np.ndarray, max_num_sources: int) -> List:
        """
        Fit standardized flows to the chain data.

        Parameters
        ----------
        chain : ndarray, shape (n_samples, n_sources, n_params_per_source)
            The chain under its *current* labeling.  Every populated slot is
            retrained from scratch; see the Notes of
            :func:`make_standardized_flows_fit`.
        max_num_sources : int
            Number of source slots to fit.  Must not exceed the
            `max_num_sources` this fitter was built for.

        Returns
        -------
        flows : list
            One entry per source label: either a trained flow or the shared
            :class:`petra.utils.UniformPrior` fallback.

        Raises
        ------
        ValueError
            If `max_num_sources` exceeds the number of slots this fitter was
            built for.
        """
        if max_num_sources > len(flows):
            raise ValueError(
                f"This fitter was built for at most {len(flows)} sources, got "
                f"max_num_sources={max_num_sources}."
            )
        fit_keys = jr.split(jr.key(rng_seed + 1), len(flows))

        for i in range(max_num_sources):
            chain_entry = chain[:, i, :]
            chain_entry = chain_entry[~np.isnan(chain_entry).any(axis=1)]

            if len(chain_entry) <= threshold_samples:
                logger.info("Source %d has %d usable samples (<= threshold_samples=%d); "
                            "falling back to the uniform prior.",
                            i, len(chain_entry), threshold_samples)
                flows[i] = uniform_prior
                transforms[i] = None
                continue

            logger.debug("Fitting a flow for source %d on %d samples.", i, len(chain_entry))
            flows[i], transforms[i] = fit_chain_entry_standardized(
                chain_entry, fit_keys[i], rng_seed + i
            )

        if plot_flows:
            display_standardized_flows(chain, flows, transforms, current_iteration[0])

        return flows

    # Direct callers can use this hook to label diagnostic plots.
    standardized_flows_fit.set_iteration = set_iteration  # type: ignore[attr-defined]

    return standardized_flows_fit


def display_standardized_flows(chain: np.ndarray,
                               flows: Sequence,
                               transforms: Sequence,
                               iteration: int | None = None) -> None:
    """
    Display comparison plots for standardized flows.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params_per_source)
        The chain the flows were fit to.
    flows : sequence of flow objects
        One entry per source; :class:`petra.utils.UniformPrior` entries are
        skipped, since there is no fit to inspect.
    transforms : sequence
        Standardization transforms matching `flows`; unused entries may be
        ``None``.
    iteration : int, optional
        Iteration number, added to the plot titles when given.
    """
    from matplotlib import pyplot as plt

    key = jr.key(999)

    # Count flows to plot
    n_sources_to_plot = sum(1 for flow in flows if not isinstance(flow, UniformPrior))
    if n_sources_to_plot == 0:
        logger.info("No trained flows to plot (all sources using uniform prior).")
        return

    n_params = chain.shape[2]
    fig, axes = plt.subplots(n_sources_to_plot, n_params, figsize=(4 * n_params, 3 * n_sources_to_plot))
    if n_sources_to_plot == 1:
        axes = np.asarray(axes).reshape(1, -1)
    if n_params == 1:
        axes = np.asarray(axes).reshape(-1, 1)

    plot_row = 0
    for i, flow in enumerate(flows):
        if isinstance(flow, UniformPrior):
            continue

        # Get clean samples for this source
        x = chain[:, i, :]
        x = x[~np.isnan(x).any(axis=1)]
        n_samples = len(x)

        # Sample from flow
        key, subkey = jr.split(key)
        x_samples = flow.sample(subkey, (n_samples,))

        # Plot marginals
        for j in range(x.shape[1]):
            # `axes` was normalized to 2-D above, so index it as 2-D
            # unconditionally.  Special-casing the single-flow branch with
            # `axes[j]` returned a whole ROW of Axes, not an Axes.
            ax = axes[plot_row, j]

            # Original samples
            counts, bins, _ = ax.hist(
                x[:, j], bins=40, density=True, alpha=0.7,
                color='blue', label="Original samples"
            )

            # Flow samples
            ax.hist(
                x_samples[:, j], bins=bins, density=True, alpha=0.7,
                color='red', label="Flow samples"
            )

            # Statistics
            orig_mean, orig_std = np.mean(x[:, j]), np.std(x[:, j])
            flow_mean, flow_std = np.mean(x_samples[:, j]), np.std(x_samples[:, j])

            title = f"Source {i} - Param {j}"
            if iteration is not None:
                title += f" (Iter {iteration})"
            title += f"\nOrig: mean={orig_mean:.3f}, std={orig_std:.3f}"
            title += f"\nFlow: mean={flow_mean:.3f}, std={flow_std:.3f}"

            ax.set_title(title, fontsize=10)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)

        plot_row += 1

    # Overall title
    main_title = "Standardized Flow Comparison"
    if iteration is not None:
        main_title += f" - Iteration {iteration}"
    fig.suptitle(main_title, fontsize=14, y=0.98)

    plt.tight_layout()
    plt.subplots_adjust(top=0.92)
    plt.show()


def standardized_flows_aux_distribution(sample: np.ndarray,
                                        aux_parameters: List,
                                        source_index: int | Sequence[int] | np.ndarray,
                                        floor: float = DEFAULT_LOG_PROB_FLOOR) -> Array:
    """
    Log-densities of every flow, evaluated on every source of one sample.

    Parameters
    ----------
    sample : ndarray, shape (n_sources, n_params_per_source)
        One posterior sample.  NaN rows mark absent sources.
    aux_parameters : list
        Fitted flows, one per source label, as returned by the function
        :func:`make_standardized_flows_fit` builds.
    source_index : int or array-like of int
        Label indices to return rows for.
    floor : float, default `petra.flow_utils.DEFAULT_LOG_PROB_FLOOR`
        Value substituted for a non-finite log-density.

    Returns
    -------
    log_probs : jax.Array, shape (len(source_index), n_sources)
        Row `i` holds the log-densities flow ``source_index[i]`` assigns to each
        source slot of `sample`.

    Examples
    --------
    >>> import numpy as np
    >>> from petra.utils import UniformPrior
    >>> flows = [UniformPrior([0.0], [np.e]), UniformPrior([0.0], [np.e ** 2])]
    >>> sample = np.array([[1.0], [5.0]])
    >>> out = standardized_flows_aux_distribution(sample, flows, np.arange(2))
    >>> np.round(np.asarray(out), 3).tolist()
    [[-1.0, -50.0], [-2.0, -2.0]]
    """
    source_indices = jnp.atleast_1d(np.asarray(source_index))
    all_lp = stack_flow_log_probs(aux_parameters, sample, floor=floor)
    return all_lp[source_indices]


def relabel_standardized_flows(posterior_chain: PosteriorChain,
                               max_num_sources: int | None = None,
                               num_iterations: int = 20,
                               *,
                               eps: float = 1e-6,
                               rng_seed: int = 999,
                               threshold_samples: int = 50,
                               plot_flows: bool = False,
                               knots: int = 16,
                               interval: float = 4.0,
                               max_epochs: int = 100,
                               max_patience: int = 5,
                               learning_rate: float = 1e-3,
                               log_prob_floor: float = DEFAULT_LOG_PROB_FLOOR,
                               checkpoint_dir: str | Path | None = None,
                               resume_from: str | Path | None = None,
                               progress: bool = True) -> PosteriorChain:
    """
    Relabel samples using standardized normalizing flows.

    This approach uses simple standardization instead of copula transforms,
    allowing natural label swapping while maintaining numerical stability.

    Parameters
    ----------
    posterior_chain : PosteriorChain
        Chain to relabel
    max_num_sources : int, optional
        Maximum number of sources (defaults to chain.num_sources)
    num_iterations : int, default 20
        Number of relabeling iterations
    eps : float, default 1e-6
        Clip bound on the inclusion probabilities used *inside* the cost matrix,
        keeping them inside ``[eps, 1 - eps]`` so the logarithms there stay
        finite.  ``1e-6`` throughout petra; this relabeler used to default to
        ``1e-2``, which made its costs incomparable with the other methods'.
        It does not reach the returned ``prob_in_model``; see Notes.
    rng_seed : int, default 999
        Seed for the flow initialization and training.
    threshold_samples : int, default 50
        Slots with at most this many usable samples fall back to the uniform
        prior; see :func:`make_standardized_flows_fit`.
    plot_flows : bool, default False
        Whether to plot flow quality
    knots : int, default 16
        Number of spline knots
    interval : float, default 4.0
        Spline interval size
    max_epochs : int, default 100
        Maximum training epochs per flow.
    max_patience : int, default 5
        Early-stopping patience for each flow fit.
    learning_rate : float, default 1e-3
        Adam learning rate for each flow fit.
    log_prob_floor : float, default `petra.flow_utils.DEFAULT_LOG_PROB_FLOOR`
        Value substituted for a non-finite flow log-density.  It sets how hard
        the assignment refuses a label, so it must match across entry points for
        their costs to be comparable.
    checkpoint_dir : str or Path, optional
        Directory to save a checkpoint of the chain after every iteration.
    resume_from : str or Path, optional
        Checkpoint file, or directory of checkpoints, to resume from.  See
        :func:`petra.relabel.load_checkpoint`.
    progress : bool, default True
        Show progress bars, both over samples and over flow training epochs.

    Returns
    -------
    relabeled_chain : PosteriorChain
        Relabeled chain with standardized flows.  Its ``prob_in_model`` is
        recomputed from the returned samples *without* clipping, so that
        ``find_prob_in_model(relabeled_chain.get_chain(), max_num_sources,
        eps=0)`` reproduces it exactly.

    Notes
    -----
    `eps` governs only the clipping applied inside the cost matrix during
    iteration, where a probability of exactly 0 or 1 would make a ``log`` term
    infinite.  Only the returned array is unclipped; see
    :func:`petra.relabel.run_relabeling_loop`.
    """
    # Create standardized flow fitter
    standardized_flows_fit = make_standardized_flows_fit(
        posterior_chain.chain,
        max_num_sources or posterior_chain.num_sources,
        rng_seed=rng_seed,
        threshold_samples=threshold_samples,
        plot_flows=plot_flows,
        knots=knots,
        interval=interval,
        max_epochs=max_epochs,
        max_patience=max_patience,
        learning_rate=learning_rate,
        progress=progress,
    )

    # Create relabeling function
    # Note: no filter_jit wrapper -- it causes JAX compilation issues with flows.
    relabel_samples = create_relabel_samples(
        standardized_flows_fit,
        partial(standardized_flows_aux_distribution, floor=log_prob_floor),
        eps=eps
    )

    # Perform relabeling
    return relabel_samples(
        posterior_chain,
        max_num_sources=max_num_sources,
        num_iterations=num_iterations,
        checkpoint_dir=checkpoint_dir,
        resume_from=resume_from,
        progress=progress,
    )


def make_catalog_standardized_flows(posterior_chain: PosteriorChain,
                                    max_num_sources: int,
                                    *,
                                    num_iterations: int = 50,
                                    initialization_param_index: int | None = 0,
                                    shuffle_seed: int | None = None,
                                    rng_seed: int = 999,
                                    checkpoint_dir: str | Path | None = None,
                                    resume_from: str | Path | None = None,
                                    progress: bool = True,
                                    eps: float = 1e-6,
                                    threshold_samples: int = 50,
                                    initialization: Initialization | None = None,
                                    flow_fit: FlowFit | None = None,
                                    **flat_keywords: Any) -> PosteriorChain:
    """
    Create catalog using standardized normalizing flows.

    Uses simple mean/std standardization instead of copula transforms,
    preserving natural label swapping behavior while benefiting from
    improved numerical stability through standardization.

    By default the labels are first initialized with a fast multivariate normal
    relabeling step, itself preceded by a univariate one, which avoids the
    cold-start problem where flows are trained on randomly mixed source slots.
    The two passes are switched independently: ``init_with_mv_normal=False`` --
    or ``initialization=Initialization(with_mv_normal=False)`` -- drops the
    multivariate pass, ``initialization_param_index=None`` drops the univariate
    one, and both together go straight to the flows.

    The keywords fall into two groups.  Everything from `num_iterations` to
    `threshold_samples` is the shared ``make_catalog_*`` contract, spelled and
    defaulted the same way by every entry point; `initialization` and `flow_fit`
    group the settings of the two separable concerns behind it.

    Parameters
    ----------
    posterior_chain : PosteriorChain
        Chain to process
    max_num_sources : int
        Target number of sources.  Must be at least ``chain.num_sources``.
    num_iterations : int, default 50
        Maximum number of relabeling iterations.  One iteration retrains every
        populated source slot's flow from scratch -- up to
        ``flow_fit.max_epochs`` epochs each, with no cache, because relabeling
        changes which samples belong to which slot and a kept fit would be
        stale -- and then solves one Hungarian assignment per sample against the
        refitted flows.  An iteration therefore costs one neural-network fit per
        occupied slot, which is why the default is 50 rather than the 200 of
        :func:`~petra.make_catalog.make_catalog_mv_normal`.  The loop stops early
        as soon as an iteration fails to lower the assignment cost, so this is a
        ceiling, not a schedule.
    initialization_param_index : int or None, default 0
        Index of the parameter for the univariate normal pre-initialization.
        ``None`` skips the univariate step and goes straight to the MV normal
        one.  It is the only thing that decides whether that step runs:
        ``initialization.with_mv_normal`` switches the multivariate pass alone
        (see Notes).  It names a column of *your* chain -- which parameter
        separates the sources -- rather than tuning the initializer, which is
        why it is here rather than on `initialization`.
    shuffle_seed : int, optional
        Seed for random shuffling of chain entries (for reproducibility)
    rng_seed : int, default 999
        Seed for the flow initialization and training.  Previously hardcoded to
        999 inside the module, which made the run-to-run variance of this entry
        point impossible to measure.
    checkpoint_dir : str or Path, optional
        Directory to save a checkpoint of the chain after every iteration of
        the flow relabeling.
    resume_from : str or Path, optional
        Checkpoint file, or directory of checkpoints, to resume the flow
        relabeling from.  The initialization steps are skipped when resuming,
        since the checkpoint already reflects them.
    progress : bool, default True
        Show progress bars, both over samples and over flow training epochs.
    eps : float, default 1e-6
        Clip bound on the inclusion probabilities used *inside* the cost matrix,
        keeping them inside ``[eps, 1 - eps]`` so the logarithms there stay
        finite.  The same value as every other ``make_catalog_*`` entry point,
        so the recorded costs are comparable between methods.  It does not reach
        the returned ``prob_in_model``; see Notes.
    threshold_samples : int, default 50
        Slots with at most this many usable samples fall back to the uniform
        prior; see :func:`make_standardized_flows_fit`.  It decides which slots
        get a flow at all rather than how one trains, which is why it is here
        rather than on `flow_fit`.
    initialization : Initialization, optional
        The pre-relabeling passes -- ``with_mv_normal`` switches the
        multivariate one and ``num_iterations`` bounds each pass that runs.
        The univariate pass is switched by `initialization_param_index`
        instead, not by anything on this object.  ``None`` means
        ``Initialization()``.
    flow_fit : FlowFit, optional
        Flow training hyperparameters -- ``knots``, ``interval``,
        ``max_epochs``, ``max_patience``, ``learning_rate``,
        ``log_prob_floor``, ``plot_flows``.  ``None`` means ``FlowFit()``.

    Returns
    -------
    relabeled_chain : PosteriorChain
        Relabeled chain using standardized flows.  Its ``prob_in_model`` is
        recomputed from the returned samples *without* clipping, so that
        ``find_prob_in_model(relabeled_chain.get_chain(), max_num_sources,
        eps=0)`` reproduces it exactly.

    Other Parameters
    ----------------
    init_with_mv_normal, init_num_iterations
        The fields of `initialization`, still accepted as flat keywords with
        unchanged meaning and no warning.  They keep the same spelling on all
        four ``make_catalog_*`` entry points, so a call can still be moved
        between methods without being rewritten.
    knots, interval, max_epochs, max_patience, learning_rate, log_prob_floor, plot_flows
        The fields of `flow_fit`, likewise.
    n_phases : int, optional
        Deprecated alias for `num_iterations`.
    mv_normal_init : bool, optional
        Deprecated alias for `init_with_mv_normal`.
    mv_normal_init_iterations : int, optional
        Deprecated alias for `init_num_iterations`.

    Raises
    ------
    ValueError
        If `max_num_sources` is smaller than the number of entries in the chain,
        if `initialization_param_index` is neither ``None`` nor a column of the
        chain, or if a flat keyword carries a value its options class rejects.
    TypeError
        If an unknown keyword argument is supplied, or if an options object is
        passed alongside a flat keyword that would overwrite one of its fields.

    Notes
    -----
    `eps` governs only the clipping applied inside the cost matrix during
    iteration, where a probability of exactly 0 or 1 would make a ``log`` term
    infinite.  Only the returned array is unclipped; see
    :func:`petra.relabel.run_relabeling_loop`.

    An options object and one of its flat fields is a :class:`TypeError`, never
    a merge -- ``FlowFit(knots=8)`` alongside ``max_epochs=20`` would otherwise
    raise the question of which defaults the object contributes, and the answer
    would have to be remembered rather than read.

    :func:`relabel_standardized_flows` and :func:`make_standardized_flows_fit`
    keep their flat signatures, so `flow_fit` is unpacked here rather than pushed
    down, preserving direct calls from existing scripts.

    Changed in 1.1: ``init_with_mv_normal`` no longer switches the univariate
    pass off as well.  ``init_with_mv_normal=False`` -- equivalently
    ``initialization=Initialization(with_mv_normal=False)`` or the deprecated
    ``mv_normal_init=False`` -- together with an `initialization_param_index`
    that is not ``None`` (the default is 0) used to skip *both* initialization
    passes here, while
    :func:`petra.bayesian_gaussian.make_catalog_bayesian_gaussian` skipped only
    the multivariate one for the same pair of keywords.  All three initialized entry points
    now go through :func:`petra.initialization.run_initialization_passes` and
    skip only the multivariate pass; add ``initialization_param_index=None`` to
    reproduce a run made with an older version.

    Examples
    --------
    A three-source chain, relabeled without any flow training: with
    ``threshold_samples`` above the number of samples every slot falls back to
    the uniform prior, which keeps the example fast.

    >>> import numpy as np
    >>> from petra.options import FlowFit, Initialization
    >>> from petra.posterior_chain import PosteriorChain
    >>> rng = np.random.default_rng(0)
    >>> chain_array = rng.normal(size=(20, 3, 1)) + np.array([[0.0], [5.0], [10.0]])
    >>> pc = PosteriorChain(chain_array, 3, 1, True, None, {})
    >>> flat = make_catalog_standardized_flows(
    ...     pc,
    ...     max_num_sources=3,
    ...     num_iterations=2,
    ...     init_num_iterations=5,
    ...     knots=4,
    ...     threshold_samples=1000,
    ...     progress=False,
    ... )
    >>> flat.chain.shape
    (20, 3, 1)

    Spelling the same call with the settings objects is the same run:

    >>> grouped = make_catalog_standardized_flows(
    ...     pc,
    ...     max_num_sources=3,
    ...     num_iterations=2,
    ...     initialization=Initialization(num_iterations=5),
    ...     flow_fit=FlowFit(knots=4),
    ...     threshold_samples=1000,
    ...     progress=False,
    ... )
    >>> bool(np.array_equal(flat.get_chain(), grouped.get_chain()))
    True
    """
    resolved, options = resolve_entry_point_kwargs(
        make_catalog_standardized_flows, flat_keywords,
        options={"initialization": initialization, "flow_fit": flow_fit},
        current={"num_iterations": num_iterations},
    )
    # The resolved mapping has to be read back out. `num_iterations` (the
    # replacement for `n_phases`) used to be left in the dict, so that alias
    # warned and was then silently dropped -- the caller got the default instead
    # of the value they passed.
    num_iterations = resolved.get("num_iterations", num_iterations)
    init: Initialization = options["initialization"]
    fit: FlowFit = options["flow_fit"]

    from petra.make_catalog import relabel_mv_normal
    from petra.initialization import relabel_univariate_normal, run_initialization_passes

    # shuffle the entries and make sure the chain has the right shape
    posterior_chain = prepare_chain(posterior_chain, max_num_sources, shuffle_seed=shuffle_seed)

    # The preamble is shared across the initialized catalog builders: this one had
    # drifted from `make_catalog_bayesian_gaussian`'s, so `init_with_mv_normal`
    # decided both passes here and only one there.
    posterior_chain = run_initialization_passes(
        posterior_chain,
        max_num_sources,
        univariate_relabeler=relabel_univariate_normal,
        mv_normal_relabeler=relabel_mv_normal,
        with_mv_normal=init.with_mv_normal,
        param_index=initialization_param_index,
        num_iterations=init.num_iterations,
        resume_from=resume_from,
        progress=progress,
    )

    # Refine using standardized flows
    logger.info("Refining with standardized normalizing flows.")
    # The relabeler keeps its flat signature -- it is what every
    # existing script call -- so the options object is unpacked here rather than
    # pushed down.
    return relabel_standardized_flows(
        posterior_chain,
        max_num_sources=max_num_sources,
        num_iterations=num_iterations,
        eps=eps,
        rng_seed=rng_seed,
        threshold_samples=threshold_samples,
        plot_flows=fit.plot_flows,
        knots=fit.knots,
        interval=fit.interval,
        max_epochs=fit.max_epochs,
        max_patience=fit.max_patience,
        learning_rate=fit.learning_rate,
        log_prob_floor=fit.log_prob_floor,
        checkpoint_dir=checkpoint_dir,
        resume_from=resume_from,
        progress=progress,
    )
