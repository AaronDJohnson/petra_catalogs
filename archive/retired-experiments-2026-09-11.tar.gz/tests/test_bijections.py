"""
Behaviour of the standalone bijections in :mod:`petra.bijections`.

The round-trip / log-determinant invariants that every bijection must satisfy
live in ``tests/test_invariants.py``; this file covers the properties that are
specific to these transforms:

* the empirical CDF stays finite *outside* the training range -- flat, because
  the clamps swamp its exponential tails, but never 0 or 1;
* it degrades gracefully when the spline cannot interpolate;
* the bounded transforms clamp instead of diverging at their bounds;
* ``NormalToUniformInverseStandardize`` really is ``NormalToUniform``, which its
  docstring claims and which nothing else would notice if it stopped being true.
"""

import jax.numpy as jnp
import numpy as np
import pytest

from petra.bijections import (EmpiricalMarginalToGaussian, InverseStandardize,
                              NormalToUniform, NormalToUniformInverseStandardize,
                              make_empirical_cdf_spline)


# ---------------------------------------------------------------------------
# make_empirical_cdf_spline
# ---------------------------------------------------------------------------

def test_empirical_cdf_returns_grid_order_not_sorted_order():
    """`cdf_vals` comes back in the order `x_grid` was given, not sorted."""
    samples = np.linspace(0.0, 1.0, 101)
    grid = np.array([0.75, 0.25, 0.5])
    cdf_values, _, _ = make_empirical_cdf_spline(grid, samples)
    assert cdf_values.shape == grid.shape
    assert cdf_values[0] > cdf_values[2] > cdf_values[1]


def test_empirical_cdf_tails_are_bounded_away_from_zero_and_one():
    """
    Outside the data the CDF is finite, flat, and never exactly 0 or 1.

    Flat is what the code actually does, and the docstring says so: the
    exponential extrapolation is at most `min_eps`, and the final clip raises it
    back to `min_eps`.  The property that matters downstream is the one asserted
    here -- a log-density built on this CDF cannot be infinite.
    """
    samples = np.linspace(0.0, 1.0, 101)
    grid = np.linspace(0.0, 1.0, 21)
    _, cdf_fn, pdf_fn = make_empirical_cdf_spline(grid, samples)

    below = cdf_fn(np.array([-5.0, -0.5, -0.01]))
    above = cdf_fn(np.array([1.01, 1.5, 6.0]))
    assert np.all(below == 1e-7)
    assert np.all(above == 1.0 - 1e-7)
    assert np.all(pdf_fn(np.array([-5.0, 6.0])) > 0.0)

    # The density does still decay over the first tail scale, before its floor.
    assert pdf_fn(np.array([-0.01]))[0] > pdf_fn(np.array([-0.1]))[0] >= 1e-7


def test_empirical_cdf_is_finite_where_the_spline_cannot_extrapolate():
    """
    A point inside the data range but outside the grid must not come back NaN.

    ``PchipInterpolator(..., extrapolate=False)`` returns NaN there; the fallback
    to linear interpolation used to be written as a chained assignment
    (``y[inside][nan] = ...``), which writes into a temporary and left the NaN in
    place -- and a NaN CDF becomes a NaN log-density in the cost matrix.
    """
    samples = np.linspace(0.0, 10.0, 201)
    grid = np.linspace(2.0, 8.0, 25)          # deliberately narrower than the data
    _, cdf_fn, pdf_fn = make_empirical_cdf_spline(grid, samples)

    probe = np.array([0.5, 1.0, 5.0, 9.0, 9.5])   # first two and last two are off-grid
    values = cdf_fn(probe)
    assert np.all(np.isfinite(values))
    assert np.all((values > 0.0) & (values < 1.0))
    assert np.all(np.isfinite(pdf_fn(probe)))


def test_empirical_cdf_falls_back_to_linear_interpolation(monkeypatch, caplog):
    """
    If the monotonic spline cannot be built, the CDF still works -- and says so.

    ``interpax`` is constructed with ``check=False`` and so does not currently
    raise on a degenerate grid, but the fallback is the difference between a
    usable transform and an exception in the middle of a fit, so it is pinned
    here rather than left to be discovered.
    """
    def explode(*args, **kwargs):
        raise ValueError("duplicated grid point")

    monkeypatch.setattr("petra.bijections.PchipInterpolator", explode)

    samples = np.linspace(0.0, 1.0, 101)
    with caplog.at_level("WARNING", logger="petra.bijections"):
        _, cdf_fn, _ = make_empirical_cdf_spline(np.linspace(0.0, 1.0, 11), samples)
    assert "falling back to linear interpolation" in caplog.text

    values = cdf_fn(np.array([0.0, 0.25, 0.5, 0.75, 1.0]))
    assert np.all(np.diff(values) >= 0.0)
    assert np.all((values > 0.0) & (values < 1.0))


def test_empirical_cdf_accepts_a_scalar():
    """The closures are used elementwise, so a 0-d input must work."""
    samples = np.linspace(0.0, 1.0, 101)
    _, cdf_fn, pdf_fn = make_empirical_cdf_spline(np.linspace(0.0, 1.0, 11), samples)
    assert 0.0 < float(cdf_fn(np.float64(0.5))) < 1.0
    assert float(pdf_fn(np.float64(0.5))) > 0.0


def test_empirical_cdf_honours_an_explicit_tail_scale():
    """
    An explicit `tail_scale` sets the tail density exactly, down to its floor.

    This pins the one part of the extrapolation that survives the clamps, and
    with it the meaning of the parameter: a distance of one `tail_scale` costs a
    factor of ``e`` in density.
    """
    samples = np.linspace(0.0, 1.0, 101)
    grid = np.linspace(0.0, 1.0, 21)
    tail_scale, min_eps = 0.1, 1e-7
    _, _, pdf_fn = make_empirical_cdf_spline(grid, samples, tail_scale=tail_scale)

    for distance in (0.05, 0.15, 0.3):
        expected = (min_eps / tail_scale) * np.exp(-distance / tail_scale)
        assert pdf_fn(np.array([-distance]))[0] == pytest.approx(max(expected, min_eps))
        assert pdf_fn(np.array([1.0 + distance]))[0] == pytest.approx(max(expected, min_eps))


# ---------------------------------------------------------------------------
# EmpiricalMarginalToGaussian
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def empirical_bijection() -> EmpiricalMarginalToGaussian:
    """A seeded transform built from 500 standard normal draws."""
    return EmpiricalMarginalToGaussian(np.random.default_rng(0).normal(size=500))


def test_empirical_marginal_maps_its_own_samples_to_a_standard_normal(empirical_bijection):
    """The point of the transform: the training data comes out roughly N(0, 1)."""
    samples = np.random.default_rng(0).normal(size=500)
    latent = np.array([float(empirical_bijection.inverse(jnp.asarray(float(s))))
                       for s in samples])
    assert np.all(np.isfinite(latent))
    assert abs(latent.mean()) < 0.15
    assert 0.8 < latent.std() < 1.25


def test_empirical_marginal_is_monotone_inside_and_clamped_outside(empirical_bijection):
    """
    Strictly increasing inside the data, and clamped -- not infinite -- outside.

    The clamp is the documented limitation: every point below the data maps to
    the same ``Phi^{-1}(min_eps)``.  What must never happen is a NaN or an
    infinity, which is what an unclamped empirical CDF would give.
    """
    inside = np.linspace(empirical_bijection.data_min + 0.1,
                         empirical_bijection.data_max - 0.1, 9)
    latent = [float(empirical_bijection.inverse(jnp.asarray(float(x)))) for x in inside]
    assert np.all(np.isfinite(latent))
    assert np.all(np.diff(latent) > 0.0)

    outside = [empirical_bijection.data_min - 5.0, empirical_bijection.data_min - 0.5,
               empirical_bijection.data_max + 0.5, empirical_bijection.data_max + 5.0]
    tails = [float(empirical_bijection.inverse(jnp.asarray(x))) for x in outside]
    assert np.all(np.isfinite(tails))
    assert tails[0] == pytest.approx(tails[1]) and tails[1] < latent[0]
    assert tails[2] == pytest.approx(tails[3]) and tails[3] > latent[-1]


def test_empirical_marginal_tail_decay_shortens_the_tail_scale():
    """`tail_decay` divides the IQR, so a larger value gives a faster decay."""
    samples = np.random.default_rng(1).normal(size=300)
    assert (EmpiricalMarginalToGaussian(samples, tail_decay=8.0).tail_scale
            <= EmpiricalMarginalToGaussian(samples, tail_decay=0.5).tail_scale)


def test_empirical_marginal_resolution_follows_num_points():
    """`num_points` is the resolution of the stored CDF."""
    samples = np.random.default_rng(2).normal(size=300)
    bijection = EmpiricalMarginalToGaussian(samples, num_points=37)
    assert bijection.x_grid.shape == (37,)
    assert bijection.raw_cdf.shape == (37,)


# ---------------------------------------------------------------------------
# The bounded and location-scale transforms
# ---------------------------------------------------------------------------

def test_normal_to_uniform_stays_inside_its_bounds():
    """Whatever the latent value, the data-space value is inside ``[a, b]``."""
    bijection = NormalToUniform(-2.0, 3.0)
    for z in np.linspace(-12.0, 12.0, 25):
        x = float(bijection.transform(jnp.asarray(float(z))))
        assert -2.0 <= x <= 3.0


def test_normal_to_uniform_clamps_out_of_range_points():
    """A point outside ``[a, b]`` gives a finite latent value, not an infinite one."""
    bijection = NormalToUniform(-2.0, 3.0)
    for x in (-50.0, -2.0, 3.0, 50.0):
        z, log_det = bijection.inverse_and_log_det(jnp.asarray(x))
        assert np.isfinite(float(z)) and np.isfinite(float(log_det))


def test_inverse_standardize_matches_its_formula():
    """``transform`` un-standardizes; ``inverse`` standardizes."""
    bijection = InverseStandardize(1.5, 2.0)
    assert float(bijection.transform(jnp.asarray(2.0))) == pytest.approx(5.5)
    assert float(bijection.inverse(jnp.asarray(5.5))) == pytest.approx(2.0, abs=1e-6)


def test_normal_to_uniform_inverse_standardize_is_normal_to_uniform():
    """
    The standardization cancels exactly, as the class docstring states.

    ``z`` enters only through ``mean + std * z``, which is divided straight back
    out, so both directions and both log-determinants are independent of `mean`
    and `std`.  If that ever stops being true the docstring is wrong.
    """
    plain = NormalToUniform(-2.0, 3.0)
    for mean, std in [(0.0, 1.0), (7.0, 0.25), (-3.0, 12.0)]:
        sandwich = NormalToUniformInverseStandardize(-2.0, 3.0, mean, std)
        for z in np.linspace(-2.5, 2.5, 11):
            latent = jnp.asarray(float(z))
            x_plain, det_plain = plain.transform_and_log_det(latent)
            x_sandwich, det_sandwich = sandwich.transform_and_log_det(latent)
            assert float(x_sandwich) == pytest.approx(float(x_plain), abs=1e-5)
            assert float(det_sandwich) == pytest.approx(float(det_plain), abs=1e-5)

            data = jnp.asarray(float(x_plain))
            assert float(sandwich.inverse(data)) == pytest.approx(float(plain.inverse(data)),
                                                                  abs=1e-5)
