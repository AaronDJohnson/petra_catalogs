"""
The ``merge_sources`` argument contract and the pieces of the candidate search.

``merge_sources`` was the last public entry point whose 13 hyperparameters were
positional-or-keyword, which made ``merge_sources(pc, 1.0, 0, 6.0, 10.0, 0.1)``
both legal and unreadable.  They are keyword-only now; the old spelling still
works for one release, and these tests pin both halves of that promise --
including the table that maps positions back to names, which is easy to let
drift away from the signature it describes.

The candidate search itself was one 150-line function; it is now three named
steps, tested here on hand-built chains rather than through a flow fit.

The accept/reject decision is the point of the module, and only its accept side
used to be exercised: if the comparison were inverted, every merge would still
have been tested and nothing would have failed.  Both sides are pinned here, on
chains built so that the answer follows from the data rather than from how well
a flow happened to converge -- see `always_present_pair`.
"""

import inspect
import logging
import warnings

import numpy as np
import pytest

from petra.merge_sources import (
    MERGE_SOURCES_LEGACY_POSITIONAL,
    _pair_merge_candidates,
    _source_frequency_stats,
    _veto_broad_sources,
    compute_pair_cost,
    identify_merge_candidates,
    merge_pair_in_chain,
    merge_sources,
)
from petra.posterior_chain import PosteriorChain
from petra.utils import UniformPrior, frequency_bin_width

DELTA_FREQ = frequency_bin_width(1.0)

#: Flow settings small enough to fit three flows in a unit test.  The decisions
#: asserted below hold across flow sizes and seeds by construction, so these
#: only have to be cheap, not good.
FAST_FLOW = dict(min_valid_samples=20, threshold_samples=20, knots=4, max_epochs=60,
                 flow_layers=2, patience=5, rng_seed=0, progress=False)


@pytest.fixture
def two_slot_chain():
    """Two slots two bins apart that are never present in the same sample."""
    rng = np.random.default_rng(0)
    chain = np.full((200, 2, 1), np.nan)
    chain[:100, 0, 0] = 1e-3 + 0.1 * DELTA_FREQ * rng.normal(size=100)
    chain[100:, 1, 0] = 1e-3 + 2 * DELTA_FREQ + 0.1 * DELTA_FREQ * rng.normal(size=100)
    return chain


def always_present_pair(n_samples: int = 120, seed: int = 0) -> PosteriorChain:
    """
    Build two narrow sources, four bins apart, both present in every sample.

    This is the shape of a pair that must *not* be merged, and it says so
    without appealing to the quality of any fit.  Neither slot ever goes
    missing, so the one-source model saves nothing on the occupancy terms; and
    the two clusters do not overlap, so the flow fit to their union is a
    half-and-half mixture that assigns each point about half the density its own
    flow does.  The one-source model therefore loses about ``log 2`` per sample
    and cannot win.

    Parameters
    ----------
    n_samples : int, default 120
        Number of posterior samples.
    seed : int, default 0
        Seed for the draws.

    Returns
    -------
    posterior_chain : PosteriorChain
        Trans-dimensional chain of shape ``(n_samples, 2, 1)``; the parameter is
        frequency in Hz.
    """
    rng = np.random.default_rng(seed)
    chain = np.empty((n_samples, 2, 1))
    chain[:, 0, 0] = 1e-3 + 0.5 * DELTA_FREQ * rng.normal(size=n_samples)
    chain[:, 1, 0] = 1e-3 + 4 * DELTA_FREQ + 0.5 * DELTA_FREQ * rng.normal(size=n_samples)
    return PosteriorChain(chain, 2, 1, trans_dimensional=True)


def three_disjoint_slots(n_samples: int = 90, seed: int = 1) -> PosteriorChain:
    """
    Build three narrow sources two bins apart, no two of which ever co-occur.

    All three pairs are merge candidates and every pair would be merged if it
    were reached, so whichever pair is evaluated first leaves the other two
    naming a slot that has already been merged.

    Parameters
    ----------
    n_samples : int, default 90
        Number of posterior samples, split equally between the three slots.
    seed : int, default 1
        Seed for the draws.

    Returns
    -------
    posterior_chain : PosteriorChain
        Trans-dimensional chain of shape ``(n_samples, 3, 1)``.
    """
    rng = np.random.default_rng(seed)
    chain = np.full((n_samples, 3, 1), np.nan)
    which = np.arange(n_samples) % 3
    for i in range(3):
        rows = which == i
        chain[rows, i, 0] = (1e-3 + 2 * i * DELTA_FREQ
                             + 0.3 * DELTA_FREQ * rng.normal(size=int(rows.sum())))
    return PosteriorChain(chain, 3, 1, trans_dimensional=True)


# ---------------------------------------------------------------------------
# The keyword-only contract
# ---------------------------------------------------------------------------

def test_legacy_positional_table_matches_the_signature():
    """
    The table is the only thing that says which position meant which keyword.

    If a parameter is renamed, reordered or given a new default and the table is
    not updated with it, every legacy positional call silently starts feeding
    values into the wrong parameters -- so the table is checked against the real
    signature rather than trusted.
    """
    parameters = list(inspect.signature(merge_sources).parameters.values())
    keyword_only = [p for p in parameters if p.kind is p.KEYWORD_ONLY]

    assert [p.name for p in keyword_only] == [name for name, _ in
                                              MERGE_SOURCES_LEGACY_POSITIONAL]
    assert [p.default for p in keyword_only] == [default for _, default in
                                                 MERGE_SOURCES_LEGACY_POSITIONAL]

    # Only the chain and the observation time may still be passed positionally.
    positional = [p for p in parameters if p.kind is p.POSITIONAL_OR_KEYWORD]
    assert [p.name for p in positional] == ["posterior_chain", "obs_time_yrs"]


def test_legacy_positional_call_still_works_and_warns(two_slot_chain):
    """The old spelling must keep producing the old answer, loudly."""
    pc = PosteriorChain(two_slot_chain, 2, 1, trans_dimensional=True)

    with pytest.warns(DeprecationWarning, match="freq_param_index"):
        # merge_sources(pc, obs_time_yrs, freq_param_index, max_freq_std_bins,
        #               max_merge_distance_bins) -- the pre-1.1 call.
        legacy = merge_sources(pc, 1.0, 0, 6.0, 1.0)

    modern = merge_sources(pc, 1.0, freq_param_index=0, max_freq_std_bins=6.0,
                           max_merge_distance_bins=1.0, progress=False)

    assert np.array_equal(legacy.chain, modern.chain, equal_nan=True)


def test_positional_and_keyword_for_the_same_parameter_is_rejected(two_slot_chain):
    """An old-style position must not silently overrule an explicit keyword."""
    pc = PosteriorChain(two_slot_chain, 2, 1, trans_dimensional=True)
    with pytest.raises(TypeError, match="not both"):
        with pytest.warns(DeprecationWarning):
            # max_freq_std_bins is the second legacy position *and* a keyword here.
            merge_sources(pc, 1.0, 0, 2.0, max_freq_std_bins=2.0, progress=False)


def test_too_many_positional_arguments_is_rejected(two_slot_chain):
    pc = PosteriorChain(two_slot_chain, 2, 1, trans_dimensional=True)
    with pytest.raises(TypeError, match="positional arguments"):
        merge_sources(pc, 1.0, *range(len(MERGE_SOURCES_LEGACY_POSITIONAL) + 1))


# ---------------------------------------------------------------------------
# The three steps of the candidate search
# ---------------------------------------------------------------------------

def test_frequency_stats_ignore_undersampled_slots():
    chain = np.full((10, 2, 1), np.nan)
    chain[:, 0, 0] = np.arange(10.0)
    chain[:3, 1, 0] = 1.0
    mean_freq, std_freq, well_sampled = _source_frequency_stats(
        chain, freq_param_index=0, min_valid_samples=5)

    assert well_sampled.tolist() == [True, False]
    assert mean_freq[0] == pytest.approx(4.5)
    assert np.isnan(mean_freq[1]) and np.isnan(std_freq[1])


def test_veto_leaves_undersampled_slots_alone():
    """
    A slot with too few samples has a NaN standard deviation.

    ``nan > threshold`` is False, so a naive veto would leave that slot in the
    "considered" set purely because its statistics are missing.  The veto must
    only ever remove slots, never add one back.
    """
    std_freq = np.array([1.0, np.nan, 9.0])
    well_sampled = np.array([True, False, True])
    assert _veto_broad_sources(std_freq, well_sampled, 5.0).tolist() == [True, False, False]


def test_pairing_vetoes_co_occurring_slots():
    """Two slots that are usually present together are two sources, not one."""
    chain = np.full((10, 2, 1), np.nan)
    chain[:, 0, 0] = 1.0
    chain[:, 1, 0] = 1.1          # present in every sample alongside slot 0
    mean_freq = np.array([1.0, 1.1])
    considered = np.array([True, True])

    assert _pair_merge_candidates(chain, mean_freq, considered, freq_param_index=0,
                                  max_merge_distance=1.0, max_co_occurrence=0.1) == []
    # ... and it is the co-occurrence, not the distance, that vetoed the pair.
    assert _pair_merge_candidates(chain, mean_freq, considered, freq_param_index=0,
                                  max_merge_distance=1.0, max_co_occurrence=1.0) != []


def test_candidate_search_is_unchanged_by_the_decomposition(two_slot_chain):
    """The three steps compose back into the documented behaviour."""
    assert identify_merge_candidates(two_slot_chain, obs_time_yrs=1.0) == [(0, 1)]
    assert identify_merge_candidates(two_slot_chain, obs_time_yrs=1.0,
                                     max_merge_distance_bins=1.0) == []
    assert identify_merge_candidates(two_slot_chain, obs_time_yrs=1.0,
                                     min_valid_samples=150) == []


# ---------------------------------------------------------------------------
# The prob_in_model deprecation on identify_merge_candidates
# ---------------------------------------------------------------------------

def test_identify_accepts_the_old_positional_prob_in_model(two_slot_chain):
    """``identify_merge_candidates(chain, prob_in_model, obs_time_yrs)`` still works."""
    with pytest.warns(DeprecationWarning, match="no longer takes prob_in_model"):
        assert identify_merge_candidates(two_slot_chain, np.array([0.5, 0.5]), 1.0) == [(0, 1)]


def test_identify_accepts_prob_in_model_by_keyword(two_slot_chain):
    with pytest.warns(DeprecationWarning, match="deprecated"):
        assert identify_merge_candidates(two_slot_chain, obs_time_yrs=1.0,
                                         prob_in_model=np.array([0.5, 0.5])) == [(0, 1)]


def test_identify_rejects_more_than_one_extra_positional(two_slot_chain):
    with pytest.raises(TypeError, match="at most 3 positional arguments"):
        identify_merge_candidates(two_slot_chain, np.array([0.5, 0.5]), 1.0, 0)


def test_a_pair_whose_flows_cannot_be_fit_is_skipped(two_slot_chain):
    """
    A candidate pair with too little data is left alone, not merged on a guess.

    ``fit_source_flow`` returns None below `threshold_samples`, and all three
    flows -- the two singles and the merged one -- must exist before the two
    hypotheses can be compared at all.
    """
    pc = PosteriorChain(two_slot_chain, 2, 1, trans_dimensional=True)
    result = merge_sources(pc, obs_time_yrs=1.0, threshold_samples=10 ** 6,
                           progress=False)
    assert np.array_equal(result.chain, pc.chain, equal_nan=True)


# ---------------------------------------------------------------------------
# The accept/reject decision itself
# ---------------------------------------------------------------------------

def test_a_pair_that_is_better_as_two_sources_is_kept_separate(caplog):
    """
    The rejection branch: two sources that co-occur always are not one source.

    `max_co_occurrence` is lifted to 1 precisely so that the veto does not make
    this decision for us -- the pair reaches the cost comparison, and it is the
    comparison that has to reject it.  Asserting that the call returned would
    prove nothing here: what is asserted is that both slots are still occupied
    in the returned chain, which is what "kept separate" means.
    """
    pc = always_present_pair()

    with caplog.at_level(logging.INFO, logger="petra.merge_sources"):
        result = merge_sources(pc, obs_time_yrs=1.0, max_co_occurrence=1.0, **FAST_FLOW)

    # The pair really was a candidate, and really was compared and turned down.
    assert "Evaluating merge of sources 0 and 1" in caplog.text
    assert "Keeping sources 0 and 1 separate" in caplog.text

    # Both sources survive, in their own slots, with all of their samples.
    assert not np.isnan(result.chain).any()
    assert np.array_equal(result.chain, pc.chain, equal_nan=True)
    assert np.array_equal(result.prob_in_model, [1.0, 1.0])


def test_a_source_is_merged_at_most_once(caplog):
    """
    A slot that has already been merged is not offered up a second time.

    All three pairs of `three_disjoint_slots` are candidates and each would be
    merged on its own, so without the guard the first merge's output would be
    fed straight into a second one and two of the three sources would be lost.
    """
    pc = three_disjoint_slots()

    with caplog.at_level(logging.INFO, logger="petra.merge_sources"):
        result = merge_sources(pc, obs_time_yrs=1.0, **FAST_FLOW)

    assert caplog.text.count("already merged in prior step") == 2
    assert "Merged 1 pair(s) total." in caplog.text

    # One slot absorbed another and a third was left untouched, so the three
    # occupancies are 2/3, 1/3 and 0 -- in whichever slots the pair search
    # happened to pick.  A second merge would have made them 1, 0, 0.
    occupancy = sorted(float(np.mean(~np.isnan(result.chain[:, i, 0]))) for i in range(3))
    assert occupancy == pytest.approx([0.0, 1 / 3, 2 / 3])
    # No sample was invented or dropped on the way.
    assert (np.count_nonzero(~np.isnan(result.chain))
            == np.count_nonzero(~np.isnan(pc.chain)))


# ---------------------------------------------------------------------------
# The prob_in_model contract: the returned chain describes itself, unclipped
# ---------------------------------------------------------------------------

def test_returned_prob_in_model_is_unclipped_when_nothing_merges():
    """
    A source present in every sample has probability 1, not ``1 - eps``.

    ``find_prob_in_model`` clips into ``[eps, 1 - eps]`` by default so that the
    logarithms inside the cost comparison stay finite.  That is an implementation
    detail of the comparison; a caller reading ``prob_in_model`` off the returned
    chain is asking how often each source was present, and 1e-6 is a wrong answer
    for a slot that is empty in every single sample.
    """
    chain = np.full((60, 3, 1), np.nan)
    chain[:, 0, 0] = 1e-3                      # present in every sample
    chain[:30, 1, 0] = 1e-3 + 40 * DELTA_FREQ  # present in half
    # slot 2 is never present at all

    pc = PosteriorChain(chain, 3, 1, trans_dimensional=True)
    result = merge_sources(pc, obs_time_yrs=1.0, progress=False)

    assert np.array_equal(result.prob_in_model, [1.0, 0.5, 0.0])


def test_returned_prob_in_model_is_unclipped_after_a_merge():
    """The slot a merge frees is empty, so its probability is 0.0 exactly."""
    pc = three_disjoint_slots()
    result = merge_sources(pc, obs_time_yrs=1.0, **FAST_FLOW)

    freed = np.array([np.all(np.isnan(result.chain[:, i, 0])) for i in range(3)])
    assert freed.sum() == 1
    assert result.prob_in_model[freed][0] == 0.0
    # ... and the probabilities still describe the chain that was handed back.
    occupancy = [np.mean(~np.isnan(result.chain[:, i, 0])) for i in range(3)]
    assert np.array_equal(result.prob_in_model, occupancy)


def test_compute_pair_cost_accepts_unclipped_probabilities():
    """
    An unclipped ``prob_in_model`` is exactly what a returned chain now carries.

    Feeding one straight back in must not produce ``log(0)``: ``np.where``
    evaluates both branches, so an untouched 1.0 would warn and put ``-inf``
    into the term for samples the source is absent from -- of which, at
    probability 1, there are none.
    """
    chain = np.array([[[0.5], [0.5]], [[0.5], [0.5]]])
    flow = UniformPrior([0.0], [1.0])

    with warnings.catch_warnings():
        warnings.simplefilter("error")     # a RuntimeWarning fails the test
        cost_2, cost_1 = compute_pair_cost(chain, 0, 1, flow, flow, flow,
                                           np.array([1.0, 1.0]))

    assert np.isfinite(cost_2) and np.isfinite(cost_1)


# ---------------------------------------------------------------------------
# Argument validation: a bare chain array carries no shape guarantee
# ---------------------------------------------------------------------------

def test_a_flattened_chain_is_rejected_by_name():
    """
    ``(n_samples, n_sources * n_params)`` is a layout PosteriorChain accepts.

    Nothing here can accept it -- there is no second argument saying where the
    split falls -- and the old failure was ``IndexError: tuple index out of
    range`` from inside ``chain.shape[2]``, which names neither the argument nor
    the layout that was wanted.
    """
    with pytest.raises(ValueError, match=r"three dimensional.*got shape \(200, 2\)"):
        identify_merge_candidates(np.zeros((200, 2)), obs_time_yrs=1.0)

    with pytest.raises(ValueError, match="three dimensional"):
        merge_pair_in_chain(np.zeros((200, 2)), 0, 1)


def test_a_non_numeric_chain_is_rejected():
    with pytest.raises(ValueError, match="chain must be a numeric array"):
        identify_merge_candidates(np.full((10, 2, 1), "x"), obs_time_yrs=1.0)


@pytest.mark.parametrize("bad_index", [1, -1, 1.0, "0"])
def test_freq_param_index_must_address_a_parameter(bad_index):
    """A one-parameter chain has exactly one legal `freq_param_index`."""
    chain = np.zeros((10, 2, 1))
    with pytest.raises(ValueError, match=r"freq_param_index must be in \[0, 1\)"):
        merge_pair_in_chain(chain, 0, 1, freq_param_index=bad_index)


def test_merge_pair_in_chain_rejects_slots_that_are_not_there():
    chain = np.zeros((10, 2, 1))
    with pytest.raises(ValueError, match=r"source_b must be in \[0, 2\), got 2"):
        merge_pair_in_chain(chain, 0, 2)


def test_a_negative_slot_index_is_rejected_rather_than_wrapped():
    """
    ``chain[:, -1, :]`` is the last slot, so a negative index used to merge it.

    Nothing raised: the caller asked for slot -1, got slot ``n_sources - 1``,
    and was handed back a chain in which the wrong pair of sources had been
    merged.
    """
    chain = np.zeros((10, 3, 1))
    with pytest.raises(ValueError, match=r"source_b must be in \[0, 3\), got -1"):
        merge_pair_in_chain(chain, 0, -1)


def test_merging_a_slot_with_itself_is_rejected():
    """It is not a no-op: slot b is emptied after slot a is filled from it."""
    chain = np.zeros((10, 2, 1))
    with pytest.raises(ValueError, match="must be different slots, got 1 twice"):
        merge_pair_in_chain(chain, 1, 1)


def test_compute_pair_cost_checks_prob_in_model_against_the_chain():
    """
    One probability per slot: a shorter array silently scores the wrong source.

    ``prob_in_model[source_b]`` on a two-entry array is a perfectly good lookup
    when the chain has three slots -- it just answers about a different source.
    """
    chain = np.zeros((10, 3, 1))
    flow = UniformPrior([0.0], [1.0])

    with pytest.raises(ValueError, match="inconsistent with num_sources=2"):
        compute_pair_cost(chain, 0, 1, flow, flow, flow, np.array([0.5, 0.5]))

    with pytest.raises(ValueError, match="prob_in_model must be a one dimensional"):
        compute_pair_cost(chain, 0, 1, flow, flow, flow, np.zeros((3, 1)))
