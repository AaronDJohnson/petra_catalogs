"""
MCMC-based label relabeling using normalizing flows.

This module provides an alternative to the EM-like (fit + Hungarian) relabeling
loop. Instead of greedy per-sample optimal assignment, it uses an MCMC sampler
over label permutations with Metropolis acceptance, which can escape local
optima that trap the Hungarian algorithm when posteriors are multimodal.

Two-phase Gibbs-like sampler:
  1. Refit phase  - train normalizing flows on current label assignments.
  2. MCMC phase   - hold flows fixed, run pairwise label swap proposals.

Temperature annealing from ``mcmc.t_start`` to ``mcmc.t_end`` across phases
helps exploration when early flow fits are poor.

Settings objects
----------------
The two entry points here take the flows' training hyperparameters as a
:class:`petra.options.FlowFit` and the sampler's as a
:class:`petra.options.MCMCSettings`, rather than as two dozen loose keywords.
Every field of both is still accepted as a plain keyword -- ``knots=8`` and
``flow_fit=FlowFit(knots=8)`` are the same call -- but an object *and* one of
its fields in the same call is a :class:`TypeError`, never a merge.

Best-state tracking
-------------------
The chain of permutations is a sampler, not an optimizer, so its *last* draw is
not its best one -- especially at ``t_end = 1``, where uphill moves are still
accepted with probability one and downhill moves with probability ``exp(delta)``.
Each phase therefore keeps the labeling with the highest mean per-sample
log-likelihood seen in that phase and carries *that* forward, discarding the
tail of the random walk.

Log-likelihoods from different phases are computed under *different* flows and
are not comparable, so the best state is tracked within a phase only.  At the
end of a phase the chain is re-based (the winning permutation is applied to the
data and the permutation state is reset to the identity), which makes each
phase self-contained: a checkpoint carries no sampler state, only the labeling
the phase ended on together with the ``prob_in_model`` and the cost that
describe it.

Checkpoints
-----------
They are written by :func:`petra.relabel._checkpoint_posterior_chain`, the one
writer :func:`petra.relabel.load_checkpoint` reads, so a checkpoint from this
module and one from the Hungarian loop are the same file in the same directory
with the same fields.
"""

from typing import Any, Sequence

import numpy as np
from tqdm import tqdm

from petra.flow_utils import DEFAULT_LOG_PROB_FLOOR, safe_flow_log_prob
from petra.options import FlowFit, Initialization, MCMCSettings
from petra.posterior_chain import PosteriorChain
from petra.relabel import (
    _checkpoint_posterior_chain,
    _with_unclipped_prob_in_model,
    load_checkpoint,
    prepare_chain,
)
from petra.standardized_flows import make_standardized_flows_fit
from petra.utils import (
    find_prob_in_model,
    get_logger,
    resolve_entry_point_kwargs,
    source_present,
)

logger = get_logger(__name__)

#: Default ceiling on the size of the log-probability cache, in gibibytes.
#: The cache is ``n_samples x n_sources x n_sources`` float64 values, which
#: grows quadratically in the number of source labels.  Read off
#: :class:`petra.options.MCMCSettings` rather than restated, so that the
#: function default and the options-object default cannot drift apart.
DEFAULT_MAX_CACHE_GB = MCMCSettings().max_cache_gb

#: Default number of refit-then-MCMC phases, shared by
#: :func:`mcmc_relabel_standardized_flows` and :func:`make_catalog_mcmc_flows`.
#: Named so the deprecated-alias handling can tell "the caller left this alone"
#: from "the caller asked for this value".
DEFAULT_NUM_ITERATIONS = 5

#: Default iteration budget for the multivariate-normal initialization steps,
#: read off :class:`petra.options.Initialization` for the same reason as
#: :data:`DEFAULT_MAX_CACHE_GB`.
DEFAULT_INIT_NUM_ITERATIONS = Initialization().num_iterations


# ---------------------------------------------------------------------------
# Cache construction
# ---------------------------------------------------------------------------

def build_log_prob_cache(chain: np.ndarray,
                         flows: Sequence[Any],
                         prob_in_model: np.ndarray,
                         nan_mask: np.ndarray,
                         max_cache_gb: float = DEFAULT_MAX_CACHE_GB,
                         progress: bool = True,
                         log_prob_floor: float = DEFAULT_LOG_PROB_FLOOR) -> np.ndarray:
    """
    Pre-compute log-probabilities for every (flow, sample, slot) triple.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params)
        Current label assignments.
    flows : list of flow objects, length n_sources
        Trained normalizing flows (one per source label).
    prob_in_model : ndarray, shape (n_sources,)
        Inclusion probability for each source label.
    nan_mask : ndarray of bool, shape (n_samples, n_sources)
        True where the source is absent from that sample, i.e.
        ``~source_present(chain)``.
    max_cache_gb : float, default `DEFAULT_MAX_CACHE_GB`
        Refuse to allocate a cache larger than this many gibibytes.
    progress : bool, default True
        Show a tqdm progress bar over the flows.
    log_prob_floor : float, default `petra.flow_utils.DEFAULT_LOG_PROB_FLOOR`
        Value substituted for a non-finite flow log-density.  It sets how hard
        the sampler refuses a label, so it must match the floor used by the
        other relabelers for two catalogs to be comparable.

    Returns
    -------
    cache : ndarray, shape (n_samples, n_sources, n_sources)
        ``cache[n, i, j]`` = log p_i(x_{n,j}) -- flow *i* evaluated on
        the data in slot *j* of sample *n*.  For NaN slots the value is
        ``log(1 - prob_in_model[i])``.  Every entry is finite: non-finite flow
        densities are floored at `log_prob_floor`.

    Raises
    ------
    MemoryError
        If the cache would exceed `max_cache_gb`.  The cache is quadratic in
        the number of source labels, so it is easy to ask for tens of
        gigabytes without noticing.

    Examples
    --------
    >>> import numpy as np
    >>> from petra.utils import UniformPrior, source_present
    >>> chain = np.array([[[0.5], [5.0]], [[0.5], [np.nan]]])
    >>> flows = [UniformPrior([0.0], [np.e]), UniformPrior([0.0], [np.e ** 2])]
    >>> cache = build_log_prob_cache(chain, flows, np.array([0.75, 0.5]),
    ...                              ~source_present(chain), progress=False)
    >>> np.round(cache[0], 3).tolist()      # sample 0: both slots occupied
    [[-1.0, -50.0], [-2.0, -2.0]]
    >>> np.round(cache[1], 3).tolist()      # sample 1: slot 1 is absent
    [[-1.0, -1.386], [-2.0, -0.693]]
    >>> huge = np.broadcast_to(np.nan, (10 ** 7, 40, 1))   # a view, not 3.2 GB
    >>> build_log_prob_cache(huge, flows, np.array([0.5, 0.5]),
    ...                      np.broadcast_to(False, huge.shape[:2]))
    Traceback (most recent call last):
        ...
    MemoryError: The MCMC log-probability cache would need 10000000 x 40 x 40 float64 values (119.21 GiB), above the max_cache_gb=2.0 limit. Thin the chain to at most 167772 samples, lower max_num_sources, or raise max_cache_gb.
    """
    n_samples, n_sources, _ = chain.shape

    cache_bytes = n_samples * n_sources * n_sources * np.dtype(np.float64).itemsize
    limit_bytes = max_cache_gb * 2 ** 30
    if cache_bytes > limit_bytes:
        max_samples = int(limit_bytes // (n_sources * n_sources * np.dtype(np.float64).itemsize))
        raise MemoryError(
            f"The MCMC log-probability cache would need {n_samples} x {n_sources} x "
            f"{n_sources} float64 values ({cache_bytes / 2 ** 30:.2f} GiB), above the "
            f"max_cache_gb={max_cache_gb} limit. Thin the chain to at most {max_samples} "
            f"samples, lower max_num_sources, or raise max_cache_gb."
        )

    cache = np.empty((n_samples, n_sources, n_sources))

    # Pre-compute the NaN fill values: log(1 - prob_in_model[i])
    with np.errstate(divide="ignore"):
        log_not_in = np.log1p(-np.asarray(prob_in_model, dtype=float))  # (n_sources,)

    for i, flow in enumerate(tqdm(flows, desc="Caching flow log-probs", disable=not progress)):
        for j in range(n_sources):
            valid = ~nan_mask[:, j]  # which samples have real data in slot j
            # Fill NaN slots with the "not in model" log-prob
            cache[:, i, j] = log_not_in[i]

            if not np.any(valid):
                continue

            # One batched call per (flow, slot): flowjax distributions and
            # UniformPrior both broadcast over a leading sample axis.
            cache[valid, i, j] = np.asarray(
                safe_flow_log_prob(flow, chain[valid, j, :], floor=log_prob_floor)
            )

    return cache


# ---------------------------------------------------------------------------
# MCMC sweep
# ---------------------------------------------------------------------------

def _occurrence_rank(values: np.ndarray) -> np.ndarray:
    """
    Rank of each element among the earlier elements with the same value.

    The first occurrence of a value gets rank 0, the second rank 1, and so on.
    Grouping proposals by this rank splits a proposal stream into consecutive
    blocks in which every sample index appears at most once, so the block can
    be applied all at once without any proposal inside it seeing a state that
    another proposal inside it wrote.

    Parameters
    ----------
    values : ndarray of int, shape (n,)
        Values to rank.

    Returns
    -------
    rank : ndarray of int, shape (n,)
        Occurrence rank of each element.

    Examples
    --------
    >>> _occurrence_rank(np.array([3, 1, 3, 3, 1]))
    array([0, 0, 1, 2, 1])
    """
    order = np.argsort(values, kind="stable")
    sorted_values = values[order]
    is_new = np.empty(sorted_values.shape, dtype=bool)
    is_new[0] = True
    np.not_equal(sorted_values[1:], sorted_values[:-1], out=is_new[1:])
    starts = np.flatnonzero(is_new)
    counts = np.diff(np.concatenate((starts, [sorted_values.size])))
    rank_sorted = np.arange(sorted_values.size) - np.repeat(starts, counts)
    rank = np.empty_like(rank_sorted)
    rank[order] = rank_sorted
    return rank


def mcmc_sweep(perms: np.ndarray,
               cache: np.ndarray,
               log_liks: np.ndarray,
               *,
               rng: np.random.Generator,
               temperature: float,
               n_proposals: int) -> dict:
    """
    Run one sweep of pairwise label-swap proposals across samples.

    Parameters
    ----------
    perms : ndarray of int, shape (n_samples, n_sources)
        Current permutation state, updated in place.  ``perms[n, j]`` is the
        flow index currently assigned to slot *j* in sample *n*.
    cache : ndarray, shape (n_samples, n_sources, n_sources)
        Pre-computed log-prob cache from :func:`build_log_prob_cache`.
    log_liks : ndarray, shape (n_samples,)
        Current per-sample total log-likelihood (updated in place).
    rng : numpy.random.Generator
        Random number generator.
    temperature : float
        Annealing temperature (>0).  Higher = more exploration.
    n_proposals : int
        Number of swap proposals to attempt in this sweep.

    Returns
    -------
    diagnostics : dict
        ``n_accepted`` -- number of accepted swaps.
        ``n_proposed`` -- total proposals.
        ``acceptance_rate`` -- fraction accepted.
        ``mean_log_lik`` -- mean per-sample log-likelihood after sweep.

    Raises
    ------
    ValueError
        If `temperature` is not strictly positive.

    Notes
    -----
    Proposals are applied in blocks of distinct sample indices rather than one
    at a time (see :func:`_occurrence_rank`).  Samples do not interact -- a
    proposal only ever reads and writes the row of `perms` and the entry of
    `log_liks` belonging to its own sample -- so a block behaves exactly like
    the same proposals applied one after another, while costing a handful of
    vectorized numpy operations instead of ``n_proposals`` interpreted ones.
    The random numbers are drawn in the same order as before, so the accepted
    set is unchanged as well.

    Examples
    --------
    >>> import numpy as np
    >>> cache = np.array([[[0.0, -5.0], [-5.0, 0.0]]])   # 1 sample, 2 labels
    >>> perms = np.array([[1, 0]])                       # start swapped
    >>> log_liks = np.array([-10.0])
    >>> diag = mcmc_sweep(perms, cache, log_liks, rng=np.random.default_rng(0),
    ...                   temperature=1.0, n_proposals=4)
    >>> perms                       # the sampler finds the identity labeling
    array([[0, 1]])
    >>> float(log_liks[0])
    0.0
    """
    n_samples, n_sources = perms.shape
    if not temperature > 0:
        raise ValueError(f"temperature must be strictly positive, got {temperature}.")
    if n_proposals <= 0:
        return {"n_accepted": 0, "n_proposed": 0, "acceptance_rate": 0.0,
                "mean_log_lik": float(np.mean(log_liks))}

    # Draw all random numbers up front for speed
    sample_idxs = rng.integers(0, n_samples, size=n_proposals)
    slot_pairs = rng.integers(0, n_sources, size=(n_proposals, 2))
    uniforms = rng.random(n_proposals)

    rank = _occurrence_rank(sample_idxs)
    n_accepted = 0

    for block in range(int(rank.max()) + 1):
        proposals = np.flatnonzero(rank == block)
        n = sample_idxs[proposals]
        j1 = slot_pairs[proposals, 0]
        j2 = slot_pairs[proposals, 1]

        # A swap of a slot with itself is a no-op, but it still consumed its
        # random numbers, exactly as in the one-proposal-at-a-time version.
        keep = j1 != j2
        proposals, n, j1, j2 = proposals[keep], n[keep], j1[keep], j2[keep]
        if proposals.size == 0:
            continue

        # Current flow assignments for the two slots
        fi = perms[n, j1]  # flow assigned to slot j1
        fj = perms[n, j2]  # flow assigned to slot j2

        # Change in log-likelihood if the two slots exchange their flows
        delta = (
            cache[n, fj, j1] + cache[n, fi, j2]
            - cache[n, fi, j1] - cache[n, fj, j2]
        )

        # Metropolis acceptance. The exponent is clipped at zero so that an
        # uphill move cannot overflow; such moves are accepted by the first
        # term anyway.
        accept = (delta > 0) | (uniforms[proposals] < np.exp(np.minimum(delta, 0.0) / temperature))
        n, j1, j2 = n[accept], j1[accept], j2[accept]
        fi, fj, delta = fi[accept], fj[accept], delta[accept]

        perms[n, j1] = fj
        perms[n, j2] = fi
        log_liks[n] += delta
        n_accepted += int(n.size)

    return {
        "n_accepted": n_accepted,
        "n_proposed": n_proposals,
        "acceptance_rate": n_accepted / max(n_proposals, 1),
        "mean_log_lik": float(np.mean(log_liks)),
    }


# ---------------------------------------------------------------------------
# Apply permutations to chain
# ---------------------------------------------------------------------------

def apply_permutations(chain: np.ndarray, perms: np.ndarray) -> np.ndarray:
    """
    Reorder chain slots according to the permutation state.

    After the MCMC, ``perms[n, j]`` tells us which flow label is assigned
    to slot *j*.  We want the output chain to have flow-label *i* in column
    *i*, so we need to invert the permutation.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params)
        Original (pre-MCMC) chain data.
    perms : ndarray of int, shape (n_samples, n_sources)
        Permutation state from the MCMC.

    Returns
    -------
    reordered : ndarray, shape (n_samples, n_sources, n_params)
        Chain with columns reordered so that column *i* contains data
        assigned to flow *i*.

    Notes
    -----
    The inverse of a permutation is its ``argsort``, which lets the whole chain
    be reordered with one :func:`numpy.take_along_axis` instead of a Python
    loop over samples.

    Examples
    --------
    >>> import numpy as np
    >>> chain = np.array([[[1.0], [2.0], [3.0]]])
    >>> apply_permutations(chain, np.array([[2, 0, 1]]))[0, :, 0]
    array([2., 3., 1.])
    """
    inverse = np.argsort(perms, axis=1)
    return np.take_along_axis(chain, inverse[:, :, np.newaxis], axis=1)


def _phase_result(chain: np.ndarray, template: PosteriorChain,
                  max_num_sources: int, mean_log_lik: float) -> PosteriorChain:
    """
    Wrap the relabeled chain of one phase, with its inclusion probabilities and cost.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params)
        Relabeled chain the phase ended on.
    template : PosteriorChain
        Chain the metadata (``num_sources`` and friends) and the earlier
        ``cost_dict`` entries are taken from.  Never modified: its cost history
        is copied before this phase's cost is added.
    max_num_sources : int
        Number of source slots to report an inclusion probability for, and the
        ``cost_dict`` key this phase's cost is recorded under.
    mean_log_lik : float
        Best mean per-sample log-likelihood of the phase.

    Returns
    -------
    PosteriorChain
        `chain` with ``prob_in_model`` recomputed from it *without* clipping and
        ``cost_dict[max_num_sources]`` set to ``-mean_log_lik``.

    Notes
    -----
    Both the checkpoint of a phase and the value the relabeler returns are built
    here, so a resumed run reads back exactly the object a completed run would
    have handed over.  They used to be built separately, and the checkpoint
    branch passed on only the shape metadata: every checkpoint the MCMC path
    wrote stored ``prob_in_model=None`` and an empty ``cost_dict``.

    Examples
    --------
    >>> import numpy as np
    >>> from petra.posterior_chain import PosteriorChain
    >>> chain = np.array([[[1.0], [np.nan]], [[2.0], [3.0]]])
    >>> template = PosteriorChain(chain, 2, 1, trans_dimensional=True, cost_dict={1: -2.0})
    >>> result = _phase_result(chain, template, 2, -4.5)
    >>> result.prob_in_model
    array([1. , 0.5])
    >>> result.cost_dict
    {1: -2.0, 2: 4.5}
    >>> template.cost_dict            # the template's history is untouched
    {1: -2.0}
    """
    cost_dict = dict(template.cost_dict)
    # petra's cost convention is the negated log-likelihood: lower is better.
    cost_dict[max_num_sources] = -mean_log_lik
    return PosteriorChain(
        chain,
        num_sources=template.num_sources,
        num_params_per_source=template.num_params_per_source,
        trans_dimensional=template.trans_dimensional,
        prob_in_model=find_prob_in_model(chain, max_num_sources, eps=0),
        cost_dict=cost_dict,
    )


# ---------------------------------------------------------------------------
# Main outer loop
# ---------------------------------------------------------------------------

def mcmc_relabel_standardized_flows(posterior_chain: PosteriorChain,
                                    max_num_sources: int | None = None,
                                    *,
                                    num_iterations: int = DEFAULT_NUM_ITERATIONS,
                                    rng_seed: int = 999,
                                    checkpoint_dir: str | None = None,
                                    resume_from: str | None = None,
                                    progress: bool = True,
                                    eps: float = 1e-6,
                                    threshold_samples: int = 50,
                                    flow_fit: FlowFit | None = None,
                                    mcmc: MCMCSettings | None = None,
                                    **flat_keywords: Any) -> PosteriorChain:
    """
    Relabel a posterior chain using alternating flow-refit and MCMC phases.

    Parameters
    ----------
    posterior_chain : PosteriorChain
        Chain to relabel.
    max_num_sources : int, optional
        Maximum number of source labels (defaults to chain's num_sources).
    num_iterations : int, default `DEFAULT_NUM_ITERATIONS`
        Number of refit-then-MCMC phases; formerly ``n_phases``.  One iteration
        retrains every populated source slot's flow, builds the
        ``(n_samples, max_num_sources, max_num_sources)`` log-probability cache
        from the refitted flows, runs ``mcmc.sweeps_per_phase`` sweeps of
        ``mcmc.proposals_per_sweep`` pairwise label-swap proposals each, and
        carries the best labeling of the phase forward.  No phase is skipped:
        unlike the Hungarian relabelers this loop has no early stop, and the
        temperature falls linearly from `mcmc.t_start` to `mcmc.t_end` across
        the phases, so `num_iterations` sets the anneal as well as the budget.
    rng_seed : int, default 999
        Random seed for the MCMC proposals and for the flow fits.
    checkpoint_dir : str, optional
        Directory to write the relabeled chain into after every phase.  Each
        checkpoint holds what this function would have returned had it stopped
        there: the labeling, its unclipped ``prob_in_model`` and its cost.
    resume_from : str, optional
        Checkpoint file, or directory of checkpoints, written by an earlier
        run.  The stored chain replaces `posterior_chain` and the phase counter
        (and hence the annealing temperature) picks up where that run stopped.
    progress : bool, default True
        Show tqdm progress bars.
    eps : float, default 1e-6
        Clip bound on the inclusion probabilities, keeping them inside
        ``[eps, 1 - eps]`` so the ``log(1 - p)`` fills in the log-probability
        cache stay finite.  Shared with the other entry points: it sets the
        scale of the absent-source term, so two catalogs built with different
        values are not comparable.  Only the cache is affected -- the
        ``prob_in_model`` reported on the returned chain is always unclipped.
    threshold_samples : int, default 50
        A source label with no more than this many samples falls back to a
        uniform prior instead of a trained flow.  It decides which slots get a
        flow at all rather than how one trains, which is why it is here rather
        than on `flow_fit`.
    flow_fit : FlowFit, optional
        Flow training hyperparameters -- ``knots``, ``interval``,
        ``max_epochs``, ``max_patience``, ``learning_rate``,
        ``log_prob_floor``, ``plot_flows``.  ``None`` means ``FlowFit()``.
    mcmc : MCMCSettings, optional
        Sampler settings -- ``sweeps_per_phase``, ``proposals_per_sweep``,
        ``t_start``, ``t_end``, ``max_cache_gb``.  ``None`` means
        ``MCMCSettings()``.

    Returns
    -------
    relabeled_chain : PosteriorChain
        Relabeled chain.  ``cost_dict[max_num_sources]`` holds the final mean
        per-sample log-likelihood, negated so that -- as everywhere else in
        petra -- a *lower* cost is a better labeling.

    Other Parameters
    ----------------
    knots, interval, max_epochs, max_patience, learning_rate, log_prob_floor, plot_flows
        Every field of `flow_fit`, still accepted as a flat keyword with
        unchanged meaning and no warning.
    sweeps_per_phase, proposals_per_sweep, t_start, t_end, max_cache_gb
        Every field of `mcmc`, likewise.
    n_phases : int, optional
        Deprecated alias for `num_iterations`.

    Raises
    ------
    ValueError
        If `num_iterations` is less than 1, or if a flat keyword carries a value
        its options class rejects.
    TypeError
        If an unknown keyword argument is supplied, or if an options object is
        passed alongside a flat keyword that would overwrite one of its fields.

    Notes
    -----
    Only the best labeling of each phase survives it; see the module docstring
    for why that best is tracked per phase rather than across the whole run.

    This function deliberately has no `initialization` parameter: it has no
    initialization step, so ``mv_normal_init`` must stay inapplicable here.

    Examples
    --------
    ``threshold_samples`` above the number of samples sends every slot to the
    uniform-prior fallback, so the example runs without training a flow.

    >>> import numpy as np
    >>> from petra.options import MCMCSettings
    >>> from petra.posterior_chain import PosteriorChain
    >>> rng = np.random.default_rng(0)
    >>> chain_array = rng.normal(size=(20, 3, 1)) + np.array([[0.0], [5.0], [10.0]])
    >>> pc = PosteriorChain(chain_array, 3, 1, True, None, {})
    >>> relabeled = mcmc_relabel_standardized_flows(
    ...     pc,
    ...     max_num_sources=3,
    ...     num_iterations=1,
    ...     threshold_samples=1000,
    ...     mcmc=MCMCSettings(sweeps_per_phase=2),
    ...     progress=False,
    ... )
    >>> relabeled.chain.shape
    (20, 3, 1)
    """
    resolved, options = resolve_entry_point_kwargs(
        mcmc_relabel_standardized_flows, flat_keywords,
        options={"flow_fit": flow_fit, "mcmc": mcmc},
        current={"num_iterations": num_iterations},
    )
    num_iterations = resolved.get("num_iterations", num_iterations)
    fit: FlowFit = options["flow_fit"]
    sampler: MCMCSettings = options["mcmc"]
    if num_iterations < 1:
        raise ValueError(f"num_iterations must be at least 1, got {num_iterations}.")

    start_phase = 0
    if resume_from is not None:
        posterior_chain, start_phase = load_checkpoint(resume_from)
        logger.warning("Resuming MCMC relabeling from checkpoint %s after %d completed "
                       "phases.", resume_from, start_phase)

    posterior_chain = prepare_chain(posterior_chain, max_num_sources)
    max_num_sources = posterior_chain.num_sources

    if start_phase >= num_iterations:
        logger.warning("Checkpoint already holds %d of %d phases; nothing to do.",
                       start_phase, num_iterations)
        # Even the do-nothing path owes the caller a chain that describes itself:
        # a checkpoint written before `_phase_result` existed carries
        # `prob_in_model=None`, and one written by the Hungarian loop carries the
        # clipped, pre-relabel array of the iteration that wrote it.
        return _with_unclipped_prob_in_model(posterior_chain, max_num_sources)

    chain = posterior_chain.get_chain().copy()
    n_samples, n_sources, _ = chain.shape

    # `None` means "scale with the chain", which is only knowable here.
    proposals_per_sweep = (sampler.proposals_per_sweep if sampler.proposals_per_sweep is not None
                           else n_samples * n_sources * 2)

    rng = np.random.default_rng(rng_seed)

    # Build flow fitter (reused across phases, retrains each call).  It is a
    # closure carrying a ``set_iteration`` attribute, which no plain Callable
    # type can express, hence the explicit Any.  The fitter keeps its flat
    # signature, so the options object is unpacked here rather than pushed down.
    flow_fitter: Any = make_standardized_flows_fit(
        chain, max_num_sources,
        rng_seed=rng_seed + 100,
        plot_flows=fit.plot_flows,
        knots=fit.knots,
        interval=fit.interval,
        threshold_samples=threshold_samples,
        max_epochs=fit.max_epochs,
        max_patience=fit.max_patience,
        learning_rate=fit.learning_rate,
        progress=progress,
    )

    slots = np.arange(n_sources)
    # ``start_phase < num_iterations`` was checked above, so the loop below runs
    # at least once and both of these are always overwritten before they are read.
    mean_log_lik = float("nan")
    phase_result = posterior_chain

    for phase in range(start_phase, num_iterations):
        # --- Temperature for this phase ---
        frac = phase / (num_iterations - 1) if num_iterations > 1 else 1.0
        temperature = sampler.t_start + (sampler.t_end - sampler.t_start) * frac

        logger.info("Phase %d/%d (temperature=%.3f): refitting flows.",
                    phase + 1, num_iterations, temperature)
        flow_fitter.set_iteration(phase)
        flows = flow_fitter(chain, max_num_sources)

        prob_in_model = find_prob_in_model(chain, max_num_sources, eps=eps)

        logger.info("  Building log-prob cache.")
        nan_mask = ~source_present(chain)
        cache = build_log_prob_cache(chain, flows, prob_in_model, nan_mask,
                                     max_cache_gb=sampler.max_cache_gb, progress=progress,
                                     log_prob_floor=fit.log_prob_floor)

        # The chain is re-based at the end of every phase, so the labeling the
        # flows were just fit to is the identity permutation.
        perms = np.tile(slots, (n_samples, 1))
        log_liks = cache[:, slots, slots].sum(axis=1)

        last_log_lik = float(np.mean(log_liks))
        best_log_lik = last_log_lik
        best_perms = perms.copy()
        best_log_liks = log_liks.copy()

        for sweep in tqdm(range(sampler.sweeps_per_phase), desc=f"Phase {phase + 1} sweeps",
                          disable=not progress):
            diagnostics = mcmc_sweep(perms, cache, log_liks, rng=rng,
                                     temperature=temperature,
                                     n_proposals=proposals_per_sweep)
            logger.info("  Sweep %d/%d: accept=%.1f%%  mean_log_lik=%.2f",
                        sweep + 1, sampler.sweeps_per_phase,
                        100 * diagnostics["acceptance_rate"],
                        diagnostics["mean_log_lik"])
            last_log_lik = diagnostics["mean_log_lik"]
            if last_log_lik > best_log_lik:
                best_log_lik = last_log_lik
                best_perms = perms.copy()
                best_log_liks = log_liks.copy()

        if best_log_lik > last_log_lik:
            logger.info("  Reverting to the best labeling of this phase "
                        "(mean_log_lik=%.2f).", best_log_lik)
        perms, log_liks = best_perms, best_log_liks
        mean_log_lik = best_log_lik

        # Re-base: fold the winning permutation into the data itself.
        chain = apply_permutations(chain, perms)

        # One object for the checkpoint and for the return value: what a resumed
        # run reads back is then exactly what an uninterrupted one would return.
        phase_result = _phase_result(chain, posterior_chain, max_num_sources, mean_log_lik)
        if checkpoint_dir is not None:
            _checkpoint_posterior_chain(phase_result, checkpoint_dir, phase + 1)

    logger.info("Final mean per-sample log-likelihood: %s", mean_log_lik)
    return phase_result


# ---------------------------------------------------------------------------
# Top-level API
# ---------------------------------------------------------------------------

def make_catalog_mcmc_flows(posterior_chain: PosteriorChain,
                            max_num_sources: int,
                            *,
                            num_iterations: int = DEFAULT_NUM_ITERATIONS,
                            initialization_param_index: int | None = 0,
                            shuffle_seed: int | None = None,
                            rng_seed: int = 999,
                            checkpoint_dir: str | None = None,
                            resume_from: str | None = None,
                            progress: bool = True,
                            eps: float = 1e-6,
                            threshold_samples: int = 50,
                            initialization: Initialization | None = None,
                            flow_fit: FlowFit | None = None,
                            mcmc: MCMCSettings | None = None,
                            **flat_keywords: Any) -> PosteriorChain:
    """
    Create a catalog using MCMC label-swap relabeling with normalizing flows.

    This is the top-level entry point that handles chain preparation --
    shuffling, expansion, then the two optional initialization passes, which
    are switched independently: `initialization_param_index` selects the
    univariate one and ``initialization.with_mv_normal`` the multivariate one
    -- before calling the MCMC relabeler.

    Parameters
    ----------
    posterior_chain : PosteriorChain
        Input chain of posterior samples.
    max_num_sources : int
        Target number of source labels.
    num_iterations : int, default 5
        Number of refit-then-MCMC phases; formerly ``n_phases``.  One iteration
        retrains every populated source slot's flow, builds the
        ``(n_samples, max_num_sources, max_num_sources)`` log-probability cache
        from the refitted flows, runs ``mcmc.sweeps_per_phase`` sweeps of
        ``mcmc.proposals_per_sweep`` pairwise label-swap proposals each -- with
        the defaults, ``5 * 2 * n_samples * max_num_sources`` Metropolis
        proposals per iteration -- and carries the best labeling of the phase
        forward, discarding the tail of the random walk.  Two things differ from
        the four Hungarian entry points.  This loop never stops early: every
        phase runs, so `num_iterations` is exact work rather than a ceiling.
        And it is the annealing schedule as well as the budget -- the
        temperature falls linearly from `mcmc.t_start` to `mcmc.t_end` across
        the phases, so a 10-phase run is a different anneal from a 5-phase run,
        not a 5-phase run continued.
    initialization_param_index : int or None, default 0
        Parameter to run the univariate normal pre-initialization on.  ``None``
        skips that step, and is the only thing that does:
        ``initialization.with_mv_normal`` switches the multivariate pass alone
        (see Notes).  It names a column of *your* chain -- which parameter
        separates the sources -- rather than tuning the initializer, which is
        why it is here rather than on `initialization`.
    shuffle_seed : int, optional
        Seed for shuffling chain entries before relabeling.
    rng_seed : int, default 999
        Random seed for the MCMC proposals and for the flow fits.
    checkpoint_dir : str, optional
        Directory to write the chain into after every MCMC phase.
    resume_from : str, optional
        Checkpoint file or directory to resume the MCMC from.  The
        initialization steps are skipped when resuming, since the checkpoint
        already reflects them.
    progress : bool, default True
        Show tqdm progress bars.
    eps : float, default 1e-6
        Clip bound on the inclusion probabilities, keeping them inside
        ``[eps, 1 - eps]`` so the ``log(1 - p)`` fills in the log-probability
        cache stay finite.  Shared with the other entry points: it sets the
        scale of the absent-source term, so two catalogs built with different
        values are not comparable.  Only the cache is affected -- the
        ``prob_in_model`` reported on the returned chain is always unclipped.
    threshold_samples : int, default 50
        Sources with no more than this many samples fall back to a uniform
        prior instead of a trained flow.
    initialization : Initialization, optional
        The pre-relabeling passes -- ``with_mv_normal`` switches the
        multivariate one and ``num_iterations`` bounds each pass that runs.
        The univariate pass is switched by `initialization_param_index`
        instead, not by anything on this object.  ``None`` means
        ``Initialization()``.
    flow_fit : FlowFit, optional
        Flow training hyperparameters -- ``knots``, ``interval``,
        ``max_epochs``, ``max_patience``, ``learning_rate``,
        ``log_prob_floor``, ``plot_flows``.  ``None`` means ``FlowFit()``.
    mcmc : MCMCSettings, optional
        Sampler settings -- ``sweeps_per_phase``, ``proposals_per_sweep``,
        ``t_start``, ``t_end``, ``max_cache_gb``.  ``None`` means
        ``MCMCSettings()``.

    Returns
    -------
    relabeled_chain : PosteriorChain
        Relabeled chain with consistent source labels.

    Other Parameters
    ----------------
    init_with_mv_normal, init_num_iterations
        The fields of `initialization`, still accepted as flat keywords with
        unchanged meaning and no warning.  They keep the same spelling on all
        five ``make_catalog_*`` entry points, so a call can still be moved
        between methods without being rewritten.
    knots, interval, max_epochs, max_patience, learning_rate, log_prob_floor, plot_flows
        The fields of `flow_fit`, likewise.
    sweeps_per_phase, proposals_per_sweep, t_start, t_end, max_cache_gb
        The fields of `mcmc`, likewise.
    n_phases : int, optional
        Deprecated alias for `num_iterations`.
    mv_normal_init : bool, optional
        Deprecated alias for `init_with_mv_normal`.
    mv_normal_init_iterations : int, optional
        Deprecated alias for `init_num_iterations`.

    Raises
    ------
    ValueError
        If `max_num_sources` is smaller than the number of entries in the chain,
        if `initialization_param_index` is neither ``None`` nor a column of the
        chain, or if a flat keyword carries a value its options class rejects.
    TypeError
        If an unknown keyword argument is supplied, or if an options object is
        passed alongside a flat keyword that would overwrite one of its fields.

    Notes
    -----
    Every argument after `max_num_sources` is keyword-only, and the defaults of
    ``initialization.with_mv_normal`` (was False), `initialization_param_index`
    (was None) and `rng_seed` (was 42) follow the shared ``make_catalog_*``
    contract rather than this module's earlier ones.  Pass them explicitly to
    reproduce a run made with an older version.

    An options object and one of its flat fields is a :class:`TypeError`, never
    a merge -- ``FlowFit(knots=8)`` alongside ``max_epochs=20`` would otherwise
    raise the question of which defaults the object contributes, and the answer
    would have to be remembered rather than read.

    Changed in 1.1: ``init_with_mv_normal`` no longer switches the univariate
    pass off as well.  ``init_with_mv_normal=False`` -- equivalently
    ``initialization=Initialization(with_mv_normal=False)`` or the deprecated
    ``mv_normal_init=False`` -- together with an `initialization_param_index`
    that is not ``None`` (the default is 0) used to skip *both* initialization
    passes here, while
    :func:`petra.bayesian_gaussian.make_catalog_bayesian_gaussian` skipped only
    the multivariate one for the same pair of keywords.  All four entry points
    now go through :func:`petra.initialization.run_initialization_passes` and
    skip only the multivariate pass; add ``initialization_param_index=None`` to
    reproduce a run made with an older version.

    Examples
    --------
    A three-source chain, relabeled without any flow training: with
    ``threshold_samples`` above the number of samples every slot falls back to
    the uniform prior, which keeps the example fast.

    >>> import numpy as np
    >>> from petra.options import FlowFit, Initialization, MCMCSettings
    >>> from petra.posterior_chain import PosteriorChain
    >>> rng = np.random.default_rng(0)
    >>> chain_array = rng.normal(size=(20, 3, 1)) + np.array([[0.0], [5.0], [10.0]])
    >>> pc = PosteriorChain(chain_array, 3, 1, True, None, {})
    >>> flat = make_catalog_mcmc_flows(
    ...     pc,
    ...     max_num_sources=3,
    ...     num_iterations=1,
    ...     init_num_iterations=2,
    ...     knots=4,
    ...     sweeps_per_phase=2,
    ...     threshold_samples=1000,
    ...     progress=False,
    ... )
    >>> flat.chain.shape
    (20, 3, 1)

    Spelling the same call with the settings objects is the same run:

    >>> grouped = make_catalog_mcmc_flows(
    ...     pc,
    ...     max_num_sources=3,
    ...     num_iterations=1,
    ...     initialization=Initialization(num_iterations=2),
    ...     flow_fit=FlowFit(knots=4),
    ...     mcmc=MCMCSettings(sweeps_per_phase=2),
    ...     threshold_samples=1000,
    ...     progress=False,
    ... )
    >>> bool(np.array_equal(flat.get_chain(), grouped.get_chain()))
    True
    """
    resolved, options = resolve_entry_point_kwargs(
        make_catalog_mcmc_flows, flat_keywords,
        options={"initialization": initialization, "flow_fit": flow_fit, "mcmc": mcmc},
        current={"num_iterations": num_iterations},
    )
    num_iterations = resolved.get("num_iterations", num_iterations)
    init: Initialization = options["initialization"]

    from petra.make_catalog import relabel_mv_normal
    from petra.initialization import relabel_univariate_normal, run_initialization_passes

    # shuffle the entries and make sure the chain has the right shape
    posterior_chain = prepare_chain(posterior_chain, max_num_sources, shuffle_seed=shuffle_seed)

    # The preamble is one shared function, not a fourth copy of it: this one had
    # drifted from `make_catalog_bayesian_gaussian`'s, so `init_with_mv_normal`
    # decided both passes here and only one there.
    posterior_chain = run_initialization_passes(
        posterior_chain,
        max_num_sources,
        univariate_relabeler=relabel_univariate_normal,
        mv_normal_relabeler=relabel_mv_normal,
        with_mv_normal=init.with_mv_normal,
        param_index=initialization_param_index,
        num_iterations=init.num_iterations,
        resume_from=resume_from,
        progress=progress,
    )

    logger.info("Running MCMC flow relabeling.")
    return mcmc_relabel_standardized_flows(
        posterior_chain,
        max_num_sources=max_num_sources,
        num_iterations=num_iterations,
        rng_seed=rng_seed,
        checkpoint_dir=checkpoint_dir,
        resume_from=resume_from,
        progress=progress,
        eps=eps,
        threshold_samples=threshold_samples,
        flow_fit=options["flow_fit"],
        mcmc=options["mcmc"],
    )
