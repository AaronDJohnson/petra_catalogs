"""
Post-processing merge step for source slots after Gaussian relabeling.

After MV Normal relabeling, bimodal frequency posteriors get split into
separate source slots. This module tests whether two nearby source slots
are better described as one source using normalizing flows and spike-slab
cost comparison.

Units
-----
Every frequency in this module is in Hz.  The scale that decides whether two
slots can be the same source is the width of one Fourier frequency bin,
``delta_freq = 1 / T_obs`` (:func:`petra.utils.frequency_bin_width`), which for
a one year observation is about 3.2e-8 Hz.  The two distance thresholds
`max_freq_std_bins` and `max_merge_distance_bins` are therefore expressed in
units of that bin width, *not* in Hz; a value of 10 means "ten bins", i.e.
``10 / T_obs`` Hz.

Conventions
-----------
A slot is "present" in a sample when its frequency column is not NaN;
`freq_param_index` therefore selects both the frequency parameter and the
occupancy test, and it is threaded through every function here rather than
being assumed to be zero.

The chain :func:`merge_sources` returns describes itself, as every relabeled
chain in petra does: its ``prob_in_model`` is recomputed from the samples being
returned and is *not* clipped, so a freed slot reads exactly 0.0.  The clipping
of :data:`_COST_EPS` applies only to the probabilities that go into
:func:`compute_pair_cost`, where a probability of exactly 0 or 1 would make a
log term infinite.

The public entry points take keyword arguments only, apart from the chain and
the observation time.  The former positional spellings still work for one
release and emit a :class:`DeprecationWarning`; see
:data:`MERGE_SOURCES_LEGACY_POSITIONAL`.
"""

import warnings
from typing import Any

import numpy as np
import jax.random as jr

from coppuccino.copula_flows import normalizing_flows_fit

from petra.flow_utils import quiet_external_fit, safe_flow_log_prob
from petra.posterior_chain import (PosteriorChain, _validate_chain_shape,
                                   _validate_numeric_array)
from petra.relabel import _with_unclipped_prob_in_model
from petra.utils import find_prob_in_model, frequency_bin_width, get_logger

logger = get_logger(__name__)

# Clip bound on the inclusion probabilities that go *into* the spike-slab cost,
# the role `eps` plays in the relabeling loop: a slot that is present in every
# sample has p = 1, and the absent-sample term log(1 - p) would be -inf, which
# would make every cost comparison involving it NaN.  It is never applied to the
# array a returned PosteriorChain carries; that one is recomputed unclipped from
# the returned chain by petra.relabel._with_unclipped_prob_in_model.
_COST_EPS: float = 1e-6

#: The parameters :func:`merge_sources` used to accept positionally, after
#: ``posterior_chain`` and ``obs_time_yrs``, paired with their signature
#: defaults.  Kept in declaration order so a legacy positional call can be
#: mapped back onto keyword names; ``tests/test_merge_sources.py`` checks the
#: table against the real signature so the two cannot drift apart.
MERGE_SOURCES_LEGACY_POSITIONAL: tuple[tuple[str, Any], ...] = (
    ("freq_param_index", 0),
    ("max_freq_std_bins", 6.0),
    ("max_merge_distance_bins", 10.0),
    ("max_co_occurrence", 0.1),
    ("min_valid_samples", 50),
    ("knots", 16),
    ("rng_seed", 0),
    ("threshold_samples", 50),
    ("patience", 20),
    ("learning_rate", 1e-3),
    ("max_epochs", 800),
    ("flow_layers", 8),
    ("progress", True),
)


def _resolve_legacy_positional(func_name: str,
                               spec: tuple[tuple[str, Any], ...],
                               positional: tuple,
                               current: dict) -> dict:
    """
    Map a legacy positional call back onto keyword arguments.

    Parameters
    ----------
    func_name : str
        Name of the function being called, for the messages.
    spec : tuple of (str, object)
        The parameter names that used to be positional, in order, paired with
        their signature defaults.
    positional : tuple
        The extra positional arguments the function swallowed.
    current : dict
        The values the caller passed (or defaulted to) by keyword, keyed by
        parameter name.

    Returns
    -------
    merged : dict
        `current`, with the positional values applied on top.

    Raises
    ------
    TypeError
        If more positional arguments are supplied than the old signature had,
        or if one of them was also passed by keyword.

    Warns
    -----
    DeprecationWarning
        Naming the keywords the positional arguments were mapped to.

    Examples
    --------
    >>> import warnings
    >>> spec = (("a", 0), ("b", 1))
    >>> with warnings.catch_warnings():
    ...     warnings.simplefilter("ignore", DeprecationWarning)
    ...     _resolve_legacy_positional("f", spec, (7,), {"a": 0, "b": 1})
    {'a': 7, 'b': 1}
    >>> with warnings.catch_warnings():
    ...     warnings.simplefilter("ignore", DeprecationWarning)
    ...     _resolve_legacy_positional("f", spec, (7,), {"a": 5, "b": 1})
    Traceback (most recent call last):
        ...
    TypeError: f() got 'a' both positionally and by keyword; pass one, not both.
    >>> _resolve_legacy_positional("f", spec, (7, 8, 9), {"a": 0, "b": 1})
    Traceback (most recent call last):
        ...
    TypeError: f() takes 2 positional arguments but 5 were given.
    """
    if len(positional) > len(spec):
        raise TypeError(
            f"{func_name}() takes 2 positional arguments but "
            f"{len(positional) + 2} were given."
        )

    names = [name for name, _ in spec[:len(positional)]]
    warnings.warn(
        f"Passing {', '.join(repr(name) for name in names)} positionally to "
        f"{func_name}() is deprecated; pass them by keyword instead.",
        DeprecationWarning, stacklevel=3,
    )

    merged = dict(current)
    for (name, default), value in zip(spec, positional):
        if current[name] != default:
            raise TypeError(
                f"{func_name}() got {name!r} both positionally and by keyword; "
                f"pass one, not both."
            )
        merged[name] = value
    return merged


def _source_frequency_stats(chain: np.ndarray,
                            freq_param_index: int,
                            min_valid_samples: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Per-source frequency mean and standard deviation.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params)
        Posterior samples with NaN for absent sources.
    freq_param_index : int
        Index of the frequency parameter.
    min_valid_samples : int
        A source needs at least this many samples in which it is present before
        its statistics are trusted.

    Returns
    -------
    mean_freq : ndarray, shape (n_sources,)
        Mean frequency of each source, NaN where there is too little data.
    std_freq : ndarray, shape (n_sources,)
        Standard deviation of each source's frequency, NaN likewise.
    well_sampled : ndarray of bool, shape (n_sources,)
        True where the source cleared `min_valid_samples`.

    Examples
    --------
    >>> import numpy as np
    >>> chain = np.array([[[1.0], [np.nan]], [[3.0], [np.nan]]])
    >>> mean, std, ok = _source_frequency_stats(chain, 0, min_valid_samples=2)
    >>> mean.tolist(), std.tolist(), ok.tolist()
    ([2.0, nan], [1.0, nan], [True, False])
    """
    n_sources = chain.shape[1]
    mean_freq = np.full(n_sources, np.nan)
    std_freq = np.full(n_sources, np.nan)
    well_sampled = np.zeros(n_sources, dtype=bool)

    for i in range(n_sources):
        freq_data = chain[:, i, freq_param_index]
        valid = freq_data[~np.isnan(freq_data)]
        if len(valid) < min_valid_samples:
            continue
        mean_freq[i] = np.mean(valid)
        std_freq[i] = np.std(valid)
        well_sampled[i] = True

    return mean_freq, std_freq, well_sampled


def _veto_broad_sources(std_freq: np.ndarray,
                        well_sampled: np.ndarray,
                        max_freq_std: float) -> np.ndarray:
    """
    Drop sources whose frequency posterior is too wide to be a split mode.

    Parameters
    ----------
    std_freq : ndarray, shape (n_sources,)
        Per-source frequency standard deviation in Hz, from
        :func:`_source_frequency_stats`.
    well_sampled : ndarray of bool, shape (n_sources,)
        Which sources had enough samples for those statistics.
    max_freq_std : float
        Largest standard deviation, in Hz, a source may have and still be
        considered.

    Returns
    -------
    considered : ndarray of bool, shape (n_sources,)
        `well_sampled` with the broad sources cleared.

    Examples
    --------
    >>> import numpy as np
    >>> _veto_broad_sources(np.array([1.0, 5.0]), np.array([True, True]), 2.0).tolist()
    [True, False]
    """
    return well_sampled & ~(well_sampled & (std_freq > max_freq_std))


def _pair_merge_candidates(chain: np.ndarray,
                           mean_freq: np.ndarray,
                           considered: np.ndarray,
                           *,
                           freq_param_index: int,
                           max_merge_distance: float,
                           max_co_occurrence: float) -> list[tuple[int, int, float, float]]:
    """
    Pair up the surviving sources that are close in frequency and rarely coexist.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params)
        Posterior samples with NaN for absent sources.
    mean_freq : ndarray, shape (n_sources,)
        Per-source mean frequency in Hz.
    considered : ndarray of bool, shape (n_sources,)
        Which sources survived :func:`_veto_broad_sources`.
    freq_param_index : int
        Index of the frequency parameter, also used as the occupancy test.
    max_merge_distance : float
        Largest separation in Hz between two mean frequencies.
    max_co_occurrence : float
        Largest fraction of samples in which both members of a pair may be
        present.

    Returns
    -------
    candidates : list of (int, int, float, float)
        ``(source_a, source_b, freq_distance_hz, co_occurrence)``, sorted by
        frequency distance ascending.

    Examples
    --------
    >>> import numpy as np
    >>> chain = np.array([[[1.0], [np.nan]], [[np.nan], [1.5]]])
    >>> _pair_merge_candidates(chain, np.array([1.0, 1.5]), np.array([True, True]),
    ...                        freq_param_index=0, max_merge_distance=1.0,
    ...                        max_co_occurrence=0.1)
    [(0, 1, 0.5, 0.0)]
    """
    n_samples = chain.shape[0]
    candidates: list[tuple[int, int, float, float]] = []
    valid_indices = np.where(considered)[0]

    for idx_a in range(len(valid_indices)):
        for idx_b in range(idx_a + 1, len(valid_indices)):
            i = int(valid_indices[idx_a])
            j = int(valid_indices[idx_b])

            freq_distance = abs(mean_freq[i] - mean_freq[j])
            if freq_distance > max_merge_distance:
                continue

            present_i = ~np.isnan(chain[:, i, freq_param_index])
            present_j = ~np.isnan(chain[:, j, freq_param_index])
            co_occurrence = np.sum(present_i & present_j) / n_samples

            if co_occurrence > max_co_occurrence:
                continue

            candidates.append((i, j, float(freq_distance), float(co_occurrence)))

    candidates.sort(key=lambda candidate: candidate[2])
    return candidates


def _validate_chain_array(chain: Any, num_sources: int | None = None) -> np.ndarray:
    """
    Check that `chain` is a numeric ``(n_samples, n_sources, n_params)`` block.

    Every function in this module indexes the source axis and the parameter axis
    directly, so -- unlike :class:`~petra.posterior_chain.PosteriorChain`, which
    is told what the two axes are and can therefore accept a flattened chain --
    only the three dimensional layout can be used here: a ``(n_samples,
    n_sources * n_params)`` array carries nothing that says where the split
    falls.  Passing one used to raise ``IndexError: tuple index out of range``
    from inside numpy, naming neither the argument nor the layout expected.

    Parameters
    ----------
    chain : array_like
        Candidate chain.
    num_sources : int, optional
        Number of source slots the caller already knows the chain must have.
        When given, a chain whose source axis disagrees is rejected rather than
        indexed into.

    Returns
    -------
    array : ndarray
        `chain` as a numpy array, three dimensional and numeric.

    Raises
    ------
    ValueError
        If `chain` is not three dimensional, does not hold numbers, or has a
        source axis of a length other than `num_sources`.

    Examples
    --------
    >>> import numpy as np
    >>> _validate_chain_array(np.zeros((4, 2, 3))).shape
    (4, 2, 3)
    >>> _validate_chain_array(np.zeros((4, 6)))
    Traceback (most recent call last):
        ...
    ValueError: chain must be a three dimensional array of shape (n_samples, n_sources, n_params), got shape (4, 6).
    >>> _validate_chain_array(np.zeros((4, 2, 3)), num_sources=3)
    Traceback (most recent call last):
        ...
    ValueError: chain has shape (4, 2, 3), which is inconsistent with num_sources=3 and num_params_per_source=3; expected shape (n_samples, 3, 3).
    """
    array = np.asarray(chain)
    if array.ndim != 3:
        raise ValueError(
            f"chain must be a three dimensional array of shape "
            f"(n_samples, n_sources, n_params), got shape {array.shape}."
        )

    # PosteriorChain already owns the wording for "that is not a chain"; reusing
    # its two checks keeps one message per failure across the package instead of
    # a second, differently phrased one here.
    _validate_numeric_array(array, array.shape[1], array.shape[2])
    if num_sources is not None:
        _validate_chain_shape(array, num_sources, array.shape[2])
    return array


def _validate_freq_param_index(num_params: int, freq_param_index: int) -> None:
    """
    Check that `freq_param_index` addresses a column of the chain.

    Parameters
    ----------
    num_params : int
        Number of parameters per source in the chain.
    freq_param_index : int
        Index of the frequency parameter, which is also the occupancy test.

    Returns
    -------
    None

    Raises
    ------
    ValueError
        If `freq_param_index` is not an integer in ``[0, num_params)``.

    Examples
    --------
    >>> _validate_freq_param_index(3, 2)
    >>> _validate_freq_param_index(3, 3)
    Traceback (most recent call last):
        ...
    ValueError: freq_param_index must be in [0, 3), got 3; the chain has 3 parameters per source.
    """
    if not isinstance(freq_param_index, (int, np.integer)) or not 0 <= freq_param_index < num_params:
        raise ValueError(
            f"freq_param_index must be in [0, {num_params}), got {freq_param_index}; "
            f"the chain has {num_params} parameters per source."
        )


def _validate_pair_arguments(chain: Any,
                             source_a: int,
                             source_b: int,
                             freq_param_index: int,
                             num_sources: int | None = None) -> tuple[np.ndarray, int, int]:
    """
    Validate the ``(chain, slot, slot, parameter index)`` quartet of a pair operation.

    Parameters
    ----------
    chain : array_like, shape (n_samples, n_sources, n_params)
        Posterior samples with NaN for absent sources.
    source_a, source_b : int
        Source slot indices, which must be two different slots of `chain`.
    freq_param_index : int
        Index of the frequency parameter.
    num_sources : int, optional
        Number of source slots the caller already knows the chain must have,
        forwarded to :func:`_validate_chain_array`.

    Returns
    -------
    array : ndarray
        `chain` as a numpy array.
    source_a, source_b : int
        The two indices as plain ints.

    Raises
    ------
    ValueError
        If `chain` is not a valid chain, if either index does not address a slot
        of it, or if the two indices are the same slot.

    Examples
    --------
    >>> import numpy as np
    >>> _validate_pair_arguments(np.zeros((4, 2, 1)), 0, 1, 0)[1:]
    (0, 1)
    >>> _validate_pair_arguments(np.zeros((4, 2, 1)), 0, 2, 0)
    Traceback (most recent call last):
        ...
    ValueError: source_b must be in [0, 2), got 2; the chain has 2 source slots.
    >>> _validate_pair_arguments(np.zeros((4, 2, 1)), 1, 1, 0)
    Traceback (most recent call last):
        ...
    ValueError: source_a and source_b must be different slots, got 1 twice.
    """
    array = _validate_chain_array(chain, num_sources=num_sources)
    _validate_freq_param_index(array.shape[2], freq_param_index)

    n_sources = array.shape[1]
    indices = []
    for name, value in (("source_a", source_a), ("source_b", source_b)):
        # A negative index would not raise: numpy would quietly wrap it round to
        # a slot at the other end of the chain and merge that one instead.
        if not isinstance(value, (int, np.integer)) or not 0 <= value < n_sources:
            raise ValueError(
                f"{name} must be in [0, {n_sources}), got {value}; "
                f"the chain has {n_sources} source slots."
            )
        indices.append(int(value))

    # Merging a slot with itself is not a no-op: slot b is emptied after slot a
    # has been filled from it, so the one slot involved would be left all-NaN
    # and its samples lost.
    if indices[0] == indices[1]:
        raise ValueError(
            f"source_a and source_b must be different slots, got {indices[0]} twice."
        )

    return array, indices[0], indices[1]


def _validate_merge_settings(num_params: int,
                             obs_time_yrs: float,
                             freq_param_index: int,
                             max_co_occurrence: float) -> float:
    """
    Validate the settings shared by every entry point of this module.

    Parameters
    ----------
    num_params : int
        Number of parameters per source in the chain.
    obs_time_yrs : float
        Observation time in years.  Must be strictly positive.
    freq_param_index : int
        Index of the frequency parameter.  Must address a column of the chain.
    max_co_occurrence : float
        Maximum fraction of samples in which both members of a pair may be
        present.  Must lie in ``(0, 1]``.

    Returns
    -------
    delta_freq : float
        Width of one Fourier frequency bin in Hz, ``1 / (obs_time_yrs * T_year)``.

    Raises
    ------
    ValueError
        If any setting is outside its allowed range.

    Examples
    --------
    >>> round(_validate_merge_settings(8, 1.0, 0, 0.1), 12)
    3.171e-08
    >>> _validate_merge_settings(8, 1.0, 8, 0.1)
    Traceback (most recent call last):
        ...
    ValueError: freq_param_index must be in [0, 8), got 8; the chain has 8 parameters per source.
    >>> _validate_merge_settings(8, 1.0, 0, 0.0)
    Traceback (most recent call last):
        ...
    ValueError: max_co_occurrence must be in (0, 1], got 0.0.
    """
    # frequency_bin_width raises for a non-positive (or NaN) observation time.
    delta_freq = frequency_bin_width(obs_time_yrs)

    _validate_freq_param_index(num_params, freq_param_index)

    if not 0 < max_co_occurrence <= 1:
        raise ValueError(f"max_co_occurrence must be in (0, 1], got {max_co_occurrence}.")

    return delta_freq


def identify_merge_candidates(chain: np.ndarray,
                              obs_time_yrs: float,
                              *deprecated_positional: Any,
                              freq_param_index: int = 0,
                              max_freq_std_bins: float = 6.0,
                              max_merge_distance_bins: float = 10.0,
                              max_co_occurrence: float = 0.1,
                              min_valid_samples: int = 50,
                              prob_in_model: np.ndarray | None = None) -> list[tuple[int, int]]:
    """
    Find candidate pairs of sources that may be split modes of a single source.

    Three steps, one function each: per-source frequency statistics
    (:func:`_source_frequency_stats`), a veto on sources whose frequency
    posterior is too broad to be half of a split mode
    (:func:`_veto_broad_sources`), and the pairing of what survives
    (:func:`_pair_merge_candidates`).

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params)
        Posterior samples with NaN for absent sources.
    obs_time_yrs : float
        Observation time in years.  Sets the frequency bin width the two
        distance thresholds below are measured in.
    freq_param_index : int, default 0
        Which parameter index is frequency.
    max_freq_std_bins : float, default 6
        Veto sources whose frequency standard deviation exceeds this many
        frequency bins (``max_freq_std_bins / T_obs`` Hz).
    max_merge_distance_bins : float, default 10
        Only consider pairs whose mean frequencies lie within this many
        frequency bins (``max_merge_distance_bins / T_obs`` Hz).
    max_co_occurrence : float, default 0.1
        Veto pairs where both sources are present in more than this
        fraction of samples.
    min_valid_samples : int, default 50
        A source needs at least this many samples in which it is present
        before its frequency mean and standard deviation are trusted.

    Returns
    -------
    candidates : list of (int, int)
        Candidate pairs sorted by frequency distance (ascending).

    Other Parameters
    ----------------
    prob_in_model : ndarray, optional
        Deprecated and ignored.  The candidate search is driven entirely by
        which entries of `chain` are NaN, so the inclusion probabilities were
        never read; passing them (positionally, as the old second argument, or
        by keyword) emits a :class:`DeprecationWarning`.

    Raises
    ------
    ValueError
        If `chain` is not a numeric ``(n_samples, n_sources, n_params)`` array,
        `obs_time_yrs` is not positive, `freq_param_index` does not address a
        column of `chain`, or `max_co_occurrence` is outside ``(0, 1]``.

    Examples
    --------
    >>> import numpy as np
    >>> from petra.utils import frequency_bin_width
    >>> rng = np.random.default_rng(0)
    >>> delta_freq = frequency_bin_width(1.0)
    >>> chain = np.full((200, 2, 1), np.nan)
    >>> # two slots two bins apart, never present in the same sample
    >>> chain[:100, 0, 0] = 1e-3 + delta_freq * rng.normal(size=100)
    >>> chain[100:, 1, 0] = 1e-3 + 2 * delta_freq + delta_freq * rng.normal(size=100)
    >>> identify_merge_candidates(chain, obs_time_yrs=1.0)
    [(0, 1)]
    >>> identify_merge_candidates(chain, obs_time_yrs=1.0, max_merge_distance_bins=1)
    []
    """
    if deprecated_positional:
        if len(deprecated_positional) > 1:
            raise TypeError(
                "identify_merge_candidates() takes at most 3 positional arguments; its "
                "signature is (chain, obs_time_yrs, *, freq_param_index=0, ...)."
            )
        # Legacy call: identify_merge_candidates(chain, prob_in_model, obs_time_yrs, ...)
        warnings.warn(
            "identify_merge_candidates() no longer takes prob_in_model; it was never "
            "read. Call identify_merge_candidates(chain, obs_time_yrs, ...) instead.",
            DeprecationWarning, stacklevel=2,
        )
        obs_time_yrs = deprecated_positional[0]
    elif prob_in_model is not None:
        warnings.warn(
            "The prob_in_model argument of identify_merge_candidates() is deprecated "
            "and ignored; it was never read. Drop it from the call.",
            DeprecationWarning, stacklevel=2,
        )

    chain = _validate_chain_array(chain)
    delta_freq = _validate_merge_settings(chain.shape[2], obs_time_yrs, freq_param_index,
                                          max_co_occurrence)

    mean_freq, std_freq, well_sampled = _source_frequency_stats(
        chain, freq_param_index, min_valid_samples)

    considered = _veto_broad_sources(std_freq, well_sampled,
                                     max_freq_std_bins * delta_freq)

    candidates = _pair_merge_candidates(
        chain, mean_freq, considered,
        freq_param_index=freq_param_index,
        max_merge_distance=max_merge_distance_bins * delta_freq,
        max_co_occurrence=max_co_occurrence,
    )

    # Log diagnostics
    if candidates:
        logger.info("Found %d merge candidate pair(s):", len(candidates))
        for i, j, freq_distance, co_occurrence in candidates:
            logger.info("  Sources (%d, %d): freq distance = %.1f bins, co-occurrence = %.3f",
                        i, j, freq_distance / delta_freq, co_occurrence)
    else:
        logger.info("No merge candidates found.")

    return [(c[0], c[1]) for c in candidates]


def fit_source_flow(source_data: np.ndarray,
                    rng_seed: int = 0,
                    knots: int = 16,
                    threshold_samples: int = 50,
                    patience: int = 20,
                    learning_rate: float = 1e-3,
                    max_epochs: int = 800,
                    flow_layers: int = 8,
                    progress: bool = True) -> Any | None:
    """
    Fit a normalizing flow to source data using coppuccino.

    Parameters
    ----------
    source_data : ndarray, shape (n_valid_samples, n_params)
        Non-NaN samples for this source.
    rng_seed : int, default 0
        Random seed for flow training.
    knots : int, default 16
        Number of spline knots.
    threshold_samples : int, default 50
        Minimum samples needed. Returns None if fewer.
    patience : int, default 20
        Early stopping patience.
    learning_rate : float, default 1e-3
        Training learning rate.
    max_epochs : int, default 800
        Maximum training epochs.
    flow_layers : int, default 8
        Number of flow layers.
    progress : bool, default True
        Show the training progress bar.

    Returns
    -------
    flow : object or None
        Trained flow with .log_prob(), or None if insufficient data.
    """
    if len(source_data) < threshold_samples:
        return None

    # coppuccino's normalizing_flows_fit has no show_progress keyword, so `progress`
    # is honoured by silencing the bar rather than by not drawing it. See
    # petra.flow_utils.quiet_external_fit.
    with quiet_external_fit(not progress):
        return normalizing_flows_fit(
            source_data,
            rng_seed=rng_seed,
            knots=knots,
            patience=patience,
            learning_rate=learning_rate,
            max_epochs=max_epochs,
            flow_layers=flow_layers,
        )


def compute_pair_cost(chain: np.ndarray,
                      source_a: int,
                      source_b: int,
                      flow_a: Any,
                      flow_b: Any,
                      flow_merged: Any,
                      prob_in_model: np.ndarray,
                      freq_param_index: int = 0) -> tuple[float, float]:
    """
    Spike-slab cost comparison between 2-source and 1-source models.

    Both hypotheses are scored on *the same data*.  For a sample in which both
    slots are occupied, the two-source model contributes
    ``log p_a + log f_a(x_a) + log p_b + log f_b(x_b)`` and the one-source
    model contributes ``log p_merged + log f_merged(x_a) + log f_merged(x_b)``:
    the merged source has to explain both points, because both points were
    observed.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params)
        Posterior chain.
    source_a, source_b : int
        Source slot indices.
    flow_a, flow_b : Transformed
        Individual flows for each source.
    flow_merged : Transformed
        Flow fit to merged data.
    prob_in_model : ndarray, shape (n_sources,)
        Per-source presence probabilities.  Clipped into
        ``[eps, 1 - eps]`` on the way in, so an unclipped array -- a 0.0 for a
        freed slot, a 1.0 for a source present in every sample -- is accepted.
    freq_param_index : int, default 0
        Parameter index used to decide whether a slot is occupied in a sample.

    Returns
    -------
    cost_2source : float
        Total cost under 2-source model.
    cost_1source : float
        Total cost under 1-source model (merged into slot a, slot b freed).

    Raises
    ------
    ValueError
        If `chain` is not a numeric ``(n_samples, n_sources, n_params)`` array,
        if `prob_in_model` is not one probability per slot of it, if either
        source index does not address a slot, if the two are the same slot, or
        if `freq_param_index` does not address a parameter.

    Notes
    -----
    Non-finite flow densities are floored at
    :data:`petra.flow_utils.DEFAULT_LOG_PROB_FLOOR`, so a point the flow
    considers impossible costs a large but finite amount.

    The freed slot *b* is absent in every sample of the one-source model and so
    contributes ``log(1 - 0) = 0``; it is omitted rather than added.

    An earlier version dropped ``log f_merged(x_b)`` when both slots were
    occupied, which scored the two hypotheses on different data.  For the
    narrow posteriors this module is applied to, ``log f`` is large and
    positive, so the omission biased the comparison against merging.

    Examples
    --------
    >>> import numpy as np
    >>> from petra.utils import UniformPrior
    >>> narrow = UniformPrior([0.0], [1.0])          # log density 0
    >>> wide = UniformPrior([0.0], [np.e])           # log density -1
    >>> chain = np.array([[[0.5], [0.5]], [[np.nan], [np.nan]]])
    >>> prob_in_model = np.array([0.5, 0.5])
    >>> cost_2, cost_1 = compute_pair_cost(chain, 0, 1, narrow, narrow, wide,
    ...                                    prob_in_model)
    >>> round(cost_2, 4), round(cost_1, 4)     # 4 log(1/2), 2 log(1/2) - 2
    (-2.7726, -3.3863)
    """
    # One probability per slot: a prob_in_model of the wrong length would not
    # raise, it would score the pair with some other source's probability.
    prob_in_model = np.asarray(prob_in_model)
    if prob_in_model.ndim != 1:
        raise ValueError(
            f"prob_in_model must be a one dimensional array of per-source "
            f"probabilities, got shape {prob_in_model.shape}."
        )
    chain, source_a, source_b = _validate_pair_arguments(
        chain, source_a, source_b, freq_param_index,
        num_sources=prob_in_model.shape[0])

    # Clipped here as well as in the caller: a PosteriorChain now carries
    # unclipped probabilities, so feeding one straight back in is the obvious
    # thing to do, and `np.where` evaluates both of its branches -- log(0) or
    # log1p(-1) would warn and return -inf for a term that is then discarded.
    p_a = np.clip(prob_in_model[source_a], _COST_EPS, 1 - _COST_EPS)
    p_b = np.clip(prob_in_model[source_b], _COST_EPS, 1 - _COST_EPS)

    present_a = ~np.isnan(chain[:, source_a, freq_param_index])
    present_b = ~np.isnan(chain[:, source_b, freq_param_index])
    # Merged probability: fraction of samples where either is present
    p_merged = np.clip(np.mean(present_a | present_b), _COST_EPS, 1 - _COST_EPS)

    x_a = chain[:, source_a, :]
    x_b = chain[:, source_b, :]

    # One batched call per (flow, slot) pair instead of one call per sample.
    log_f_a = np.asarray(safe_flow_log_prob(flow_a, x_a))
    log_f_b = np.asarray(safe_flow_log_prob(flow_b, x_b))
    log_f_merged_a = np.asarray(safe_flow_log_prob(flow_merged, x_a))
    log_f_merged_b = np.asarray(safe_flow_log_prob(flow_merged, x_b))

    # --- 2-source model ---
    cost_2source = (
        np.sum(np.where(present_a, np.log(p_a) + log_f_a, np.log1p(-p_a)))
        + np.sum(np.where(present_b, np.log(p_b) + log_f_b, np.log1p(-p_b)))
    )

    # --- 1-source model (merged into slot a, slot b freed) ---
    either_present = present_a | present_b
    cost_1source = (
        np.sum(np.where(either_present, np.log(p_merged), np.log1p(-p_merged)))
        + np.sum(log_f_merged_a[present_a])
        + np.sum(log_f_merged_b[present_b])
    )

    return float(cost_2source), float(cost_1source)


def merge_pair_in_chain(chain: np.ndarray,
                        source_a: int,
                        source_b: int,
                        freq_param_index: int = 0) -> np.ndarray:
    """
    Merge two source slots in the chain.

    Slot a receives all data from both slots. When both are present in a
    sample, slot a's value is kept. Slot b becomes all NaN.

    Parameters
    ----------
    chain : ndarray, shape (n_samples, n_sources, n_params)
        Posterior chain.
    source_a, source_b : int
        Source slot indices to merge.
    freq_param_index : int, default 0
        Parameter index used to decide whether a slot is occupied in a sample.

    Returns
    -------
    merged_chain : ndarray
        Copy of chain with sources merged.

    Raises
    ------
    ValueError
        If `chain` is not a numeric ``(n_samples, n_sources, n_params)`` array,
        if either source index does not address a slot of it, if the two are the
        same slot, or if `freq_param_index` does not address a parameter.

    Examples
    --------
    >>> import numpy as np
    >>> chain = np.array([[[1.0], [2.0]],
    ...                   [[np.nan], [3.0]],
    ...                   [[4.0], [np.nan]]])
    >>> merge_pair_in_chain(chain, 0, 1)[:, :, 0]
    array([[ 1., nan],
           [ 3., nan],
           [ 4., nan]])
    """
    chain, source_a, source_b = _validate_pair_arguments(chain, source_a, source_b,
                                                         freq_param_index)
    merged = chain.copy()

    present_a = ~np.isnan(chain[:, source_a, freq_param_index])
    present_b = ~np.isnan(chain[:, source_b, freq_param_index])

    # Move b's data into slot a wherever only b is present
    move = present_b & ~present_a
    merged[move, source_a, :] = chain[move, source_b, :]

    # Slot b always becomes NaN
    merged[:, source_b, :] = np.nan

    return merged


def merge_sources(posterior_chain: PosteriorChain,
                  obs_time_yrs: float,
                  *deprecated_positional: Any,
                  freq_param_index: int = 0,
                  max_freq_std_bins: float = 6.0,
                  max_merge_distance_bins: float = 10.0,
                  max_co_occurrence: float = 0.1,
                  min_valid_samples: int = 50,
                  knots: int = 16,
                  rng_seed: int = 0,
                  threshold_samples: int = 50,
                  patience: int = 20,
                  learning_rate: float = 1e-3,
                  max_epochs: int = 800,
                  flow_layers: int = 8,
                  progress: bool = True) -> PosteriorChain:
    """
    Top-level API: identify and merge source slots that are split modes.

    After Gaussian relabeling, bimodal frequency posteriors get split into
    separate source slots. This function tests whether nearby pairs are
    better described as one source using normalizing flows and spike-slab
    cost comparison.

    Parameters
    ----------
    posterior_chain : PosteriorChain
        Chain after relabeling (e.g., from make_catalog_mv_normal).
    obs_time_yrs : float
        Observation time in years.  Sets the frequency bin width
        ``1 / T_obs`` in Hz that the two thresholds below are measured in.
    freq_param_index : int, default 0
        Which parameter index is frequency.  Also decides whether a slot is
        occupied in a given sample.
    max_freq_std_bins : float, default 6
        Veto sources with a frequency standard deviation above this many bins.
    max_merge_distance_bins : float, default 10
        Only consider pairs within this many bins.
    max_co_occurrence : float, default 0.1
        Veto pairs where both present > this fraction.
    min_valid_samples : int, default 50
        Minimum number of samples in which a source must be present before its
        frequency statistics are trusted.
    knots : int, default 16
        Spline knots for flow.
    rng_seed : int, default 0
        Random seed for flow training.
    threshold_samples : int, default 50
        Minimum number of samples needed to fit a flow.  A pair whose flows
        cannot be fit is skipped.
    patience : int, default 20
        Early stopping patience for flow training.
    learning_rate : float, default 1e-3
        Learning rate for flow training.
    max_epochs : int, default 800
        Maximum training epochs for flow training.
    flow_layers : int, default 8
        Number of flow layers.
    progress : bool, default True
        Show the flow training progress bars.

    Returns
    -------
    result : PosteriorChain
        Updated chain with merged sources. Freed slots are all-NaN.  The
        input's ``cost_dict`` is carried over unchanged, and ``prob_in_model``
        is recomputed from the returned samples without clipping, so a freed
        slot reads exactly ``0.0`` and an always-present source exactly ``1.0``.

    Other Parameters
    ----------------
    *deprecated_positional
        Everything after `obs_time_yrs` is keyword-only.  Positional arguments
        are still mapped onto the old parameter order
        (:data:`MERGE_SOURCES_LEGACY_POSITIONAL`) for one release, with a
        :class:`DeprecationWarning`.

    Raises
    ------
    ValueError
        If `obs_time_yrs` is not positive, `freq_param_index` does not address
        a column of the chain, or `max_co_occurrence` is outside ``(0, 1]``.
    TypeError
        If more positional arguments are given than the old signature accepted,
        or if one of them is also passed by keyword.

    Notes
    -----
    The 13 settings below used to be positional-or-keyword, which made a call
    like ``merge_sources(pc, 1.0, 0, 6.0, 10.0, 0.1)`` both legal and
    unreadable, and made inserting a parameter a breaking change.  They are now
    keyword-only.

    The inclusion probabilities are computed twice over, for two different
    jobs.  The ones handed to :func:`compute_pair_cost` are clipped into
    ``[eps, 1 - eps]`` because they are read inside a logarithm; the ones the
    returned chain carries are not, because a caller asking "how often was this
    source present?" must be told 1.0 when the answer is always.

    Examples
    --------
    >>> import numpy as np
    >>> from petra.posterior_chain import PosteriorChain
    >>> chain = np.full((60, 2, 1), np.nan)
    >>> chain[:30, 0, 0] = 1e-3
    >>> chain[30:, 1, 0] = 2e-3
    >>> pc = PosteriorChain(chain, 2, 1, trans_dimensional=True)
    >>> # far apart in frequency: no candidate pair, so no flow is ever fit
    >>> merged = merge_sources(pc, obs_time_yrs=1.0, progress=False)
    >>> merged.chain.shape
    (60, 2, 1)
    >>> merged.prob_in_model            # unclipped: each slot is in half the samples
    array([0.5, 0.5])
    """
    if deprecated_positional:
        settings = _resolve_legacy_positional(
            "merge_sources", MERGE_SOURCES_LEGACY_POSITIONAL, deprecated_positional,
            {
                "freq_param_index": freq_param_index,
                "max_freq_std_bins": max_freq_std_bins,
                "max_merge_distance_bins": max_merge_distance_bins,
                "max_co_occurrence": max_co_occurrence,
                "min_valid_samples": min_valid_samples,
                "knots": knots,
                "rng_seed": rng_seed,
                "threshold_samples": threshold_samples,
                "patience": patience,
                "learning_rate": learning_rate,
                "max_epochs": max_epochs,
                "flow_layers": flow_layers,
                "progress": progress,
            },
        )
        freq_param_index = settings["freq_param_index"]
        max_freq_std_bins = settings["max_freq_std_bins"]
        max_merge_distance_bins = settings["max_merge_distance_bins"]
        max_co_occurrence = settings["max_co_occurrence"]
        min_valid_samples = settings["min_valid_samples"]
        knots = settings["knots"]
        rng_seed = settings["rng_seed"]
        threshold_samples = settings["threshold_samples"]
        patience = settings["patience"]
        learning_rate = settings["learning_rate"]
        max_epochs = settings["max_epochs"]
        flow_layers = settings["flow_layers"]
        progress = settings["progress"]

    chain = posterior_chain.chain.copy()
    n_sources = posterior_chain.num_sources
    num_params_per_source = posterior_chain.num_params_per_source
    cost_dict = dict(posterior_chain.cost_dict or {})

    _validate_merge_settings(chain.shape[2], obs_time_yrs, freq_param_index,
                             max_co_occurrence)

    # Clipped, because this array is an input to compute_pair_cost, where an
    # always-present slot's log(1 - p) would otherwise be -inf.  The array the
    # returned chain carries is a different one; see the returns below.
    prob_in_model = find_prob_in_model(chain, n_sources, eps=_COST_EPS)

    # Identify candidates
    candidates = identify_merge_candidates(
        chain, obs_time_yrs,
        freq_param_index=freq_param_index,
        max_freq_std_bins=max_freq_std_bins,
        max_merge_distance_bins=max_merge_distance_bins,
        max_co_occurrence=max_co_occurrence,
        min_valid_samples=min_valid_samples,
    )

    if not candidates:
        logger.info("No merges to perform.")
        return _with_unclipped_prob_in_model(
            PosteriorChain(
                chain=chain,
                num_sources=n_sources,
                num_params_per_source=num_params_per_source,
                trans_dimensional=posterior_chain.trans_dimensional,
                cost_dict=cost_dict,
            ),
            n_sources,
        )

    key = jr.key(rng_seed)
    flow_kwargs: dict[str, Any] = dict(knots=knots, threshold_samples=threshold_samples,
                                       patience=patience, learning_rate=learning_rate,
                                       max_epochs=max_epochs, flow_layers=flow_layers,
                                       progress=progress)
    merged_sources: set[int] = set()  # Track sources already merged
    n_merged = 0

    for source_a, source_b in candidates:
        # Skip if either source was already merged
        if source_a in merged_sources or source_b in merged_sources:
            logger.info("  Skipping (%d, %d): already merged in prior step.",
                        source_a, source_b)
            continue

        logger.info("Evaluating merge of sources %d and %d...", source_a, source_b)

        # Get non-NaN data for each source
        data_a = chain[:, source_a, :]
        valid_a = data_a[~np.isnan(data_a).any(axis=1)]

        data_b = chain[:, source_b, :]
        valid_b = data_b[~np.isnan(data_b).any(axis=1)]

        # Merged data: combine both
        valid_merged = np.concatenate([valid_a, valid_b], axis=0)

        # Fit 3 flows using coppuccino - generate seeds from the JAX key
        key, k1, k2, k3 = jr.split(key, 4)
        seed_a = int(jr.randint(k1, (), 0, 999999))
        seed_b = int(jr.randint(k2, (), 0, 999999))
        seed_m = int(jr.randint(k3, (), 0, 999999))

        flow_a = fit_source_flow(valid_a, rng_seed=seed_a, **flow_kwargs)
        flow_b = fit_source_flow(valid_b, rng_seed=seed_b, **flow_kwargs)
        flow_merged = fit_source_flow(valid_merged, rng_seed=seed_m, **flow_kwargs)

        if flow_a is None or flow_b is None or flow_merged is None:
            logger.info("  Skipping (%d, %d): insufficient samples for flow fitting.",
                        source_a, source_b)
            continue

        # Compute costs
        cost_2, cost_1 = compute_pair_cost(
            chain, source_a, source_b,
            flow_a, flow_b, flow_merged, prob_in_model,
            freq_param_index=freq_param_index,
        )

        logger.info("  2-source cost: %.1f", cost_2)
        logger.info("  1-source cost: %.1f", cost_1)
        logger.info("  Difference (1source - 2source): %.1f", cost_1 - cost_2)

        # Accept merge if 1-source cost is better (higher log-likelihood)
        if cost_1 > cost_2:
            logger.info("  -> Merging sources %d and %d", source_a, source_b)
            chain = merge_pair_in_chain(chain, source_a, source_b,
                                        freq_param_index=freq_param_index)
            merged_sources.add(source_a)
            merged_sources.add(source_b)
            n_merged += 1
            # The freed slot is absent in every remaining sample and the merged
            # one may now be present in all of them, so this recomputation stays
            # clipped: it is the next candidate pair's cost input, not a result.
            prob_in_model = find_prob_in_model(chain, n_sources, eps=_COST_EPS)
        else:
            logger.info("  -> Keeping sources %d and %d separate", source_a, source_b)

    logger.info("Merged %d pair(s) total.", n_merged)

    # The chain handed back has to describe itself: its prob_in_model is derived
    # from the samples being returned and left unclipped, so a freed slot reads
    # 0.0 and an always-present source 1.0 rather than eps and 1 - eps.  This is
    # the contract every relabeler in petra.relabel honours.
    return _with_unclipped_prob_in_model(
        PosteriorChain(
            chain=chain,
            num_sources=n_sources,
            num_params_per_source=num_params_per_source,
            trans_dimensional=posterior_chain.trans_dimensional,
            cost_dict=cost_dict,
        ),
        n_sources,
    )
