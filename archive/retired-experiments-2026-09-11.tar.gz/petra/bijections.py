"""
Reusable ``flowjax`` bijections for mapping source parameters to a latent space.

A normalizing flow trains best on data that is roughly standard normal, so every
flow-based relabeler in petra sits behind a fixed (non-trainable) transform that
maps one source's parameters into such a space.  This module collects a set of
such transforms: an empirical-marginal-to-Gaussian map
(:class:`EmpiricalMarginalToGaussian`), a uniform-to-normal map
(:class:`NormalToUniform`), plain standardization (:class:`InverseStandardize`),
and the composition of the last two (:class:`NormalToUniformInverseStandardize`).
:func:`make_empirical_cdf_spline` is the numpy-side helper the empirical map is
built from, and is useful on its own.

Conventions
-----------
Direction
    Following ``flowjax``, ``transform_and_log_det`` maps *latent* to *data*
    (``z -> x``) and ``inverse_and_log_det`` maps *data* to *latent*
    (``x -> z``); a ``flowjax.distributions.Transformed`` samples by calling
    ``transform`` on a draw from its base distribution.  Every class here is
    named after its ``transform`` direction, so ``NormalToUniform`` takes a
    standard normal ``z`` to a uniform ``x``.
Shape
    Every bijection here declares ``shape = ()``, i.e. it is univariate: it
    describes *one* parameter of one source.  Stack one per parameter with
    ``flowjax.bijections.Stack`` (wrapped in ``paramax.non_trainable``, since
    these carry fitted constants rather than trainable weights) to get a
    transform for a whole source, and ``jax.vmap`` it to apply it to a batch of
    samples.  The bodies are written elementwise and sum their log-determinant,
    so they also behave sensibly on an array input.  ``shape`` and ``cond_shape``
    are declared as ``ClassVar``, which is how ``flowjax``'s own bijections
    declare them; mypy reads that as overriding an instance variable because it
    does not model equinox's ``AbstractVar``, hence the ``type: ignore[misc]``
    on those eight lines.
Finiteness
    The empirical map clips its CDF into ``[min_eps, 1 - min_eps]`` and floors
    its density at ``min_eps``, so no log-density it produces is ever infinite.
    That is what matters downstream: an infinite log-density becomes a constant
    row of the cost matrix, which makes the Hungarian assignment arbitrary while
    still reporting convergence.  The price is that the exponential tails
    described in :func:`make_empirical_cdf_spline` are swamped by those clamps
    within a fraction of a tail scale, so outside the training range the CDF is
    flat and the transform cannot tell "just outside" from "far outside".

Status
------
This is a standalone toolkit, not part of any relabeler's default path.  The
production standardized-flow relabeler builds its own
:class:`petra.standardized_flows.StandardizationBijection`, and the copula
relabeler gets its marginal transforms from ``coppuccino``.  The classes here are
kept, documented and tested (round trips in ``tests/test_invariants.py``,
behaviour in ``tests/test_bijections.py``) because they are what a user composes
by hand when building a custom ``flowjax`` transform for a chain -- which is
exactly what ``example_notebooks/flows_test.ipynb`` does.  They were previously
duplicated in the deleted ``petra/flows.py``; this module is the single home for
them.
"""

from typing import Callable, ClassVar

import jax
import jax.numpy as jnp
import numpy as np
from flowjax.bijections import AbstractBijection
from interpax._ppoly import PchipInterpolator
from jax.scipy.special import erf, erfinv, ndtr, ndtri
from jax.typing import ArrayLike

from petra.utils import get_logger, process_array

logger = get_logger(__name__)


def make_empirical_cdf_spline(x_grid: np.ndarray,
                              samples: np.ndarray,
                              tail_scale: float | None = None,
                              min_eps: float = 1e-7) -> tuple[np.ndarray, Callable, Callable]:
    """
    Build an empirical CDF spline, and its density, with bounded tails.

    The CDF is the empirical CDF of `samples` evaluated on `x_grid` and
    interpolated monotonically in between.  Outside ``[min(samples),
    max(samples)]`` it is extrapolated as ``min_eps * exp(-distance /
    tail_scale)`` (and the mirror image above) and then clipped, so it never
    reaches 0 or 1 and an out-of-support point keeps a finite log-density.  See
    the Notes: the clip, not the exponential, is what those points actually get.

    Parameters
    ----------
    x_grid : ndarray, shape (n_grid,)
        Points at which to evaluate the empirical CDF.  Need not be sorted; it is
        sorted internally and the returned values are put back in the given order.
    samples : ndarray, shape (n_samples,)
        Training samples for one parameter.  Must not contain NaNs: they would
        propagate through ``np.min``/``np.percentile`` into every returned value.
        Ties are broken by :func:`petra.utils.process_array`, so a repeated value
        does not flatten the CDF.
    tail_scale : float, optional
        Decay length of the exponential tails, in the units of `samples`.  If
        None (default) it is set adaptively to
        ``max(iqr / 4, (max - min) / 10, 0.1)``.
    min_eps : float, default 1e-7
        Smallest probability the CDF is allowed to take; it is clipped into
        ``[min_eps, 1 - min_eps]``.  It is also the amplitude of the exponential
        tails and the floor on the returned density.

    Returns
    -------
    cdf_vals : ndarray, shape (n_grid,)
        Empirical CDF evaluated on `x_grid`, in the order `x_grid` was given.
    cdf_fn : callable
        ``cdf_fn(u: ndarray) -> ndarray`` of the same shape, non-decreasing and
        strictly inside ``(0, 1)``.
    pdf_fn : callable
        ``pdf_fn(u: ndarray) -> ndarray`` of the same shape, strictly positive:
        the derivative of `cdf_fn`, analytic in the tails and a central finite
        difference in the interior.

    Notes
    -----
    The two clamps dominate the tails.  ``min_eps * exp(-d / tail_scale)`` is at
    most `min_eps`, and `cdf_fn` clips at `min_eps` from below, so *every* point
    below ``min(samples)`` comes back as exactly `min_eps` (and every point above
    ``max(samples)`` as exactly ``1 - min_eps``); `pdf_fn` similarly floors at
    `min_eps` within about a tail scale.  Out-of-support points therefore get a
    finite but essentially constant density rather than one that keeps decaying:
    this transform is a guard against infinities, not a model of the tails.

    `pdf_fn` also has a narrow spike at each data bound, where its central
    difference straddles the step between the clamped tail and the first spline
    value.

    Examples
    --------
    >>> import numpy as np
    >>> samples = np.linspace(0.0, 1.0, 101)
    >>> grid = np.linspace(0.0, 1.0, 11)
    >>> cdf_vals, cdf_fn, pdf_fn = make_empirical_cdf_spline(grid, samples)
    >>> cdf_vals.shape
    (11,)
    >>> bool(0.4 < cdf_fn(np.array([0.5]))[0] < 0.6)
    True
    >>> cdf_fn(np.array([-0.5, -10.0]))         # flat, and never 0
    array([1.e-07, 1.e-07])
    """
    # 1. Sort the grid
    x_grid = np.asarray(x_grid)
    sort_idx = np.argsort(x_grid)
    xg = x_grid[sort_idx]

    # 2. Empirical CDF
    sorted_chain = process_array(samples)
    counts = np.searchsorted(sorted_chain, xg, side='right')
    cdf_vals = counts / len(sorted_chain)

    # 3. Data bounds and adaptive tail scale
    data_min, data_max = np.min(samples), np.max(samples)

    if tail_scale is None:
        # Adaptive tail scale based on data characteristics
        q25, q75 = np.percentile(samples, [25, 75])
        iqr = q75 - q25
        data_range = data_max - data_min
        tail_scale = max(iqr / 4, data_range / 10, 0.1)  # Ensure minimum scale

    # 4. Create monotonic spline for interior region
    try:
        cs: Callable = PchipInterpolator(xg, cdf_vals, extrapolate=False, check=False)
    except ValueError as error:
        # Fallback to simple linear interpolation. The reason is worth seeing:
        # it is usually a duplicated grid point, i.e. a degenerate marginal.
        logger.warning("PchipInterpolator failed (%s); falling back to linear interpolation.", error)
        from scipy.interpolate import interp1d
        cs = interp1d(xg, cdf_vals, kind='linear', bounds_error=False, fill_value=(0, 1))

    def _regions(u: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Split `u` into below-range, above-range and in-range masks."""
        u = np.asarray(u, dtype=float)
        below = u < data_min
        above = u > data_max
        return u, below, above, ~(below | above)

    def cdf_fn(u: np.ndarray) -> np.ndarray:
        """
        Empirical CDF with clamped exponential tails.

        Parameters
        ----------
        u : ndarray
            Points at which to evaluate the CDF, any shape.

        Returns
        -------
        ndarray
            CDF values of the same shape, clipped into ``[min_eps, 1 - min_eps]``.
        """
        u, below, above, inside = _regions(u)
        y = np.zeros(u.shape, dtype=float)

        y[below] = min_eps * np.exp(-(data_min - u[below]) / tail_scale)
        y[above] = 1.0 - min_eps * np.exp(-(u[above] - data_max) / tail_scale)

        if np.any(inside):
            interior = np.array(cs(u[inside]), dtype=float)
            # The spline does not extrapolate, so it returns NaN for a point that
            # is inside the data range but outside the grid; fall back to linear
            # interpolation there.  NOTE: this used to be written
            # `y[inside][nan] = ...`, which assigns into a temporary copy and so
            # silently left the NaNs in place.
            missing = np.isnan(interior)
            if np.any(missing):
                interior[missing] = np.interp(u[inside][missing], xg, cdf_vals)
            y[inside] = interior

        return np.clip(y, min_eps, 1.0 - min_eps)

    def pdf_fn(u: np.ndarray) -> np.ndarray:
        """
        Density of `cdf_fn`.

        Parameters
        ----------
        u : ndarray
            Points at which to evaluate the density, any shape.

        Returns
        -------
        ndarray
            Strictly positive densities of the same shape: the analytic
            derivative of the exponential tails outside the data range, and a
            central finite difference of `cdf_fn` inside it.
        """
        u, below, above, inside = _regions(u)
        y = np.zeros(u.shape, dtype=float)

        # Analytical derivatives in tails (from exponential extrapolation)
        tail_density = min_eps / tail_scale
        y[below] = tail_density * np.exp(-(data_min - u[below]) / tail_scale)
        y[above] = tail_density * np.exp(-(u[above] - data_max) / tail_scale)

        if np.any(inside):
            eps_fd = min(1e-6, tail_scale / 1000)  # Adaptive step size
            cdf_plus = cdf_fn(u[inside] + eps_fd)
            cdf_minus = cdf_fn(u[inside] - eps_fd)
            y[inside] = (cdf_plus - cdf_minus) / (2 * eps_fd)

        # Ensure positive and bounded
        return np.maximum(y, min_eps)

    return cdf_vals[np.argsort(sort_idx)], cdf_fn, pdf_fn


class EmpiricalMarginalToGaussian(AbstractBijection):
    r"""
    Bijection between a standard normal ``z`` and a parameter's empirical marginal.

    ``transform`` maps ``z ~ N(0, 1)`` to ``x = F^{-1}(Phi(z))``, where ``F`` is
    the empirical CDF of the samples the bijection was built from; ``inverse``
    maps ``x`` back with ``z = Phi^{-1}(F(x))``.  ``F`` is clamped away from 0
    and 1 (see `min_eps`), so a point outside the range of those samples still
    gets a finite latent value and a finite log-density.

    Parameters
    ----------
    samples : ndarray, shape (n_samples,)
        Samples of a single parameter, with NaNs already removed.
    num_points : int, default 200
        Number of quantiles used to represent the CDF.  This is the resolution of
        the transform: more points follow the marginal more closely and cost more
        memory per source.
    tail_decay : float, default 2.0
        Divisor applied to the interquartile range when choosing the tail scale,
        ``tail_scale = max(iqr / tail_decay, range / 10, 0.1)``.  A *larger* value
        therefore gives a shorter tail scale, i.e. a faster decay.

    Attributes
    ----------
    x_grid : jax.Array, shape (num_points,)
        The quantile grid, increasing.
    raw_cdf : jax.Array, shape (num_points,)
        Empirical CDF on `x_grid`, increasing.
    data_min, data_max : float
        Range of `samples`; the exponential tails start here.
    tail_scale : float
        Decay length of the tails, in the units of `samples`.
    min_eps : float
        Smallest CDF value allowed, ``1e-7``.

    Notes
    -----
    This bijection is univariate (``shape == ()``): build one per parameter and
    combine them with ``flowjax.bijections.Stack``.  Its log-determinant is
    computed from a finite-difference density, so it is accurate to roughly the
    finite-difference step rather than to machine precision.

    Outside ``[data_min, data_max]`` the clamp on the CDF dominates the
    exponential extrapolation (see :func:`make_empirical_cdf_spline`), so every
    point below the data maps to the same latent value ``Phi^{-1}(min_eps)``
    (about -5.2) and every point above it to ``+5.2``.  The transform is a guard
    against infinities out there, not a model of the tails; it is faithful only
    within the range of the samples it was built from.

    Examples
    --------
    >>> import numpy as np
    >>> import jax.numpy as jnp
    >>> samples = np.random.default_rng(0).normal(size=500)
    >>> bijection = EmpiricalMarginalToGaussian(samples)
    >>> x = bijection.transform(jnp.asarray(0.0))   # the empirical median
    >>> bool(abs(float(x)) < 0.5)
    True
    """

    x_grid: jnp.ndarray
    raw_cdf: jnp.ndarray
    data_min: float
    data_max: float
    tail_scale: float
    min_eps: float = 1e-7
    cond_shape: ClassVar[None] = None                # type: ignore[misc]  # AbstractVar
    shape: ClassVar[tuple[int, ...]] = ()            # type: ignore[misc]  # AbstractVar

    def __init__(self, samples: np.ndarray, num_points: int = 200,
                 tail_decay: float = 2.0) -> None:
        """Fit the transform to `samples`; see the class docstring for the parameters."""
        # Compute adaptive tail scale based on data characteristics
        q25, q75 = np.percentile(samples, [25, 75])
        iqr = q75 - q25
        data_range = np.max(samples) - np.min(samples)
        tail_scale = max(iqr / tail_decay, data_range / 10, 0.1)

        # Create the empirical CDF on a quantile grid.  Only the CDF values
        # are kept: the closures make_empirical_cdf_spline returns are numpy, and
        # this class re-implements them in jax below.
        x_grid = np.quantile(samples, np.linspace(0, 1, num_points))
        raw_cdf, _, _ = make_empirical_cdf_spline(x_grid, samples)

        # Store data as JAX arrays for Equinox compatibility
        self.x_grid = jnp.array(x_grid)
        self.raw_cdf = jnp.array(raw_cdf)
        self.data_min = float(np.min(samples))
        self.data_max = float(np.max(samples))
        self.tail_scale = tail_scale
        self.min_eps = 1e-7

    def _smooth_interp_cdf(self, x: ArrayLike) -> jax.Array:
        """
        Evaluate the empirical CDF at `x`, with clamped exponential tails.

        Parameters
        ----------
        x : array_like
            Point(s) in data space.

        Returns
        -------
        jax.Array
            CDF values in ``[min_eps, 1 - min_eps]``, same shape as `x`.
        """
        # Use JIT-compiled version for better performance
        return _jit_smooth_interp_cdf(jnp.asarray(x), self.x_grid, self.raw_cdf,
                                      self.data_min, self.data_max,
                                      self.tail_scale, self.min_eps)

    def _smooth_finite_diff_pdf(self, x: ArrayLike) -> jax.Array:
        """
        Evaluate the empirical density at `x` by finite differencing the CDF.

        Parameters
        ----------
        x : array_like
            Point(s) in data space.

        Returns
        -------
        jax.Array
            Strictly positive densities, same shape as `x`.
        """
        # Use JIT-compiled version for better performance
        return _jit_smooth_finite_diff_pdf(jnp.asarray(x), self.x_grid, self.raw_cdf,
                                           self.data_min, self.data_max,
                                           self.tail_scale, self.min_eps)

    def inverse_and_log_det(self, x: ArrayLike,
                            condition: ArrayLike | None = None) -> tuple[jax.Array, jax.Array]:
        """
        Map data space to the standard normal, ``z = Phi^{-1}(F(x))``.

        Parameters
        ----------
        x : array_like
            Point(s) in data space.
        condition : array_like, optional
            Unused; present because ``flowjax`` bijections all accept it.

        Returns
        -------
        z : jax.Array
            Latent value(s), same shape as `x`.
        log_det : jax.Array
            Scalar ``log |dz/dx|``, summed over the elements of `x`.
        """
        # Get CDF value using smooth interpolation
        u = self._smooth_interp_cdf(x)

        # Transform to standard Gaussian (ndtri is the inverse normal CDF)
        z = ndtri(u)

        # Jacobian: |dz/dx| = |dz/du| * |du/dx| = (1/phi(z)) * pdf(x)
        pdf_x = self._smooth_finite_diff_pdf(x)

        # JAX normal PDF
        pdf_z = jnp.exp(-0.5 * z**2) / jnp.sqrt(2 * jnp.pi)
        log_det = jnp.log(pdf_x) - jnp.log(pdf_z)

        return z, jnp.sum(log_det)

    def transform_and_log_det(self, z: ArrayLike,
                              condition: ArrayLike | None = None) -> tuple[jax.Array, jax.Array]:
        """
        Map the standard normal to data space, ``x = F^{-1}(Phi(z))``.

        Parameters
        ----------
        z : array_like
            Latent value(s).
        condition : array_like, optional
            Unused; present because ``flowjax`` bijections all accept it.

        Returns
        -------
        x : jax.Array
            Data-space value(s), same shape as `z`.  Points in the far tails are
            placed by inverting the exponential extrapolation rather than the
            spline.
        log_det : jax.Array
            Scalar ``log |dx/dz|``, summed over the elements of `z`.
        """
        # Transform to uniform using the JAX normal CDF
        u = ndtr(z)
        u = jnp.clip(u, self.min_eps, 1.0 - self.min_eps)

        # Inverse CDF with smooth extrapolation handling
        # For very low u (left tail)
        x_left = jnp.where(
            u <= self.min_eps * 2,  # Safety factor
            self.data_min + self.tail_scale * jnp.log(u / self.min_eps),
            0.0
        )

        # For very high u (right tail)
        x_right = jnp.where(
            u >= 1.0 - self.min_eps * 2,  # Safety factor
            self.data_max - self.tail_scale * jnp.log((1.0 - u) / self.min_eps),
            0.0
        )

        # For interior (use interpolation)
        x_interior = jnp.where(
            (u > self.min_eps * 2) & (u < 1.0 - self.min_eps * 2),
            jnp.interp(u, self.raw_cdf, self.x_grid),
            0.0
        )

        # Combine (only one will be non-zero for each point)
        x = x_left + x_right + x_interior

        # Jacobian: |dx/dz| = |dx/du| * |du/dz| = (1/pdf(x)) * phi(z)
        pdf_x = self._smooth_finite_diff_pdf(x)

        # JAX normal PDF
        pdf_z = jnp.exp(-0.5 * z**2) / jnp.sqrt(2 * jnp.pi)
        log_det = jnp.log(1.0 / pdf_x) + jnp.log(pdf_z)

        return x, jnp.sum(log_det)


# JIT-compiled helper functions for improved performance
def _smooth_interp_cdf_impl(x: jax.Array, x_grid: jax.Array, raw_cdf: jax.Array,
                            data_min: float, data_max: float,
                            tail_scale: float, min_eps: float) -> jax.Array:
    """
    Jax implementation of :meth:`EmpiricalMarginalToGaussian._smooth_interp_cdf`.

    Parameters
    ----------
    x : jax.Array
        Point(s) in data space.
    x_grid, raw_cdf : jax.Array, shape (num_points,)
        The quantile grid and the empirical CDF on it, both increasing.
    data_min, data_max : float
        Range of the training samples; the exponential tails start here.
    tail_scale : float
        Decay length of the tails.
    min_eps : float
        Smallest CDF value allowed.

    Returns
    -------
    jax.Array
        CDF values in ``[min_eps, 1 - min_eps]``, same shape as `x`.
    """
    # Smooth extrapolation below minimum
    below_contrib = jnp.where(
        x < data_min,
        min_eps * jnp.exp(-(data_min - x) / tail_scale),
        0.0
    )

    # Smooth extrapolation above maximum
    above_contrib = jnp.where(
        x > data_max,
        1.0 - min_eps * jnp.exp(-(x - data_max) / tail_scale),
        0.0
    )

    # Interior: JAX-compatible interpolation
    interior_contrib = jnp.where(
        (x >= data_min) & (x <= data_max),
        jnp.interp(x, x_grid, raw_cdf),
        0.0
    )

    # Combine contributions
    u = below_contrib + above_contrib + interior_contrib

    # Ensure numerical bounds
    return jnp.clip(u, min_eps, 1.0 - min_eps)


def _smooth_finite_diff_pdf_impl(x: jax.Array, x_grid: jax.Array, raw_cdf: jax.Array,
                                 data_min: float, data_max: float,
                                 tail_scale: float, min_eps: float) -> jax.Array:
    """
    Jax implementation of :meth:`EmpiricalMarginalToGaussian._smooth_finite_diff_pdf`.

    Parameters
    ----------
    x : jax.Array
        Point(s) in data space.
    x_grid, raw_cdf : jax.Array, shape (num_points,)
        The quantile grid and the empirical CDF on it, both increasing.
    data_min, data_max : float
        Range of the training samples.
    tail_scale : float
        Decay length of the tails; the finite-difference step is
        ``tail_scale / 1000``.
    min_eps : float
        Floor on the returned density, so a log-density stays finite.

    Returns
    -------
    jax.Array
        Densities, at least `min_eps`, same shape as `x`.
    """
    # Adaptive step size for finite differences
    eps_fd = tail_scale / 1000

    cdf_plus = _smooth_interp_cdf_impl(x + eps_fd, x_grid, raw_cdf, data_min, data_max, tail_scale, min_eps)
    cdf_minus = _smooth_interp_cdf_impl(x - eps_fd, x_grid, raw_cdf, data_min, data_max, tail_scale, min_eps)
    pdf = (cdf_plus - cdf_minus) / (2 * eps_fd)

    return jnp.maximum(pdf, min_eps)


# Create JIT-compiled versions at module level
_jit_smooth_interp_cdf = jax.jit(_smooth_interp_cdf_impl)
_jit_smooth_finite_diff_pdf = jax.jit(_smooth_finite_diff_pdf_impl)


class NormalToUniform(AbstractBijection):
    r"""
    Bijection between a standard normal ``z`` and a uniform ``x`` on ``[a, b]``.

    ``transform`` (latent to data) is

    .. math::

        u = \tfrac{1}{2}\bigl(1 + \mathrm{erf}(z/\sqrt{2})\bigr), \qquad
        x = a + u\,(b - a),

    and ``inverse`` (data to latent) is

    .. math::

        u = \mathrm{clip}\bigl((x - a)/(b - a),\, \epsilon,\, 1 - \epsilon\bigr),
        \qquad z = \sqrt{2}\,\mathrm{erf}^{-1}(2u - 1).

    Use it for a parameter with hard, known bounds -- a phase or a cosine of an
    inclination -- so that a flow trained in ``z`` can never place mass outside
    the physical range.

    Parameters
    ----------
    a : float
        Lower bound of the uniform support.
    b : float
        Upper bound of the uniform support; must exceed `a`.
    eps : float, default 1e-6
        Clamp on the uniform value, keeping it away from 0 and 1 where
        ``erfinv`` diverges.  A point outside ``[a, b]`` is pulled to the
        corresponding end of the latent range rather than sent to infinity.

    Notes
    -----
    Univariate (``shape == ()``): build one per parameter and combine them with
    ``flowjax.bijections.Stack``.

    Examples
    --------
    >>> import jax.numpy as jnp
    >>> bijection = NormalToUniform(0.0, 1.0)
    >>> x, log_det = bijection.transform_and_log_det(jnp.asarray(0.0))
    >>> float(x), round(float(log_det), 4)
    (0.5, -0.9189)
    """

    a: float
    b: float
    eps: float = 1e-6
    cond_shape: ClassVar[None] = None                # type: ignore[misc]  # AbstractVar

    shape: ClassVar[tuple[int, ...]] = ()            # type: ignore[misc]  # AbstractVar

    def inverse_and_log_det(self, x: ArrayLike,
                            condition: ArrayLike | None = None) -> tuple[jax.Array, jax.Array]:
        """
        Map ``x`` in ``[a, b]`` to the standard normal.

        Parameters
        ----------
        x : array_like
            Data-space value(s); values outside ``[a, b]`` are clamped by `eps`.
        condition : array_like, optional
            Unused; present because ``flowjax`` bijections all accept it.

        Returns
        -------
        z : jax.Array
            Latent value(s), same shape as `x`.
        log_det : jax.Array
            Scalar ``log |dz/dx|``, summed over the elements of `x`.
        """
        # map into (0,1)
        u = (x - self.a) / (self.b - self.a)
        u = jnp.clip(u, self.eps, 1.0 - self.eps)
        # uniform->normal
        y = jnp.sqrt(2.0) * erfinv(2.0 * u - 1.0)
        # log|dz/du|
        log_dz_du = 0.5 * jnp.log(2.0 * jnp.pi) + erfinv(2.0 * u - 1.0) ** 2
        # log|du/dx|
        log_du_dx = -jnp.log(self.b - self.a)
        log_det = jnp.sum(log_dz_du + log_du_dx)
        return y, log_det

    def transform_and_log_det(self, z: ArrayLike,
                              condition: ArrayLike | None = None) -> tuple[jax.Array, jax.Array]:
        """
        Map the standard normal to ``x`` in ``[a, b]``.

        Parameters
        ----------
        z : array_like
            Latent value(s).
        condition : array_like, optional
            Unused; present because ``flowjax`` bijections all accept it.

        Returns
        -------
        x : jax.Array
            Data-space value(s) in ``[a, b]``, same shape as `z`.
        log_det : jax.Array
            Scalar ``log |dx/dz|``, summed over the elements of `z`.
        """
        # normal->uniform
        u = 0.5 * (1.0 + erf(z / jnp.sqrt(2.0)))
        # uniform->original
        x = self.a + u * (self.b - self.a)
        # log|dx/dz|
        log_du_dy = -0.5 * jnp.log(2.0 * jnp.pi) - 0.5 * z ** 2
        log_dx_du = jnp.log(self.b - self.a)
        log_det = jnp.sum(log_dx_du + log_du_dy)
        return x, log_det


class InverseStandardize(AbstractBijection):
    r"""
    Bijection between a standardized ``z`` and data ``x = mean + std * z``.

    The name is the ``transform`` (latent to data) direction: it *undoes* a
    standardization.  ``inverse`` is the standardization itself,
    ``z = (x - mean) / std``.  This is the plain-vanilla latent map for an
    unbounded parameter, and the univariate counterpart of
    :class:`petra.standardized_flows.StandardizationBijection`.

    Parameters
    ----------
    mean : float
        Location added in the ``transform`` direction.
    std : float
        Scale multiplied in the ``transform`` direction; must be non-zero and
        is not floored, so pass a positive value (an empty source slot gives
        ``nan``).

    Notes
    -----
    Univariate (``shape == ()``): build one per parameter and combine them with
    ``flowjax.bijections.Stack``.

    Examples
    --------
    >>> import jax.numpy as jnp
    >>> bijection = InverseStandardize(1.0, 2.0)
    >>> x, log_det = bijection.transform_and_log_det(jnp.asarray(0.5))
    >>> float(x), round(float(log_det), 6)
    (2.0, 0.693147)
    """

    mean: float
    std: float
    cond_shape: ClassVar[None] = None                # type: ignore[misc]  # AbstractVar

    shape: ClassVar[tuple[int, ...]] = ()            # type: ignore[misc]  # AbstractVar

    def inverse_and_log_det(self, x: ArrayLike,
                            condition: ArrayLike | None = None) -> tuple[jax.Array, jax.Array]:
        """
        Standardize: map data ``x`` to ``z = (x - mean) / std``.

        Parameters
        ----------
        x : array_like
            Data-space value(s).
        condition : array_like, optional
            Unused; present because ``flowjax`` bijections all accept it.

        Returns
        -------
        z : jax.Array
            Standardized value(s), same shape as `x`.
        log_det : jax.Array
            Scalar ``log |dz/dx| = -log(std)``.
        """
        u = (jnp.asarray(x) - self.mean) / self.std
        log_du_dx = -jnp.log(self.std)
        log_det = jnp.sum(log_du_dx)
        return u, log_det

    def transform_and_log_det(self, z: ArrayLike,
                              condition: ArrayLike | None = None) -> tuple[jax.Array, jax.Array]:
        """
        Un-standardize: map ``z`` to ``x = mean + std * z``.

        Parameters
        ----------
        z : array_like
            Standardized value(s).
        condition : array_like, optional
            Unused; present because ``flowjax`` bijections all accept it.

        Returns
        -------
        x : jax.Array
            Data-space value(s), same shape as `z`.
        log_det : jax.Array
            Scalar ``log |dx/dz| = log(std)``.
        """
        u = self.std * jnp.asarray(z) + self.mean
        log_du_dy = jnp.log(self.std)
        log_det = jnp.sum(log_du_dy)
        return u, log_det


class NormalToUniformInverseStandardize(AbstractBijection):
    r"""
    :class:`NormalToUniform` written as a standardize/un-standardize sandwich.

    ``transform`` un-standardizes ``z`` to ``y = mean + std * z``, maps ``y``
    through the normal CDF of ``N(mean, std)`` to ``u``, and then to
    ``x = a + u (b - a)``; ``inverse`` runs the same chain backwards.

    Parameters
    ----------
    a : float
        Lower bound of the uniform support.
    b : float
        Upper bound of the uniform support; must exceed `a`.
    mean : float
        Location of the intermediate normal.
    std : float
        Scale of the intermediate normal; must be positive.
    eps : float, default 1e-6
        Clamp on the uniform value, as in :class:`NormalToUniform`.

    Notes
    -----
    The standardization cancels exactly -- ``z`` enters only through
    ``mean + std * z``, which is immediately divided back out -- so for every
    `mean` and `std` this bijection and its log-determinant are *identical* to
    ``NormalToUniform(a, b, eps)``.  It is kept because it is composed by name in
    ``example_notebooks/flows_test.ipynb``; prefer :class:`NormalToUniform` in new
    code, and pass `mean` and `std` to a separate
    :class:`InverseStandardize` if a genuine location-scale step is wanted.

    Univariate (``shape == ()``): build one per parameter and combine them with
    ``flowjax.bijections.Stack``.

    Examples
    --------
    >>> import jax.numpy as jnp
    >>> bijection = NormalToUniformInverseStandardize(0.0, 1.0, 3.0, 7.0)
    >>> x, log_det = bijection.transform_and_log_det(jnp.asarray(0.0))
    >>> float(x), round(float(log_det), 4)   # the same as NormalToUniform(0.0, 1.0)
    (0.5, -0.9189)
    """

    a: float
    b: float
    mean: float
    std: float
    eps: float = 1e-6
    cond_shape: ClassVar[None] = None                # type: ignore[misc]  # AbstractVar

    shape: ClassVar[tuple[int, ...]] = ()            # type: ignore[misc]  # AbstractVar

    def inverse_and_log_det(self, x: ArrayLike,
                            condition: ArrayLike | None = None) -> tuple[jax.Array, jax.Array]:
        """
        Map ``x`` in ``[a, b]`` to the standardized normal ``z``.

        Parameters
        ----------
        x : array_like
            Data-space value(s); values outside ``[a, b]`` are clamped by `eps`.
        condition : array_like, optional
            Unused; present because ``flowjax`` bijections all accept it.

        Returns
        -------
        z : jax.Array
            Latent value(s), same shape as `x`.
        log_det : jax.Array
            Scalar ``log |dz/dx|``, summed over the elements of `x`.
        """
        # map into (0,1)
        u = (x - self.a) / (self.b - self.a)
        u = jnp.clip(u, self.eps, 1.0 - self.eps)
        # uniform->normal
        y = self.mean + self.std * jnp.sqrt(2.0) * erfinv(2.0 * u - 1.0)
        # standardize
        z = (y - self.mean) / self.std
        # log|dz/dy|
        log_dz_dy = -jnp.log(self.std)
        # log|dy/du|
        log_dy_du = jnp.log(self.std) + 0.5 * jnp.log(2.0 * jnp.pi) + erfinv(2.0 * u - 1.0) ** 2
        # log|du/dx|
        log_du_dx = -jnp.log(self.b - self.a)
        log_det = jnp.sum(log_dy_du + log_du_dx + log_dz_dy)
        return z, log_det

    def transform_and_log_det(self, z: ArrayLike,
                              condition: ArrayLike | None = None) -> tuple[jax.Array, jax.Array]:
        """
        Map the standardized normal ``z`` to ``x`` in ``[a, b]``.

        Parameters
        ----------
        z : array_like
            Latent value(s).
        condition : array_like, optional
            Unused; present because ``flowjax`` bijections all accept it.

        Returns
        -------
        x : jax.Array
            Data-space value(s) in ``[a, b]``, same shape as `z`.
        log_det : jax.Array
            Scalar ``log |dx/dz|``, summed over the elements of `z`.
        """
        # unstandardize
        y = self.std * z + self.mean
        # normal->uniform
        u = 0.5 * (1.0 + erf((y - self.mean) / (self.std * jnp.sqrt(2.0))))
        # uniform->original
        x = self.a + u * (self.b - self.a)
        # jacobians:
        log_dz_dy = jnp.log(self.std)
        log_du_dy = -0.5 * jnp.log(2.0 * jnp.pi) - 0.5 * ((y - self.mean)/self.std)**2 - jnp.log(self.std)
        log_dx_du = jnp.log(self.b - self.a)
        log_det = jnp.sum(log_dz_dy + log_dx_du + log_du_dy)
        return x, log_det
