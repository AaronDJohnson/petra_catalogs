"""
Merge sources example for PETRA.

Demonstrates the post-processing merge step that detects source slots
which were split by MV Normal relabeling (e.g., bimodal frequency
posteriors) and merges them when a single normalizing flow fits
better than two separate flows.

This example creates synthetic trans-dimensional data where one true
source has a bimodal frequency posterior, then shows how merge_sources
recovers the correct picture.

The script is self-checking: the surviving sources' mean frequencies are
matched to the truth with :func:`scipy.optimize.linear_sum_assignment` (slot
indices are arbitrary) and asserted to agree, so a regression fails the script
instead of quietly producing a wrong plot.  It writes its PNG next to itself
and never calls ``plt.show()``, so it runs unattended under ``MPLBACKEND=Agg``.

Usage:
    python examples/merge_example.py
"""

from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment

from petra.posterior_chain import PosteriorChain
from petra.merge_sources import merge_sources
from petra.utils import frequency_bin_width

OUTPUT_DIR = Path(__file__).parent

# Absolute tolerance on a surviving source's mean frequency, in frequency bins.
# A merge only moves samples between slots, so a correct merge reproduces the
# truth to well within one bin; the closest pair of true sources is 50 bins
# apart, so this cannot accidentally pass.
ATOL_BINS = 0.3

# ── 1. Generate synthetic trans-dimensional data ────────────────────────
# Simulate a scenario after MV Normal relabeling: a bimodal source has
# been split into two slots that rarely co-occur.

np.random.seed(42)
n_samples = 500
n_sources = 4
n_params = 3  # e.g., frequency, amplitude, phase

# Observation time → frequency resolution
obs_time_yrs = 5.0
delta_freq = frequency_bin_width(obs_time_yrs)

chain = np.full((n_samples, n_sources, n_params), np.nan)

# Source 0: strong source, always present
chain[:, 0, 0] = np.random.normal(50 * delta_freq, 0.5 * delta_freq, n_samples)
chain[:, 0, 1] = np.random.normal(1e-22, 1e-24, n_samples)
chain[:, 0, 2] = np.random.uniform(0, 2 * np.pi, n_samples)

# Sources 1 & 2: SPLIT bimodal source — low mode in slot 1, high mode in slot 2
# They almost never co-occur (the original source flips between modes)
for i in range(n_samples):
    if np.random.rand() < 0.55:
        # Low-frequency mode → slot 1
        chain[i, 1, 0] = np.random.normal(100 * delta_freq, 1.0 * delta_freq)
        chain[i, 1, 1] = np.random.normal(5e-23, 5e-25)
        chain[i, 1, 2] = np.random.uniform(0, 2 * np.pi)
    else:
        # High-frequency mode → slot 2
        chain[i, 2, 0] = np.random.normal(104 * delta_freq, 1.0 * delta_freq)
        chain[i, 2, 1] = np.random.normal(5e-23, 5e-25)
        chain[i, 2, 2] = np.random.uniform(0, 2 * np.pi)

# Source 3: weak source, present ~30% of the time
for i in range(n_samples):
    if np.random.rand() < 0.3:
        chain[i, 3, 0] = np.random.normal(200 * delta_freq, 0.8 * delta_freq)
        chain[i, 3, 1] = np.random.normal(1e-23, 2e-25)
        chain[i, 3, 2] = np.random.uniform(0, 2 * np.pi)

# The truth the merge has to reproduce: three physical sources, the middle one
# being the union of the two slots the bimodal posterior was split across.
# Taken from the generated data rather than hardcoded, so the check does not
# depend on the realised mixture fraction.
true_mean_freq_bins = np.array([
    np.nanmean(chain[:, 0, 0]) / delta_freq,
    np.nanmean(np.concatenate([chain[:, 1, 0], chain[:, 2, 0]])) / delta_freq,
    np.nanmean(chain[:, 3, 0]) / delta_freq,
])

# ── 2. Create PosteriorChain ────────────────────────────────────────────
pc = PosteriorChain(
    chain=chain,
    num_sources=n_sources,
    num_params_per_source=n_params,
    trans_dimensional=True,
)

print(f"Input chain: {pc.chain.shape}")
print(f"  {n_samples} samples, {n_sources} source slots, {n_params} params")
print(f"  Frequency resolution: {delta_freq:.4e}")
print()

# Check per-source presence
for i in range(n_sources):
    frac = np.mean(~np.isnan(chain[:, i, 0]))
    print(f"  Source {i}: present in {frac:.1%} of samples")
print()

# ── 3. Run merge_sources ────────────────────────────────────────────────
print("=" * 60)
print("Running merge_sources...")
print("=" * 60)

result = merge_sources(
    pc,
    obs_time_yrs=obs_time_yrs,
    freq_param_index=0,
    max_freq_std_bins=6,
    max_merge_distance_bins=10,
    max_co_occurrence=0.1,
    knots=16,
    rng_seed=0,
    progress=False,
)

# ── 4. Print results ────────────────────────────────────────────────────
print()
print("=" * 60)
print("Results after merge")
print("=" * 60)
print()

occupied = []
for i in range(result.num_sources):
    frac = np.mean(~np.isnan(result.chain[:, i, 0]))
    if frac > 0.01:
        freq_data = result.chain[:, i, 0]
        valid = freq_data[~np.isnan(freq_data)]
        occupied.append(np.mean(valid) / delta_freq)
        print(f"  Source {i}: present {frac:.1%}, "
              f"mean freq = {np.mean(valid)/delta_freq:.1f} bins, "
              f"std = {np.std(valid)/delta_freq:.1f} bins")
    else:
        print(f"  Source {i}: present {frac:.1%} (freed slot)")

print()
print(f"prob_in_model: {result.prob_in_model}")
print()

# ── 5. Check the result ─────────────────────────────────────────────────
# One slot must have been freed, so exactly three sources survive, and their
# mean frequencies must reproduce the truth up to a relabeling of the slots.
recovered_mean_freq_bins = np.array(occupied)
assert len(recovered_mean_freq_bins) == len(true_mean_freq_bins), (
    f"expected {len(true_mean_freq_bins)} surviving sources, "
    f"got {len(recovered_mean_freq_bins)}: {recovered_mean_freq_bins}")

distances = np.abs(recovered_mean_freq_bins[:, None] - true_mean_freq_bins[None, :])
slot, true_index = linear_sum_assignment(distances)
matched = np.empty_like(recovered_mean_freq_bins)
matched[true_index] = recovered_mean_freq_bins[slot]

print("Recovered mean frequency vs true, in bins:")
for true_bin, found_bin in zip(true_mean_freq_bins, matched):
    print(f"  true {true_bin:8.2f}  ->  recovered {found_bin:8.2f}   "
          f"(error {abs(found_bin - true_bin):.3f} bins)")
print()

assert np.allclose(matched, true_mean_freq_bins, atol=ATOL_BINS), (
    f"merge did not reproduce the true sources:\n{matched}\nvs\n{true_mean_freq_bins}")

# No sample may be created or destroyed by a merge, only moved between slots.
assert (np.count_nonzero(~np.isnan(result.chain[:, :, 0]))
        == np.count_nonzero(~np.isnan(pc.chain[:, :, 0])))

# ── 6. Plot before/after ─────────────────────────────────────────────────
before_chain = pc.chain
after_chain = result.chain
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
param_labels = ['Frequency', 'Amplitude', 'Phase']

fig, axes = plt.subplots(2, 3, figsize=(14, 7))

for j in range(n_params):
    for row, (data_chain, when) in enumerate([(before_chain, 'Before merge'),
                                              (after_chain, 'After merge')]):
        ax = axes[row, j]
        for i in range(n_sources):
            data = data_chain[:, i, j]
            valid = data[~np.isnan(data)]
            if len(valid) > 0:
                if j == 0:
                    valid = valid / delta_freq  # plot freq in bins
                ax.hist(valid, bins=40, alpha=0.6, color=colors[i],
                        label=f'Slot {i} ({len(valid)})')
        ax.set_title(f'{param_labels[j]} — {when}')
        ax.legend(fontsize=7)
        ax.grid(True, alpha=0.3)
        if j == 0:
            ax.set_xlabel('Frequency (bins)')

fig.suptitle('Source Merge: Before vs After', fontsize=14, y=0.98)
plt.tight_layout()
output_path = OUTPUT_DIR / 'merge_example_result.png'
plt.savefig(output_path, dpi=150)
plt.close(fig)
print(f"Plot saved to {output_path}")
