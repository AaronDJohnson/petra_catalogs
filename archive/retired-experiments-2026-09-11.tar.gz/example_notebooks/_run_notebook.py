"""Run the bayesian_gaussian_catalog notebook as a script."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import time
from scipy.optimize import linear_sum_assignment

from petra.posterior_chain import PosteriorChain
from petra.make_catalog import make_catalog_mv_normal
from petra.bayesian_gaussian import make_catalog_bayesian_gaussian

# ============================================================
# SECTION 1: Synthetic Benchmark
# ============================================================
print("=" * 70)
print("SECTION 1: SYNTHETIC BENCHMARK")
print("=" * 70)


def make_hard_synthetic_chain(n_samples=500, max_sources=7, D=3, seed=42):
    rng = np.random.default_rng(seed)
    true_means = np.array([
        [0.0, 0.0, 0.0], [0.8, 0.5, 0.3], [5.0, -3.0, 2.0],
        [-4.0, 4.0, -1.0], [3.0, 3.0, -4.0],
    ])
    true_covs = np.array([
        np.diag([0.5, 0.3, 0.4]), np.diag([0.4, 0.5, 0.3]),
        np.diag([0.3, 0.2, 0.3]), np.diag([0.2, 0.4, 0.2]),
        np.diag([0.3, 0.3, 0.5]),
    ])
    presence_probs = [0.6, 0.6, 0.9, 0.85, 0.8]
    n_clusters = len(true_means)
    chain = np.full((n_samples, max_sources, D), np.nan)
    for i in range(n_samples):
        active = [c for c in range(n_clusters) if rng.random() < presence_probs[c]]
        if len(active) == 0:
            active = [rng.integers(n_clusters)]
        slots = rng.choice(max_sources, size=len(active), replace=False)
        for slot, cluster in zip(slots, active):
            chain[i, slot, :] = rng.multivariate_normal(
                true_means[cluster], true_covs[cluster])
    return chain, max_sources, D, true_means


chain, max_sources, D, true_means = make_hard_synthetic_chain()
print(f"Chain: {chain.shape}, clusters 0&1 distance: "
      f"{np.linalg.norm(true_means[0] - true_means[1]):.2f}")

# MV Normal (5 seeds)
print("\n--- MV Normal (5 seeds) ---")
mv_results = {}
for seed in [0, 1, 2, 3, 4]:
    pc = PosteriorChain(chain.copy(), max_sources, D, trans_dimensional=True)
    t0 = time.time()
    result = make_catalog_mv_normal(
        pc, max_num_sources=max_sources, num_iterations=200,
        initialization_param_index=0, shuffle_seed=seed)
    elapsed = time.time() - t0
    cost = result.cost_dict[max_sources]
    mv_results[seed] = {"result": result, "cost": cost, "time": elapsed}
    print(f"  Seed {seed}: cost={cost:.4f}, time={elapsed:.1f}s")

# Bayesian Gaussian (3 seeds)
print("\n--- Bayesian Gaussian (3 seeds) ---")
bayes_results = {}
for seed in [0, 1, 2]:
    pc = PosteriorChain(chain.copy(), max_sources, D, trans_dimensional=True)
    t0 = time.time()
    result = make_catalog_bayesian_gaussian(
        pc, max_num_sources=max_sources, num_iterations=5,
        initialization_param_index=0, shuffle_seed=seed)
    elapsed = time.time() - t0
    cost = result.cost_dict[max_sources]
    bayes_results[seed] = {"result": result, "cost": cost, "time": elapsed}
    print(f"  Seed {seed}: cost={cost:.4f}, time={elapsed:.1f}s")

mv_costs = [r['cost'] for r in mv_results.values()]
bayes_costs = [r['cost'] for r in bayes_results.values()]
print(f"\nMV Normal costs:  {[f'{c:.4f}' for c in mv_costs]}")
print(f"Bayesian costs:   {[f'{c:.4f}' for c in bayes_costs]}")

# Save comparison plot
fig, ax = plt.subplots(figsize=(8, 4))
ax.scatter([0]*len(mv_costs), mv_costs, s=80, marker='o', label='MV Normal', zorder=3)
ax.scatter([1]*len(bayes_costs), bayes_costs, s=80, marker='s', label='Bayesian Gaussian', zorder=3)
ax.axhline(min(mv_costs), color='C0', ls='--', alpha=0.5)
ax.axhline(min(bayes_costs), color='C1', ls='--', alpha=0.5)
ax.set_xticks([0, 1]); ax.set_xticklabels(['MV Normal', 'Bayesian Gaussian'])
ax.set_ylabel('Final assignment cost'); ax.set_title('Cost comparison'); ax.legend()
plt.tight_layout()
plt.savefig('bayesian_cost_comparison.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: bayesian_cost_comparison.png")

# Recovered means
best_mv = min(mv_results, key=lambda s: mv_results[s]['cost'])
best_bayes = min(bayes_results, key=lambda s: bayes_results[s]['cost'])
mv_ch = mv_results[best_mv]['result'].chain
bayes_ch = bayes_results[best_bayes]['result'].chain

def recovered_means(ch, max_s, D):
    rec = []
    for i in range(max_s):
        d = ch[:, i, :]
        v = ~np.isnan(d).any(axis=1)
        rec.append(d[v].mean(axis=0) if v.sum() > ch.shape[0]*0.1 else np.full(D, np.nan))
    return np.array(rec)

def match(rec, true):
    vm = ~np.isnan(rec[:, 0])
    vr = rec[vm]
    c = np.array([[np.linalg.norm(r-t) for t in true] for r in vr])
    ri, ci = linear_sum_assignment(c)
    return vr[ri], true[ci], c[ri, ci]

print("\nMV Normal recovery:")
mr, mt, me = match(recovered_means(mv_ch, max_sources, D), true_means)
for r, t, e in zip(mr, mt, me):
    print(f"  True:{t} Recovered:{np.round(r,3)} Error:{e:.3f}")

print("\nBayesian recovery:")
mr, mt, me = match(recovered_means(bayes_ch, max_sources, D), true_means)
for r, t, e in zip(mr, mt, me):
    print(f"  True:{t} Recovered:{np.round(r,3)} Error:{e:.3f}")

# ============================================================
# SECTION 2: Real LISA data
# ============================================================
print("\n" + "=" * 70)
print("SECTION 2: REAL LISA DATA")
print("=" * 70)

df = pd.read_feather('./data/lisa_example.feather')
num_sources = int(df['num_sources'][0])
num_params = int(df['num_params_per_source'][0])
trans = bool(df['transdimensional'][0])
df_data = df.drop(columns=['num_sources', 'num_params_per_source', 'transdimensional'])
lisa_chain_full = df_data.values.reshape(-1, num_sources, num_params)
lisa_max_sources = 15
lisa_chain = lisa_chain_full[:, :lisa_max_sources, :]
print(f"LISA chain: {lisa_chain_full.shape} -> trimmed to {lisa_chain.shape}")

# MV Normal
lisa_pc = PosteriorChain(lisa_chain.copy(), lisa_max_sources, num_params, trans_dimensional=trans)
t0 = time.time()
lisa_mv = make_catalog_mv_normal(
    lisa_pc, max_num_sources=lisa_max_sources, num_iterations=200,
    initialization_param_index=0, shuffle_seed=42)
mv_time = time.time() - t0
print(f"MV Normal: cost={lisa_mv.cost_dict[lisa_max_sources]:.4f}, time={mv_time:.1f}s")

# Bayesian Gaussian
lisa_pc2 = PosteriorChain(lisa_chain.copy(), lisa_max_sources, num_params, trans_dimensional=trans)
t0 = time.time()
lisa_bayes = make_catalog_bayesian_gaussian(
    lisa_pc2, max_num_sources=lisa_max_sources, num_iterations=10,
    initialization_param_index=0, mv_normal_init=True, mv_normal_init_iterations=100,
    shuffle_seed=42)
bayes_time = time.time() - t0
print(f"Bayesian: cost={lisa_bayes.cost_dict[lisa_max_sources]:.4f}, time={bayes_time:.1f}s")

# Save trace plots
fig, axes = plt.subplots(1, 2, figsize=(16, 6), sharey=True)
for j in range(lisa_max_sources):
    axes[0].plot(lisa_mv.chain[:, j, 0], ',', alpha=0.6)
    axes[1].plot(lisa_bayes.chain[:, j, 0], ',', alpha=0.6)
axes[0].set_title('MV Normal'); axes[1].set_title('Bayesian Gaussian')
axes[0].set_ylabel('Frequency (Hz)')
for ax in axes: ax.set_xlabel('Sample index')
plt.tight_layout()
plt.savefig('bayesian_lisa_traces.png', dpi=150, bbox_inches='tight')
plt.close()
print("Saved: bayesian_lisa_traces.png")

# Summary
print("\n" + "=" * 70)
print("FINAL SUMMARY")
print("=" * 70)
print(f"MV Normal:          cost={lisa_mv.cost_dict[lisa_max_sources]:.4f}  ({mv_time:.1f}s)")
print(f"Bayesian Gaussian:  cost={lisa_bayes.cost_dict[lisa_max_sources]:.4f}  ({bayes_time:.1f}s)")
delta = lisa_bayes.cost_dict[lisa_max_sources] - lisa_mv.cost_dict[lisa_max_sources]
if delta < 0:
    print(f"Bayesian Gaussian found a BETTER solution (cost {abs(delta):.4f} lower)")
elif delta == 0:
    print("Both methods found the same solution")
else:
    print(f"MV Normal found a better solution (cost {abs(delta):.4f} lower)")
    print("(Note: Bayesian uses a different cost metric — compare trace plots visually)")
